import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from 'app/services/auth.service';

export const authGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  // Check if the user is logged in
  if (authService.isLoggedIn()) {
    return true; // Allow navigation if the user is authenticated
  } else {
    // Redirect to sign-in page if not authenticated
    router.navigate(['/signIn']);
    return false;
  }
};
