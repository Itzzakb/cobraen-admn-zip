/* eslint-disable */
import { FuseNavigationItem } from '@fuse/components/navigation';

export const defaultNavigation: FuseNavigationItem[] = [
  {
    id: 'dashboard',
    title: 'Dashboard',
    type: 'group',
    icon: 'mat_outline:dashboard',
    link: '/dashboard',
  },
  {
    id: 'product',
    title: 'Product Management',
    subtitle: '',
    type: 'collapsable',
    vMenuClass: 'main-title-nav',
    icon: 'feather:box',
    children: [
      {
        id: 'product.add',
        title: 'Product List',
        type: 'basic',
        icon: 'heroicons_outline:clipboard-document-list',
        link: '/products/product-list',
      },
      {
        id: 'product.childList',
        title: 'Child Product List',
        type: 'basic',
        icon: 'heroicons_outline:chat-bubble-left-ellipsis',
        link: '/products/child-product-list',
      },
    ],
  },
    {
    id: 'category',
    title: 'Category Management',
    type: 'group',
    icon: 'mat_outline:category',
    link: '/common/categories',
  },
    {
    id: 'color',
    title: 'Color Management',
    type: 'group',
    icon: 'mat_outline:color_lens',
    link: '/color-management',
  },
    {
    id: 'coupon',
    title: 'Coupon Management',
    type: 'group',
    icon: 'mat_outline:local_offer',
    link: '/coupon',
  },
    {
    id: 'combo',
    title: 'Combo Management',
    type: 'group',
    icon: 'heroicons_outline:gift-top',
    link: '/combo',
  },
    {
    id: 'banner',
    title: 'Banner Management',
    type: 'group',
    icon: 'heroicons_outline:film',
    link: '/banner',
  },
    {
    id: 'fabric',
    title: 'Fabric Management',
    type: 'group',
    icon: 'mat_outline:ac_unit',
    link: '/fabric',
  },
    {
    id: 'fit',
    title: 'Fit Management',
    type: 'group',
    icon: 'mat_outline:accessibility',
    link: '/fit',
  },
    {
    id: 'hsn',
    title: 'HSN Management',
    type: 'group',
    icon: 'mat_outline:list_alt',
    link: '/hsn',
  },

  
];
export const compactNavigation: FuseNavigationItem[] = [
  {
    id: 'dashboards',
    title: 'Dashboards',
    tooltip: 'Dashboards',
    type: 'aside',
    children: [], // This will be filled from defaultNavigation so we don't have to manage multiple sets of the same navigation
  },
  {
    id: 'apps',
    title: 'Apps',
    tooltip: 'Apps',
    type: 'aside',
    icon: 'heroicons_outline:squares-2x2',
    children: [], // This will be filled from defaultNavigation so we don't have to manage multiple sets of the same navigation
  },
  {
    id: 'pages',
    title: 'Pages',
    tooltip: 'Pages',
    type: 'aside',
    icon: 'heroicons_outline:document-duplicate',
    children: [], // This will be filled from defaultNavigation so we don't have to manage multiple sets of the same navigation
  },
  {
    id: 'user-interface',
    title: 'UI',
    tooltip: 'UI',
    type: 'aside',
    icon: 'heroicons_outline:rectangle-stack',
    children: [], // This will be filled from defaultNavigation so we don't have to manage multiple sets of the same navigation
  },
  {
    id: 'navigation-features',
    title: 'Navigation',
    tooltip: 'Navigation',
    type: 'aside',
    icon: 'heroicons_outline:bars-3',
    children: [], // This will be filled from defaultNavigation so we don't have to manage multiple sets of the same navigation
  },
];
export const futuristicNavigation: FuseNavigationItem[] = [
  {
    id: 'dashboards',
    title: 'DASHBOARDS',
    type: 'group',
    children: [], // This will be filled from defaultNavigation so we don't have to manage multiple sets of the same navigation
  },
  {
    id: 'apps',
    title: 'APPS',
    type: 'group',
    children: [], // This will be filled from defaultNavigation so we don't have to manage multiple sets of the same navigation
  },
  {
    id: 'others',
    title: 'OTHERS',
    type: 'group',
  },
  {
    id: 'pages',
    title: 'Pages',
    type: 'aside',
    icon: 'heroicons_outline:document-duplicate',
    children: [], // This will be filled from defaultNavigation so we don't have to manage multiple sets of the same navigation
  },
  {
    id: 'user-interface',
    title: 'User Interface',
    type: 'aside',
    icon: 'heroicons_outline:rectangle-stack',
    children: [], // This will be filled from defaultNavigation so we don't have to manage multiple sets of the same navigation
  },
  {
    id: 'navigation-features',
    title: 'Navigation Features',
    type: 'aside',
    icon: 'heroicons_outline:bars-3',
    children: [], // This will be filled from defaultNavigation so we don't have to manage multiple sets of the same navigation
  },
];
export const horizontalNavigation: FuseNavigationItem[] = [
  {
    id: 'dashboards',
    title: 'Dashboards',
    type: 'group',
    icon: 'heroicons_outline:home',
    children: [], // This will be filled from defaultNavigation so we don't have to manage multiple sets of the same navigation
  },
  {
    id: 'apps',
    title: 'Apps',
    type: 'group',
    icon: 'heroicons_outline:squares-2x2',
    children: [], // This will be filled from defaultNavigation so we don't have to manage multiple sets of the same navigation
  },
  {
    id: 'pages',
    title: 'Pages',
    type: 'group',
    icon: 'heroicons_outline:document-duplicate',
    children: [], // This will be filled from defaultNavigation so we don't have to manage multiple sets of the same navigation
  },
  {
    id: 'user-interface',
    title: 'UI',
    type: 'group',
    icon: 'heroicons_outline:rectangle-stack',
    children: [], // This will be filled from defaultNavigation so we don't have to manage multiple sets of the same navigation
  },
  {
    id: 'navigation-features',
    title: 'Misc',
    type: 'group',
    icon: 'heroicons_outline:bars-3',
    children: [], // This will be filled from defaultNavigation so we don't have to manage multiple sets of the same navigation
  },
];
