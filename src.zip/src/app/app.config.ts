import { ApplicationConfig, inject, provideZoneChangeDetection } from '@angular/core';
import { PreloadAllModules, provideRouter, Routes, withInMemoryScrolling, withPreloading } from '@angular/router';
import { LuxonDateAdapter } from '@angular/material-luxon-adapter';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { provideIcons } from './core/icons/icons.provider';
import { firstValueFrom } from 'rxjs';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideAnimations } from '@angular/platform-browser/animations';
 
import { DashboardComponent } from './modules/admin/common/dashboard/dashboard.component'
import { ServicesComponent } from './pages/services/services.component';
import { SettingsComponent } from './pages/settings/settings.component';
import { routes } from './app.routes';
import { provideFuse } from '@fuse';
import { mockApiServices } from './mock-api';
import { EditorModule, TINYMCE_SCRIPT_SRC } from '@tinymce/tinymce-angular';
import { provideToastr } from 'ngx-toastr';
import { HttpInterceptor } from './interceptors/http-interceptor.interceptor';


// export const routes: Routes = [
//     { path: 'dashboard', component: DashboardComponent },
//     { path: 'services', component: ServicesComponent },
//     { path: 'settings', component: SettingsComponent },
//     { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
//     { path: '**', redirectTo: '/dashboard' }
// ];

export const appConfig: ApplicationConfig = {
  providers: [
    // { provide: TINYMCE_SCRIPT_SRC, useValue: 'tinymce/tinymce.min.js' },
    provideAnimations(),
    provideToastr({
        timeOut: 3000,
        progressBar: true,
        progressAnimation: 'increasing',
        positionClass: 'toast-top-right',
        preventDuplicates: true,
        toastClass: 'ngx-toastr w-fit mt-3',
        tapToDismiss: true,

      },
    ),
    provideHttpClient(withInterceptors([HttpInterceptor])),
    provideRouter(
        routes
    ),

    // Material Date Adapter
    {
        provide: DateAdapter,
        useClass: LuxonDateAdapter,
    },
    {
        provide: MAT_DATE_FORMATS,
        useValue: {
            parse: {
                dateInput: 'D',
            },
            display: {
                dateInput: 'DDD',
                monthYearLabel: 'LLL yyyy',
                dateA11yLabel: 'DD',
                monthYearA11yLabel: 'LLLL yyyy',
            },
        },
    },

    // Transloco Config
    // provideTransloco({
    //     config: {
    //         availableLangs: [
    //             {
    //                 id: 'en',
    //                 label: 'English',
    //             },
    //             {
    //                 id: 'tr',
    //                 label: 'Turkish',
    //             },
    //         ],
    //         defaultLang: 'en',
    //         fallbackLang: 'en',
    //         reRenderOnLangChange: true,
    //         prodMode: true,
    //     },
    //     loader: TranslocoHttpLoader,
    // }),
    // {
    //     // Preload the default language before the app starts to prevent empty/jumping content
    //     provide: APP_INITIALIZER,
    //     useFactory: () => {
    //         const translocoService = inject(TranslocoService);
    //         const defaultLang = translocoService.getDefaultLang();
    //         translocoService.setActiveLang(defaultLang);

    //         return () => firstValueFrom(translocoService.load(defaultLang));
    //     },
    //     multi: true,
    // },

    // Fuse
    provideIcons(),
    provideFuse({
        mockApi: {
            delay: 0,
            services: mockApiServices,
        },
        fuse: {
            layout: 'classic',
            scheme: 'light',
            screens: {
                sm: '600px',
                md: '960px',
                lg: '1280px',
                xl: '1440px',
            },
            theme: 'theme-default',
            themes: [
                {
                    id: 'theme-default',
                    name: 'Default',
                },
                {
                    id: 'theme-brand',
                    name: 'Brand',
                },
                {
                    id: 'theme-teal',
                    name: 'Teal',
                },
                {
                    id: 'theme-rose',
                    name: 'Rose',
                },
                {
                    id: 'theme-purple',
                    name: 'Purple',
                },
                {
                    id: 'theme-amber',
                    name: 'Amber',
                },
            ],
        },
    }),
],
};
