export class GlobalVariables {
  public static baseUrl: string;
}
