import { Injectable } from '@angular/core';
import { GlobalVariables } from '../global-variables';

@Injectable({ providedIn: 'root' })
export class AppConfigService {
  load(): Promise<void> {
    return fetch('/assets/config.json')
      .then((res) => res.json())
      .then((config) => {
        GlobalVariables.baseUrl = config.apiUrl;
      });
  }
}
