import { Component, ViewEncapsulation } from '@angular/core';
import { RouterLink, RouterModule, RouterOutlet } from '@angular/router';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {FormsModule, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators} from '@angular/forms';



import { CommonModule } from '@angular/common';
import { fuseAnimations } from '../@fuse/animations/public-api';
import { FuseAlertComponent } from '../@fuse/components/alert/alert.component';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCheckboxModule } from '@angular/material/checkbox';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { FuseAlertType } from '../@fuse/components/alert/alert.types';
import { LogoComponent } from './components/login/logo/logo.component';
import { LogintitleComponent } from './components/login/logintitle/logintitle.component';
import { DashboardComponent } from './modules/admin/common/dashboard/dashboard.component';
import { ServicesComponent } from './pages/services/services.component';
import { SettingsComponent } from './pages/settings/settings.component';



@Component({
  selector: 'app-root',
  encapsulation: ViewEncapsulation.None,
    animations: fuseAnimations,
    standalone: true,
    imports: [
        RouterLink,
        RouterModule,
        FuseAlertComponent,
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatProgressSpinnerModule,
        LogoComponent,
        LogintitleComponent,
        DashboardComponent,
        ServicesComponent,
        SettingsComponent,
    ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent {


  alert: { type: FuseAlertType; message: string } = {
    type: 'success',
    message: '',
};
signInForm: UntypedFormGroup;
showAlert: boolean = false;

/**
 * Constructor
 */
constructor(
    // private _authService: AuthService,
    private _formBuilder: UntypedFormBuilder
) {}

// -----------------------------------------------------------------------------------------------------
// @ Lifecycle hooks
// -----------------------------------------------------------------------------------------------------

/**
 * On init
 */
ngOnInit(): void {
    // Create the form
    this.signInForm = this._formBuilder.group({
        email: ['', [Validators.required, Validators.email]],
        password: ['', Validators.required],
        rememberMe: [''],
    });
}

// -----------------------------------------------------------------------------------------------------
// @ Public methods
// -----------------------------------------------------------------------------------------------------

/**
 * Sign in
 */
signIn(): void {}

}


