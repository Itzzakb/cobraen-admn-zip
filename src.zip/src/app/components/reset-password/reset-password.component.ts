import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { ErrorMesageService } from 'app/shared/services/error-message.service';

@Component({
  selector: 'app-reset-password',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule,
  ],
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss'],
})
export class ResetPasswordComponent implements OnInit {
  hidePassword = true;
  hideConfirm = true;
  passwordPatternErrorMessage =
    'Use a combo of uppercase letters, lowercase letters, numbers, some special characters ( !, @, $, %, ^, &, *, +,#) and minimum length should be 12.';

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private apiService: ApiService,
    private toastr: ToastrService,
    private errorMessageService: ErrorMesageService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      let token = params?.['token'] || ''; // Ensure token is a string or fallback to an empty string
      let decodedToken = token.replace(/ /g, '+'); // Use replace with regex
      if (decodedToken && decodedToken != '') {
        localStorage.setItem('resetToken', decodedToken);
      } else {
        return;
      }

      if (params?.['token']) {
        this.validateResetToken(decodedToken);
      }
    });
  }

  form = this.fb.group({
    password: [
      '',
      [
        Validators.required,
        Validators.minLength(12),
        Validators.pattern(
          "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?!.*[,)(={}\\]\\[;'_:><?/ `~]).{12,}$"
        ),
      ],
    ],
    confirmPassword: ['', [Validators.required]],
  });

  validateResetToken(decodedToken: string) {
    this.apiService.validateResetToken(decodedToken).subscribe(
      (response) => {
        if (response.requestResult == 1) {
          this.router.navigate(['forgotpassword'], { replaceUrl: true });
        } else {
          this.router.navigate(['expired-link']);
        }
      },
      (error) => {
        this.router.navigate(['expired-link']);
      }
    );
  }

  checkPasswordMatch() {
    const password = this.form.get('password')?.value;
    const confirmPassword = this.form.get('confirmPassword')?.value;
    return password === confirmPassword;
  }

    onSubmit() {
        if (this.form.valid && this.checkPasswordMatch()) {
            let body = {
                "token": localStorage.getItem("resetToken"),
                "password": this.form.value.password
            }
            this.apiService.resetPassword(body).subscribe(
                (response) => {
                    if (response.requestResult == 1) {
                        this.toastr.success('Password reset successfully');
                        this.form.reset();
                        localStorage.removeItem("resetToken");
                    } else {
                        this.toastr.error(this.errorMessageService.getErrorMessage(response.responseTip), 'Error!');
                    }
                }, (error) => {
                    this.toastr.error(this.errorMessageService.getErrorMessage(error.error.responseTip), 'Error!')
                }
            )
        }
    }
}
