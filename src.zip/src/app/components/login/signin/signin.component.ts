import { Component, ViewEncapsulation } from '@angular/core';
import { Router, RouterLink, RouterModule, RouterOutlet } from '@angular/router';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';



import { CommonModule } from '@angular/common';
import { fuseAnimations } from '../../../../@fuse/animations/public-api';
import { FuseAlertComponent } from '../../../../@fuse/components/alert/alert.component';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { FuseAlertType } from '../../../../@fuse/components/alert/alert.types';
import { LogoComponent } from '../logo/logo.component';
import { LogintitleComponent } from '../logintitle/logintitle.component';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';
import { ForgotPasswordModal } from 'app/components/forgot-password-modal/forgot-paassword.component';
import { ErrorMesageService } from 'app/shared/services/error-message.service';


@Component({
  selector: 'app-signin',
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  standalone: true,
  imports: [
    RouterLink,
    RouterModule,
    FuseAlertComponent,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    LogoComponent,
    LogintitleComponent,
  ],
  templateUrl: './signin.component.html',
  styleUrl: './signin.component.scss',
})
export class SigninComponent {
  alert: { type: FuseAlertType; message: string } = {
    type: 'success',
    message: '',
  };
  signInForm: UntypedFormGroup;
  showAlert: boolean = false;

  /**
   * Constructor
   */
  constructor(
    // private _authService: AuthService,
    private _formBuilder: UntypedFormBuilder,
    private router: Router,
    private apiService: ApiService,
    private toastr: ToastrService,
    private dialog: MatDialog,
    private errorMessageService: ErrorMesageService
  ) {}

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  errorMessage = '';
  /**
   * On init
   */
  ngOnInit(): void {
    // Create the form
    this.signInForm = this._formBuilder.group({
      userName: ['', [Validators.required]],
      password: ['', [Validators.required]],
      // rememberMe: [''],
    });
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Sign in
   */
  signIn(): void {
    if (this.signInForm.valid) {
      this.apiService.login(this.signInForm.value).subscribe(
        (response) => {
          if (response.token) {
            localStorage.setItem('authToken', response.token);
            localStorage.setItem('userName', response.name);
            localStorage.setItem('email', response.email);
            localStorage.setItem('userType', response.userType);
            this.router.navigate(['']);
          } else {
            this.errorMessage = this.errorMessageService.getErrorMessage(
              response.responseTip
            );
            this.showError();
          }
        },
        (error) => {
          this.errorMessage = this.errorMessageService.getErrorMessage(
            error.error.responseTip
          );
          this.showError();
          console.error(error);
        }
      );
    }
  }

  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }

  openForgotPasswordModal() {
    const dialogRef = this.dialog.open(ForgotPasswordModal, {
      panelClass: 'custom-forgot-password-modal',
    });
  }
}
