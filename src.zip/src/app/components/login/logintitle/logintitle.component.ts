import { Component } from '@angular/core';

@Component({
  selector: 'app-logintitle',
  standalone: true,
  imports: [],
  templateUrl: './logintitle.component.html',
  styleUrl: './logintitle.component.scss'
})
export class LogintitleComponent {

}
