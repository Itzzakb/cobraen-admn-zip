import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LogintitleComponent } from './logintitle.component';

describe('LogintitleComponent', () => {
  let component: LogintitleComponent;
  let fixture: ComponentFixture<LogintitleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LogintitleComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LogintitleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
