import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-signinform',
  standalone: true,
  imports: [MatIconModule, MatButtonModule],
  templateUrl: './signinform.component.html',
  styleUrl: './signinform.component.scss'
})
export class SigninformComponent {

}
