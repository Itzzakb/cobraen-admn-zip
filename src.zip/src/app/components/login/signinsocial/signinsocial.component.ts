import { Component } from '@angular/core';

@Component({
  selector: 'app-signinsocial',
  standalone: true,
  imports: [],
  templateUrl: './signinsocial.component.html',
  styleUrl: './signinsocial.component.scss'
})
export class SigninsocialComponent {

}
