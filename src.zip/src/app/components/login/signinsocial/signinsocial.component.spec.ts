import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SigninsocialComponent } from './signinsocial.component';

describe('SigninsocialComponent', () => {
  let component: SigninsocialComponent;
  let fixture: ComponentFixture<SigninsocialComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SigninsocialComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SigninsocialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
