import { CommonModule } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import {
    FormControl,
    FormsModule,
    ReactiveFormsModule,
    UntypedFormBuilder,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule, MatLabel } from '@angular/material/form-field';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { ApiService } from '@fuse/services/api-service.service';
import { ImageLibraryContent } from 'app/shared/types/interfaces';
import { ToastrService } from 'ngx-toastr';

@Component({
    selector: 'app-forgot-password',
    templateUrl: './forgot-paassword.component.html',
    styleUrl: './forgot-paassword.component.scss',
    standalone: true,
    imports: [
        MatDialogModule,
        MatButtonModule,
        MatLabel,
        MatFormFieldModule,
        FormsModule,
        ReactiveFormsModule,
        MatInputModule,
        MatIcon,
        MatIconModule,
        CommonModule
    ]
})
export class ForgotPasswordModal implements OnInit {
    imageLibraryContent: ImageLibraryContent[] = [];
    errorMessage: string = '';
    isSpinner: boolean = false;

    constructor(private _formBuilder: UntypedFormBuilder,
        private dialogRef: MatDialogRef<ForgotPasswordModal>,
        private toastr: ToastrService,
        @Inject(ApiService) private apiService: ApiService
    ) { }

    userNameInput = new FormControl('', [Validators.required]);
    ngOnInit(): void {
    }

    showError() {
        this.toastr.error(this.errorMessage, 'Error!');
    }

    sendMail() {
        if(this.userNameInput.valid){
            this.apiService.forgotPassword(this.userNameInput.value).subscribe(
                (response) => {
                    if (response.requestResult == 1){
                        this.toastr.success('Reset password link is sent to your registered email', 'Success!');
                        this.dialogRef.close();
                    }
                }, (error) => {
                   if(error.error.requestResult == 42){
                        this.toastr.error('User not found', 'Error!');
                   }else{
                       this.toastr.error('Something went wrong', 'Error!');
                   }
                }
            ); 
        }else{
            this.toastr.error('Please enter a valid username', 'Error!');
        }
    }

    onCancel(): void {
        this.dialogRef.close(null);
    }
}