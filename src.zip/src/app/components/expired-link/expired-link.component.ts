import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
    selector: 'app-link-expired',
    standalone: true,
    imports: [CommonModule],
    template: `
    <div class="expired-message">
      The link is expired
    </div>
  `,
    styles: [`
    .expired-message {
        min-height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 2rem;
        color: #0f172a;
        text-align: center;
        background-color: #f8f9fa;
    }
  `]
})
export class LinkExpiredComponent { }
