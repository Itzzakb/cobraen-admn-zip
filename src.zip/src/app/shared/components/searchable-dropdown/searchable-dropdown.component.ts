import { CommonModule} from "@angular/common";
import { Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation, inject, ViewChild } from "@angular/core";
import { FormsModule, ReactiveFormsModule, NgControl, NG_VALUE_ACCESSOR } from "@angular/forms";
import { MatButtonModule } from "@angular/material/button";
import { MatCheckboxModule } from "@angular/material/checkbox";
import { MatOptionModule, MatRippleModule } from "@angular/material/core";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatIconModule } from "@angular/material/icon";
import { MatInputModule } from "@angular/material/input";
import { MatSelect, MatSelectModule } from "@angular/material/select";
import { MatTooltipModule } from "@angular/material/tooltip";
import { fuseAnimations } from "@fuse/animations";

@Component({
    selector: 'app-searchable-dropdown',
    standalone: true,
    encapsulation: ViewEncapsulation.None,
    animations: fuseAnimations,
    imports: [
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        FormsModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatSelectModule,
        MatOptionModule,
        MatCheckboxModule,
        MatRippleModule,
        MatTooltipModule,
        CommonModule,
    ],
    templateUrl: './searchable-dropdown.component.html',
    styleUrls: ['./searchable-dropdown.component.scss'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: SearchableDropdownComponent,
            multi: true,
        },
    ],

})
export class SearchableDropdownComponent implements OnInit {
    @Input() options: any[] = [];
    @Input() isMulti: boolean = false;
    @Input() placeholder: string = '';
    @Input() label: string = '';
    @Input() isRequired: boolean = false;
    @Input() controlName: string = '';
    @Input() disabled: boolean = false;
    @Input() isError: boolean = false;

    @Output() selectionChange = new EventEmitter<any>();
    @Output() blurEvent = new EventEmitter<void>();
    @Output() focusEvent = new EventEmitter<void>();
    @ViewChild(MatSelect) matSelect: MatSelect;

    selectedData: any;

    searchText: string = '';

    value: any;
    isDisabled = false;
    filterEmpty: boolean = false;
    hideSelectAll: boolean = false;

    onChange = (value: any) => { };
    onTouched = () => { };

    public ngControl: NgControl | null = null;

    constructor() {
        try {
            this.ngControl = inject(NgControl);
            if (this.ngControl) {
                this.ngControl.valueAccessor = this;
                this.ngControl.control.value();
            }
        } catch (e) {
            this.ngControl = null;
        }
    }


    ngOnInit() {
        this.value = this.isMulti ? [] : null;
        this.populateDropDown();
    }

    writeValue(value: any): void {
        this.value = value;
    }

    registerOnChange(fn: any): void {
        this.onChange = fn;
    }

    registerOnTouched(fn: any): void {
        this.onTouched = fn;
    }

    setDisabledState(isDisabled: boolean): void {
        this.isDisabled = isDisabled;
    }

    populateDropDown() {
        //Not giving directly to this.searchText since that is updating search bar text as well to lower case!
        var search = this.searchText;
        search = search.toLowerCase();

        this.hideSelectAll = search ? true : this.options.length === 0 ? true : false;

        this.filterEmpty = true;

        this.reorderSelection();

        this.options.forEach((option) => {
            option.visible = (search ? option.name.toLowerCase().includes(search) : true);
            if (this.filterEmpty && option.visible) {
                this.filterEmpty = false;
            }
        });

    }

    reorderSelection() {
        if (!this.isMulti || !this.value) {
            return;
        };

        this.options.sort((a, b) => {
            const aIndex = this.value.indexOf(a.id);
            const bIndex = this.value.indexOf(b.id);

            if ((aIndex !== -1 && bIndex !== -1) || (aIndex === -1 && bIndex === -1)) {
                return a.name.localeCompare(b.name);
            }

            if (aIndex !== -1) {
                return -1;
            }

            if (bIndex !== -1) {
                return 1;
            }
        });
    }

    clearSearch() {
        this.searchText = '';
        this.populateDropDown();
        this.hideSelectAll = this.options.length === 0;
    }

    onSelect(option: any) {
        if (this.isMulti) {
            if(this.filterEmpty && option.includes(null)){
                return;
            }
            if (option.includes(null)) {
                this.toggleSelectAll();
            } 
        } else {
            this.value = option;
            this.matSelect.close();
        }
    
        this.onChange(this.value);
        this.selectionChange.emit(this.controlName);
    }
    
    
    getAllTheOptions() {
        let ids = [];
        this.options.forEach(option => ids.push(option.id));
        return ids;
    }

    toggleSelectAll() {
        if (this.isMulti) {
            this.value = this.value[0] == null ? this.value.slice(1) : this.value;
            this.value = this.value.length == this.options.length ? [] : this.getAllTheOptions();
        } else {
            this.value = null;
        }
    }

    onBlur(): void {
        this.onTouched();
        this.blurEvent.emit();
    }

    onFocus(): void {
        this.populateDropDown();
        this.focusEvent.emit();
    }
}
