import { CommonModule } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import {
    FormsModule,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormControl,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule, MatLabel } from '@angular/material/form-field';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { ApiService } from '@fuse/services/api-service.service';
import { ErrorMesageService } from 'app/shared/services/error-message.service';
import { ImageLibraryContent } from 'app/shared/types/interfaces';
import { ToastrService } from 'ngx-toastr';
import { InfiniteScrollDirective } from 'ngx-infinite-scroll';

@Component({
    selector: 'app-image-library',
    templateUrl: './image-library.component.html',
    styleUrl: './image-library.component.scss',
    standalone: true,
    imports: [
        MatDialogModule,
        MatButtonModule,
        MatLabel,
        MatFormFieldModule,
        FormsModule,
        ReactiveFormsModule,
        MatInputModule,
        MatIcon,
        MatIconModule,
        CommonModule,
        InfiniteScrollDirective
    ]
})
export class ImageLibraryDialog implements OnInit {
    imageLibraryContent: ImageLibraryContent[] = [];
    errorMessage: string = '';
    isSpinner: boolean = false;

    constructor(private _formBuilder: UntypedFormBuilder,
        private dialogRef: MatDialogRef<ImageLibraryDialog>,
        private apiService: ApiService,
        private toastr: ToastrService
    ) { }


    ngOnInit(): void {
        this.loadMoreImages();
    }

    showError() {
        this.toastr.error(this.errorMessage, 'Error!');
    }

currentPage = 1;
pageSize = 30;
hasMore = true;

loadMoreImages(): void {
    if (!this.hasMore || this.isSpinner) return;
  
    this.isSpinner = true;
  
    this.apiService.getImageLibraryContent(this.currentPage, this.pageSize).subscribe({
      next: (data) => {
        this.isSpinner = false;
  
        if (data.requestResult === 1 && data.result.length > 0) {
          this.imageLibraryContent.push(...data.result);
  
          if (data.result.length < this.pageSize) {
            this.hasMore = false;
          } else {
            this.currentPage++;
          }
  
          // Optional:
          // this.cdr.detectChanges();
        } else {
          this.hasMore = false;
        }
      },
      error: () => {
        this.isSpinner = false;
        this.hasMore = false;
        this.errorMessage = 'Unable to fetch the image library content.';
        this.showError();
      }
    });
  }
  


    onSelect(): void {
        this.dialogRef.close();  // Send form data back to parent

    }

    onCancel(): void {
        this.dialogRef.close(null);
    }
}