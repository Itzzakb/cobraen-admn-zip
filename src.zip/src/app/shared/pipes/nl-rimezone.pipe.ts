import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'nlTimezone',
  standalone: true // 👈 Add this line
})
export class NlTimezonePipe implements PipeTransform {

  transform(value: string | Date): string {
    if (!value) return '';

    const date = new Date(value);

    const options: Intl.DateTimeFormatOptions = {
      timeZone: 'Europe/Amsterdam',
      year: 'numeric',
      month: 'short',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    };

    return new Intl.DateTimeFormat('en-GB', options).format(date);
  }
}
