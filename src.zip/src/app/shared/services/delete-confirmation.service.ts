import { Injectable } from "@angular/core";
import { firstValueFrom } from "rxjs";
import { FuseConfirmationService } from "@fuse/services/confirmation";

@Injectable({ providedIn: 'root' })

export class DeleteConfirmationService {

    /**
     *ctor
     */
    constructor(private _fuseConfirmationService: FuseConfirmationService) { }

    async showDeleteConfirmation(item: string = 'Item', type: DeleteTypes = DeleteTypes.Item, customMessage: string = '', confirmBtnText: string = 'Delete'): Promise<boolean> {

        let message: string;
        let title: string = `${confirmBtnText} ${item}(s)`;

        switch (type) {
            case DeleteTypes.Video:
                title = 'Delete Video';
                message = 'Are you sure you want to remove this video?';
                break;
            case DeleteTypes.Custom: message = customMessage;
                break;
            case DeleteTypes.CustomNoTitle:
                message = customMessage;
                title = confirmBtnText;
                break;
            case DeleteTypes.ItemNoTitle:
                title = confirmBtnText;
                message = `Are you sure you want to remove this ${item}(s)? This action cannot be undone!`;
                break;
            case DeleteTypes.Item:
            default:
                message = `Are you sure you want to remove this ${item}(s)? This action cannot be undone!`;
        }

        const confirmation = this._fuseConfirmationService.open({
            title: title,
            message: message,
            actions: {
                confirm: {
                    label: confirmBtnText,
                },
            },
        });

        var result = await firstValueFrom(confirmation.afterClosed());

        return result === 'confirmed';
    }
}

export enum DeleteTypes {
    Item = 1,
    Video = 2,
    ItemNoTitle = 4,
    Custom = 8,
    CustomNoTitle = 16,
}