import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ErrorMesageService {

    getErrorMessage(responseType) {
        switch (responseType) {
          case 'Failure':
            return 'Operation failed.';
          case 'Success':
            return 'Operation successful.';
          case 'NotFound':
            return 'Resource not found.';
          case 'UnknownResponse':
            return 'Unknown response received.';
          case 'FoundUnauthorized':
            return 'Unauthorized access.';
          case 'InvalidCredentails':
            return 'Invalid credentials.';
          case 'InvalidEmail':
            return 'Invalid email address.';
          case 'InvalidUserName':
            return 'Invalid username.';
          case 'NameAlreadyExists':
            return 'Name already exists.';
          case 'ParentCategoryNotFound':
            return 'Parent category not found.';
          case 'FaqTypeNotFound':
            return 'FAQ type not found.';
          case 'BudgetOrFairBudgetIsRequired':
            return 'Budget or fair budget is required.';
          case 'AddressFieldsRequired':
            return 'Address fields are required.';
          case 'CouldNotDelete':
            return 'Could not delete the item.';
          case 'MissingMandatoryFields':
            return 'Missing mandatory fields.';
          case 'NoActiveSeasons':
            return 'No active seasons found.';
          case 'InvalidWebShopDates':
            return 'Invalid webshop dates.';
          case 'InvalidAppDates':
            return 'Invalid app dates.';
          case 'DeleteFailedForSomeDueToLinkedUsers':
            return 'Delete failed for some due to linked users.';
          case 'DeleteFailedForSomeDueToLinkedProducts':
            return 'Delete failed for some due to linked products.';
          case 'BrandingAlreadyExists':
            return 'Branding already exists.';
          case 'InvalidHeadingTransparency':
            return 'Invalid heading transparency value.';
          case 'InvalidBodyTransparency':
            return 'Invalid body transparency value.';
          case 'InvalidModuleTransparency':
            return 'Invalid module transparency value.';
          case 'AppLogoRequired':
            return 'App logo is required.';
          case 'AppQrImageRequired':
            return 'App QR image is required.';
          case 'OrganizationIdRequired':
            return 'Organization ID is required.';
          case 'PasswordNotValid':
            return 'Old and new passwords should not be the same.';
          case 'UserWishlistItemNotValid':
            return 'User wishlist item is not valid.';
          case 'DeleteFailedTimeSlotLinkedToEmployees':
            return 'Delete failed as timeslot is linked to employees.';
          case 'FulfillmentNotFound':
            return 'Fulfillment not found.';
          case 'FulfillmentError':
            return 'Error with fulfillment.';
          case 'UserWishlistItemAlreadyExists':
            return 'User wishlist item already exists.';
          case 'ThumbnailImageNotSelected':
            return 'Thumbnail image not selected.';
          case 'CantDeleteProductAslinkedToOrders':
            return 'Cannot delete product as it is linked to orders.';
          default:
            return 'An unexpected error occurred.';
        }
      }
}