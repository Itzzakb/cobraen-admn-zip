import { Injectable } from '@angular/core';
import { ApiService } from '@fuse/services/api-service.service';
import { 
    ExtraStock, 
    ExtraStockCreate, 
    ExtraStockDeliveryUpdate, 
    ExtraStockDetails, 
    ExtraStockUpdate 
} from 'app/shared/types/extra-stock.types';
import { BehaviorSubject, Observable, of, tap, catchError } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ExtraStockService {
    private _extraStocks: BehaviorSubject<ExtraStock[] | null> = new BehaviorSubject<ExtraStock[] | null>(null);
    private _extraStockDetails: BehaviorSubject<ExtraStockDetails | null> = new BehaviorSubject<ExtraStockDetails | null>(null);
    private _pagination: BehaviorSubject<any | null> = new BehaviorSubject<any | null>(null);

    constructor(private _apiService: ApiService) {}

    /**
     * Getters for observables
     */
    get extraStocks$(): Observable<ExtraStock[]> {
        return this._extraStocks.asObservable();
    }

    get extraStockDetails$(): Observable<ExtraStockDetails> {
        return this._extraStockDetails.asObservable();
    }

    get pagination$(): Observable<any> {
        return this._pagination.asObservable();
    }

    /**
     * Get extra stocks with pagination
     */
    getExtraStocks(pageIndex: number = 0, pageSize: number = 10, sortBy: string = 'id', 
                   sortOrder: 'asc' | 'desc' = 'asc', search: string = '', statusId?: number): Observable<any> {
        const params = {
            pageIndex,
            pageSize,
            sortBy,
            sortOrder,
            search,
            statusId
        };

        return this._apiService.getExtraStocks(params).pipe(
            tap((response) => {
                if (response && response.result) {
                    this._pagination.next({
                        length: response.result.count,
                        size: response.result.pageSize,
                        page: response.result.pageIndex
                    });
                    
                    // Set the extraStocks to the data array from the result
                    this._extraStocks.next(response.result.data || []);
                } else {
                    console.warn('Invalid or empty response from API', response);
                    this._extraStocks.next([]);
                }
            }),
            catchError(error => {
                console.error('Error in getExtraStocks:', error);
                this._extraStocks.next([]);
                return of({ result: { data: [], count: 0, pageSize: pageSize, pageIndex: pageIndex } });
            })
        );
    }

    /**
     * Get extra stock details by ID
     */
    getExtraStockDetails(id: number): Observable<any> {
        return this._apiService.getExtraStockDetails(id).pipe(
            tap((response) => {
                if (response && response.result) {
                    this._extraStockDetails.next(response.result);
                }
            }),
            catchError(error => {
                console.error('Error fetching extra stock details:', error);
                return of({ result: null });
            })
        );
    }

    /**
     * Create a new extra stock
     */
    createExtraStock(data: ExtraStockCreate): Observable<any> {
        return this._apiService.createExtraStock(data);
    }

    /**
     * Update an existing extra stock
     */
    updateExtraStock(data: ExtraStockUpdate): Observable<any> {
        return this._apiService.updateExtraStock(data);
    }

    /**
     * Update delivery status of an extra stock
     */
    updateDeliveryStatus(data: ExtraStockDeliveryUpdate): Observable<any> {
        return this._apiService.updateExtraStockDeliveryStatus(data);
    }

    /**
     * Search for products
     */
    searchProducts(pageIndex: number = 0, pageSize: number = 20, searchTerm: string = ''): Observable<any> {
        const params = {
            pageIndex,
            pageSize,
            search: searchTerm
        };

        return this._apiService.searchProducts(params).pipe(
            catchError(error => {
                console.error('Error searching products:', error);
                return of({ result: { data: [] } });
            })
        );
    }

    /**
     * Clear current extra stock details
     */
    clearExtraStockDetails(): void {
        this._extraStockDetails.next(null);
    }
}