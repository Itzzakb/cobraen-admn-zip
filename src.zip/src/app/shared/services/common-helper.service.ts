import { Injectable } from "@angular/core";
import { UntypedFormGroup } from "@angular/forms";
import { DateTime } from "luxon";

@Injectable({ providedIn: 'root' })
export class CommonHelperService {

  public static GenerateDate(date: any): string {
    if (date instanceof Date) {
      return CommonHelperService.GenerateISODateTimeStringFromDate(date);
    }
    return CommonHelperService.GenerateISODateTimeString(date,null);
  }

    public static GenerateISODateTimeStringFromDate(date: Date): string {     
        
        const day = date.getDate();
        const year = date.getFullYear();
        const month = date.getMonth() + 1;

        var resultDate = `${year}-${(month > 9 ? month : ('0' + month))}-${(day > 9 ? day : ('0' + day))}T00:00:00`;

        return resultDate;
    }

    /**
     * GenerateDateTime
     */
    public static GenerateISODateTimeString(date: string, time: string): string {
        if (!time) {
            time = '00:00';
        }
        return DateTime.fromISO(date).set({ hour: parseInt(time.split(':')[0]), minute: parseInt(time.split(':')[1]) }).toISO({ includeOffset: false });
    }

    /**
     * GetTimeStampFromDateTime
     */
    public static GetTimeStampFromDateTime(dateString: string): string {

        if (!dateString)
            return '';

        var date = DateTime.fromISO(dateString);
        return date.toFormat('HH:mm');
    }

    public static preserveId(form: UntypedFormGroup) : void {
        let property = form.getRawValue();
        
        // Reset the form
        form.reset({
            id: property.id,
        });

        // Optionally mark the form as touched to trigger validation messages
        if(property.id != 0){
            form.markAllAsTouched();
        }
    }

}
