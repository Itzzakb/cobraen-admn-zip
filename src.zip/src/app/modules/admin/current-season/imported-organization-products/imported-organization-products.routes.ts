import { Routes } from "@angular/router";
import { ImportedOrganizationProductsComponent } from "./imported-organization-products.component";

export default [
    {
        path: '',
        component: ImportedOrganizationProductsComponent
    }
] as Routes