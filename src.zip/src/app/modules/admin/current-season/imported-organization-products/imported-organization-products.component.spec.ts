import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportedOrganizationProductsComponent } from './imported-organization-products.component';

describe('ImportedOrganizationProductsComponent', () => {
  let component: ImportedOrganizationProductsComponent;
  let fixture: ComponentFixture<ImportedOrganizationProductsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ImportedOrganizationProductsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ImportedOrganizationProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
