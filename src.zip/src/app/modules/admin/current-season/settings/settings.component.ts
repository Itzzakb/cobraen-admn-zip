import {
  AsyncPipe,
  CommonModule,
  CurrencyPipe,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDatepickerModule } from '@angular/material/datepicker';

import {
  InventoryCategory,
  InventoryPagination,
  InventoryProduct,
  InventoryTag,
  InventoryVendor,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  takeUntil,
} from 'rxjs';
import { ChristmasFairList, ChrsitmasFairSetting, OrganizationList } from 'app/shared/types/interfaces';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { SearchableDropdownComponent } from 'app/shared/components/searchable-dropdown/searchable-dropdown.component';

@Component({
  selector: 'app-settings',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 1fr 50px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 1fr 50px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 1fr 50px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 1fr 50px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    MatTooltipModule,
    MatDatepickerModule,
    CommonModule,
    SearchableDropdownComponent
  ],
  templateUrl: './settings.component.html',
  styleUrl: './settings.component.scss',
})
export class SettingsComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  products$: Observable<InventoryProduct[]>;

  categories: InventoryCategory[];
  filteredTags: InventoryTag[];
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: InventoryPagination;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: ChrsitmasFairSetting | null = null;
  selectedProductForm: UntypedFormGroup;
  tags: InventoryTag[];
  tagsEditMode: boolean = false;
  vendors: InventoryVendor[];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  christmasFairSettingArray: ChrsitmasFairSetting[] = [];
  selectedChsreistmasFairSettings: Map<number, boolean> = new Map(); // Tracks selected brands
  allSelected: boolean = false;
  organizationList: OrganizationList[] = [];
  christmasFairList: ChristmasFairList[] = [];

  searchQuery: string = '';
  searchSubject = new Subject<string>();
  searchSubscription: any;

  // Pagination properties
  pageIndex: number = 0;
  pageSize: number = 10;
  totalCount: number = 0;
  sortOrder: number = 1;
  sortColumn: string = 'id';

  createchsreistmasFairSetting = false;
  selectedOrganizationId: number | null = null;
  selectedChristmasFairId: number | null = null;

  isDataLoaded: boolean = false;

  errorMessage = '';

  @ViewChild('headerPaginator') headerPaginator!: MatPaginator;
  @ViewChild('footerPaginator') footerPaginator!: MatPaginator;

  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _formBuilder: UntypedFormBuilder,
    private apiService: ApiService,
    private toastr: ToastrService,
  ) {}

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.selectedProductForm = this._formBuilder.group({
      id: [''],
      christmasFairId: [''],
      fairName: ['', [Validators.required]],
      organizationId: [''],
      organizationName: [''],
      type: ['', [Validators.required]],
      letOtherEmpShop: ['', [Validators.required]],
      letEmpChooseLocAndTime: ['', [Validators.required]],
      selfServiceUrl: ['', [Validators.required]],
      closingDate: ['']      
    });

     //get all organizations
        this.getAllOrganizations();

        // get all christmas fair settings
        this.getAllChristmasFairs();
    
        // Debounce search input to optimize API calls
        this.searchSubscription = this.searchSubject
          .pipe(debounceTime(300), distinctUntilChanged())
          .subscribe(query => {
            this.searchQuery = query;
            this.pageIndex = 0; // Reset to first page on new search
            this.footerPaginator.firstPage();
            this.getAllChrsitmasFairSettings();
          });
    
      }
    
    
  
    
    
      // get all christmas fair settings
      getAllChrsitmasFairSettings() {
        const params = {
          sortColumn: this.sortColumn,
          pageIndex: this.pageIndex,
          pageSize: this.pageSize,
          sortOrder: this.sortOrder,
          searchQuery: this.searchQuery,
          organizationId: this.selectedOrganizationId,
          christmasFairId: this.selectedChristmasFairId
        }
        this.apiService.getChristmasFairSettings(params).subscribe((data) => {
          this.christmasFairSettingArray = data.result.data;
          this.pageIndex = data.result.pageIndex;
          this.pageSize = data.result.pageSize;
          this.totalCount = data.result.count;
          this.isDataLoaded = true;
        }, 
      (error)=>{
        this.errorMessage = error.error.responseTip;
        this.showError();
      });
      }
    
      getAllOrganizations(){
        this.apiService.getAllOrganizations().subscribe((data)=>{
          this.organizationList = data.result;
        },
      (error)=>{
        this.errorMessage = error.error.responseTip;
        this.showError();
      })
      }
      getAllChristmasFairs(){
        this.apiService.getAllChristmasFairs().subscribe((data)=>{
          this.christmasFairList = data.result.data;
        },
      (error)=>{
        this.errorMessage = error.error.responseTip;
        this.showError();
      })
      }
    
      showSuccess(type: string) {
        const message = type == 'update' ? 'Christmas fair setting updated successfully.' : 'Christmas fair setting deleted successfully.';
        this.toastr.success(message, 'Success!');
      }
      showError() {
        this.toastr.error(this.errorMessage, 'Error!');
      }
    
      // Triggers a search operation with the provided query string.
      onSearch(query: string): void {
        this.createchsreistmasFairSetting = false;
        this.closeDetails();
        this.searchSubject.next(query);
      }
    
      // Handle pagination changes
      onPageChange(event: any): void {
        this.pageIndex = event.pageIndex;
        this.pageSize = event.pageSize;
        this.getAllChrsitmasFairSettings();
      }
    
      toggleCreateFaqForm() {
        this.createchsreistmasFairSetting = !this.createchsreistmasFairSetting;
        if (this.createchsreistmasFairSetting) {
          const newProduct = {
            id: 0,
            christmasFairId: 0,
            fairName: '',
            organizationId: null,
            organizationName: '',
            type: null,
            letOtherEmpShop: null,
            letEmpChooseLocAndTime: null,
            selfServiceUrl: '',
            closingDate: null
          }
          // Go to new product
          this.selectedProduct = newProduct;
    
          // Fill the form
          this.selectedProductForm.patchValue(newProduct);
    
          // Mark for check
          this._changeDetectorRef.markForCheck();
        } else {
          this.selectedProductForm.reset();
        }
      }
    
    
      updateChristmasFairSetting() {
        if(this.selectedProductForm.valid){
        const christmasFairSetting = this.selectedProductForm.getRawValue();
        const body ={
          "id": christmasFairSetting.id,
          "type": christmasFairSetting.type,
          "letOtherEmpShop": christmasFairSetting.letOtherEmpShop,
          "letEmpChooseLocAndTime": christmasFairSetting.letEmpChooseLocAndTime,
          "selfServiceUrl": christmasFairSetting.selfServiceUrl,
          "closingDate": christmasFairSetting.closingDate
        }
        
        this.apiService.updateChristmasFairSetting(body).subscribe((data) => {
          if(data.requestResult == 1){
            this.getAllChrsitmasFairSettings();
            this.resetForm();
            this.closeDetails();
            this.showSuccess('update');
          }else{
            this.errorMessage = data.responseTip;
            this.showError();
          }
        },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      });
      }else{
          this.selectedProductForm.markAllAsTouched();
          this.errorMessage = 'Please fill all the required fields';
          this.showError();
      }
    }

  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * After view init
   */
  ngAfterViewInit(): void {
    if (this._sort && this._paginator) {
      setTimeout(()=>{
        // Set the initial sort
      this._sort.sort({
        id: 'id',
        start: 'desc',
        disableClear: true,
      });
      })

      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;
          this.pageIndex = 0;

          //reset and close the form if it is open
          this.resetForm();
          this.closeDetails();

          // set the sort column and sort order
          this.sortColumn = this._sort.active;
          this.sortOrder = this._sort.direction === 'asc' ? 2 : 1;
          
          // Get the Brands
          this.getAllChrsitmasFairSettings();
        });

      
    }
  }



  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggle product details
   *
   * @param id
   */
  toggleDetails(id: number): void {
    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct.id === id) {
      // Close the details
      this.closeDetails();
      return;
    }

    const myMap = new Map(this.christmasFairSettingArray.map(obj => [obj.id, obj]));

    this.selectedProduct = myMap.get(id);
    this.selectedProductForm.patchValue(this.selectedProduct);
  }

  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
  }


  //reset the form
  resetForm(){
    this.selectedProductForm.reset();
  }

  

  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }
  
  onSelectionChange(value: any) {
    if(value && value !=''){
        this.selectedProductForm.get(value).markAsTouched();      
    }
  }
}
