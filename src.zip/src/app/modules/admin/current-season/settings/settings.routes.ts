import { SettingsComponent } from "./settings.component";

export default [
    {
        path: '',
        component: SettingsComponent
    }
]