import {
  AsyncPipe,
  CommonModule,
  CurrencyPipe,
  DatePipe,
  NgClass,
  NgIf,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import {
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule, Sort } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { FuseConfirmationService } from '@fuse/services/confirmation';


import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDatepickerModule } from '@angular/material/datepicker';

import {
  Observable,
  Subject,
  debounceTime,
  map,
  takeUntil,
  take,
  distinctUntilChanged} from 'rxjs';
import { OrderService } from 'app/shared/services/order.service';
import { BulkStatusUpdateDialogComponent } from './bulk-status-update-dialog.component';
import { DeleteConfirmationService, DeleteTypes } from 'app/shared/services/delete-confirmation.service';
import { SearchableDropdownComponent } from 'app/shared/components/searchable-dropdown/searchable-dropdown.component';

@Component({
  selector: 'app-orders',
  standalone: true,
  imports: [
    NgClass,
    NgTemplateOutlet,
    NgIf,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatRippleModule,
    MatSelectModule,
    MatSortModule,
    MatTooltipModule,
    MatDatepickerModule,
    MatDialogModule,
    AsyncPipe,
    CurrencyPipe,
    DatePipe,
    MatSlideToggleModule,
    MatOptionModule,
    CommonModule,
    SearchableDropdownComponent
  ],
  templateUrl: './orders.component.html',
  styleUrl: './orders.component.scss',
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 1fr 100px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 1fr 100px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 1fr 100px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 1fr 100px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: fuseAnimations
})
export class OrdersComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  orders$: Observable<any[]>;
  partners$: Observable<any[]>;
  partnersLoading$: Observable<boolean>;
  partnersComplete$: Observable<boolean>;
  partnersSearchControl: UntypedFormControl = new UntypedFormControl();
  
  budgetGroups$: Observable<any[]>;
  budgetGroupsLoading$: Observable<boolean>;
  budgetGroupsComplete$: Observable<boolean>;
  budgetGroupsSearchControl: UntypedFormControl = new UntypedFormControl();
  
  organizations$: Observable<any[]>;
  organizationsLoading$: Observable<boolean>;
  organizationsComplete$: Observable<boolean>;
  organizationsSearchControl: UntypedFormControl = new UntypedFormControl();
  
  users$: Observable<any[]>;
  formUsers$: Observable<any[]>;
  formUsers: any[];
  formUsersLoading$: Observable<boolean>;
  formUsersComplete$: Observable<boolean>;
  formUsersSearchControl: UntypedFormControl = new UntypedFormControl();
  usersLoading$: Observable<boolean>;
  usersComplete$: Observable<boolean>;
  usersSearchControl: UntypedFormControl = new UntypedFormControl();
  
  products$: Observable<any[]>;
  productsLoading$: Observable<boolean>;
  productsComplete$: Observable<boolean>;
  productsSearchControl: UntypedFormControl = new UntypedFormControl();
  
  statuses$: Observable<any[]>;

  filterForm: UntypedFormGroup;
  orderForm: UntypedFormGroup;
  
  // Temporary values until real dropdown data is loaded
  partners: any[] = [];
  budgetGroups: any[] = [];
  organizations: any[] = [];
  users: any[] = [];
  products: any[] = [];
  statuses: any[] = [];
  inExtraOrderOptions = [
    { id: null, name: 'All' },
    { id: true, name: 'Yes' },
    { id: false, name: 'No' }
  ];
  
  flashMessage: 'success' | 'error' | 'partial' | null = null;
  flashMessageText: string = null;
  isLoading: boolean = false;
  isCreateMode: boolean = false;
  pagination: any;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedOrder: any | null = null;
  selectedProductForm: UntypedFormGroup;
  
  private _filterValues: any = {};
  private _sortBy: string = 'id';
  private _sortOrder: number = 1; // Descending
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _deleteConfirmationService: DeleteConfirmationService,
    private _fuseConfirmationService: FuseConfirmationService,
    private _formBuilder: UntypedFormBuilder,
    private _orderService: OrderService,
    private _matDialog: MatDialog
  ) {
    // Initialize the filter form
    this.filterForm = this._formBuilder.group({
      partnerId: [null],
      budgetGroupId: [null],
      organizationId: [null],
      userId: [null],
      statusId: [null],
      inExtraOrder: [null]
    });
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form (for order row editing)
    this.selectedProductForm = this._formBuilder.group({
      id: [''],
      productId: [null, [Validators.required]],
      amount: ['', [Validators.required, Validators.min(1), Validators.pattern('^[0-9]*$')]],
      statusId: [null, [Validators.required]],
      remark: [''],
      inExtraOrder: [false]
    });
    
    // Clear validation errors on init so they don't show prematurely
    Object.keys(this.selectedProductForm.controls).forEach(key => {
      const control = this.selectedProductForm.get(key);
      control.setErrors(null);
      control.markAsPristine();
      control.markAsUntouched();
    });
    
    // Create the order form for editing main order properties
    this.orderForm = this._formBuilder.group({
      organizationId: [null, [Validators.required]],
      userId: [{value: null, disabled: true}, [Validators.required]],
      statusId: [null, [Validators.required]]
    });
    
    // Listen for organization changes to update user dropdown in edit form
    this.orderForm.get('organizationId').valueChanges
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe(organizationId => {
        const userControl = this.orderForm.get('userId');
        
        if (organizationId) {
          // Enable user dropdown
          userControl.enable();
          
          // Clear user selection
          userControl.setValue(null);
          
          // Load users for this organization (for the form)
          this._orderService.loadUsersByOrganization(organizationId, this.formUsersSearchControl.value || '', true).subscribe();
        } else {
          // Disable and clear user dropdown if no organization selected
          userControl.disable();
          userControl.setValue(null);
        }
      });
      
    // Load products regardless of organization
    this._orderService.loadMoreProducts(this.productsSearchControl.value || '').subscribe();

    // Initialize pagination with default values
    this.pagination = {
      length: 0,
      size: 10,
      page: 0
    };

    // Get the orders data from the order service
    this.orders$ = this._orderService.orders$;
    
    // Get the pagination
    this._orderService.pagination$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((pagination) => {
        // Update the pagination if value exists
        if (pagination) {
          this.pagination = pagination;
          // Mark for check
          this._changeDetectorRef.markForCheck();
        }
      });
      
    // Get dropdown data for filters
    this._orderService.loadDropdownData()
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe();
      
    // Set up observables for dropdowns
    this.partners$ = this._orderService.partners$;
    this.partnersLoading$ = this._orderService.partnersLoading$;
    this.partnersComplete$ = this._orderService.partnersComplete$;
    
    this.budgetGroups$ = this._orderService.budgetGroups$;
    this.budgetGroupsLoading$ = this._orderService.budgetGroupsLoading$;
    this.budgetGroupsComplete$ = this._orderService.budgetGroupsComplete$;
    
    this.organizations$ = this._orderService.organizations$;
    this.organizationsLoading$ = this._orderService.organizationsLoading$;
    this.organizationsComplete$ = this._orderService.organizationsComplete$;
    
    this.users$ = this._orderService.users$;
    this.formUsers$ = this._orderService.formUsers$;
    this.usersLoading$ = this._orderService.usersLoading$;
    this.usersComplete$ = this._orderService.usersComplete$;
    this.formUsersLoading$ = this._orderService.formUsersLoading$;
    this.formUsersComplete$ = this._orderService.formUsersComplete$;
    
    this.products$ = this._orderService.products$;
    this.productsLoading$ = this._orderService.productsLoading$;
    this.productsComplete$ = this._orderService.productsComplete$;
    
    this.statuses$ = this._orderService.statuses$;
    
    // Subscribe to data for the component properties
    this.partners$.pipe(takeUntil(this._unsubscribeAll))
      .subscribe(partners => {
        this.partners = partners;
        this._changeDetectorRef.markForCheck();
      });
      
    this.budgetGroups$.pipe(takeUntil(this._unsubscribeAll))
      .subscribe(budgetGroups => {
        this.budgetGroups = budgetGroups;
        this._changeDetectorRef.markForCheck();
      });
      
    this.organizations$.pipe(takeUntil(this._unsubscribeAll))
      .subscribe(organizations => {
        this.organizations = organizations;
        this._changeDetectorRef.markForCheck();
      });
      
    this.users$.pipe(takeUntil(this._unsubscribeAll))
      .subscribe(users => {
        this.users = users;
        this._changeDetectorRef.markForCheck();
      });
      
    // Create a separate array for form users
    this.formUsers$.pipe(takeUntil(this._unsubscribeAll))
      .subscribe(formUsers => {
        this.formUsers = formUsers;
        // Only update form users, don't touch the regular users array
        // This keeps the two dropdowns completely separate
        this._changeDetectorRef.markForCheck();
      });
      
    this.products$.pipe(takeUntil(this._unsubscribeAll))
      .subscribe(products => {
        this.products = products;
        this._changeDetectorRef.markForCheck();
      });
      
    this.statuses$.pipe(takeUntil(this._unsubscribeAll))
      .subscribe(statuses => {
        this.statuses = statuses;
        this._changeDetectorRef.markForCheck();
      });
      
    // Set up search control for partners dropdown
    this.partnersSearchControl.valueChanges
      .pipe(
        takeUntil(this._unsubscribeAll),
        debounceTime(300),
        distinctUntilChanged()
      )
      .subscribe(value => {
        this._orderService.loadMorePartners(value || '').subscribe();
      });
      
    // Set up search control for budget groups dropdown
    this.budgetGroupsSearchControl.valueChanges
      .pipe(
        takeUntil(this._unsubscribeAll),
        debounceTime(300),
        distinctUntilChanged()
      )
      .subscribe(value => {
        this._orderService.loadMoreBudgetGroups(value || '').subscribe();
      });
      
    // Set up search control for organizations dropdown
    this.organizationsSearchControl.valueChanges
      .pipe(
        takeUntil(this._unsubscribeAll),
        debounceTime(300),
        distinctUntilChanged()
      )
      .subscribe(value => {
        this._orderService.loadMoreOrganizations(value || '').subscribe();
      });
      
    // Set up search control for users dropdown in filter section
    this.usersSearchControl.valueChanges
      .pipe(
        takeUntil(this._unsubscribeAll),
        debounceTime(300),
        distinctUntilChanged()
      )
      .subscribe(value => {
        // Get the organization ID from the filter form
        const organizationId = this.filterForm.get('organizationId').value;
        
        if (organizationId) {
          // If organization is selected, filter users by that organization
          this._orderService.loadUsersByOrganization(organizationId, value || '', false).subscribe();
        } else {
          // Otherwise load all users matching the search
          this._orderService.loadMoreUsers(value || '').subscribe();
        }
      });
      
    // Set up search control for users dropdown in edit form
    this.formUsersSearchControl.valueChanges
      .pipe(
        takeUntil(this._unsubscribeAll),
        debounceTime(300),
        distinctUntilChanged()
      )
      .subscribe(value => {
        // Get the organization ID from the edit form
        const organizationId = this.orderForm.get('organizationId').value;
        
        if (organizationId) {
          // If organization is selected, load users for that organization with search
          this._orderService.loadMoreFormUsers(value || '', organizationId).subscribe();
        }
      });
      
    // Set up search control for products dropdown
    this.productsSearchControl.valueChanges
      .pipe(
        takeUntil(this._unsubscribeAll),
        debounceTime(300),
        distinctUntilChanged()
      )
      .subscribe(value => {
        // Always load all products with search, no longer filtering by organization
        this._orderService.loadMoreProducts(value || '').subscribe();
      });

    // Subscribe to organization changes in filter form
    this.filterForm.get('organizationId').valueChanges
      .pipe(
        takeUntil(this._unsubscribeAll),
        distinctUntilChanged()
      )
      .subscribe((organizationId) => {
        // Clear user selection when organization changes
        if (this.filterForm.get('userId').value) {
          this.filterForm.get('userId').setValue(null, { emitEvent: false });
        }
        
        // Load users for this organization if an organization is selected
        if (organizationId) {
          this._orderService.loadUsersByOrganization(organizationId, this.usersSearchControl.value || '', false).subscribe();
        } else {
          // If no organization selected, load all users
          this._orderService.loadMoreUsers(this.usersSearchControl.value || '').subscribe();
        }
      });

    // Subscribe to filter form value changes
    this.filterForm.valueChanges
      .pipe(
        takeUntil(this._unsubscribeAll),
        debounceTime(300)
      )
      .subscribe((value) => {
        // Update the filter values
        this._filterValues = {};
        
        // Only add defined values to the filter
        if (value.partnerId) this._filterValues.partnerId = value.partnerId;
        if (value.budgetGroupId) this._filterValues.budgetGroupId = value.budgetGroupId;
        if (value.organizationId) this._filterValues.organizationId = value.organizationId;
        if (value.userId) this._filterValues.userId = value.userId;
        if (value.statusId) this._filterValues.statusId = value.statusId;
        if (value.inExtraOrder !== null) this._filterValues.inExtraOrder = value.inExtraOrder;

        // Reset back to the first page
        if (this._paginator) {
          this._paginator.pageIndex = 0;
        }
        
        // Get orders with the new filters
        this.loadOrdersWithCurrentSettings();
      });

    // Subscribe to search input field value changes
    this.searchInputControl.valueChanges
      .pipe(
        takeUntil(this._unsubscribeAll),
        debounceTime(300)
      )
      .subscribe((search) => {
        // Close details if open
        this.closeDetails();
        
        // Reset to the first page
        if (this._paginator) {
          this._paginator.pageIndex = 0;
        }
        
        // Get orders with the search term
        this.loadOrdersWithCurrentSettings();
      });
    
    // Initial data load with explicit parameters
    this.isLoading = true;
    this._orderService.getOrders(0, 10, 'id', 1).subscribe({
      next: () => {
        this.isLoading = false;
        this._changeDetectorRef.detectChanges();
      },
      error: (error) => {
        this.isLoading = false;
        this.isLoading = false;
        this._changeDetectorRef.detectChanges();
      }
    });
  }

;

  /**
   * After view init
   */
  ngAfterViewInit(): void {
    if (this._sort && this._paginator) {
      // Set the initial sort
      this._sort.sort({
        id: 'id',
        start: 'desc',
        disableClear: true,
      });

      // Store the sort info
      this._sortBy = this._sort.active;
      this._sortOrder = this._sort.direction === 'desc' ? 
        this._orderService['_apiService'].sortOrder.DESCENDING : 
        this._orderService['_apiService'].sortOrder.ASCENDING;

      // Use detectChanges to ensure changes are applied immediately
      this._changeDetectorRef.detectChanges();
      
      // Load initial data with sort and pagination parameters
      this.loadOrdersWithCurrentSettings();
    }
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Handle page event from paginator
   */
  onPageChange(event: PageEvent): void {
    if (this._paginator) {
      this._paginator.pageIndex = event.pageIndex;
      this._paginator.pageSize = event.pageSize;
    }
    
    // Close detail view if open
    this.closeDetails();
    
    // Load data with new pagination settings
    this.loadOrdersWithCurrentSettings();
  }

  /**
   * Handle sort change event
   */
  onSortChange(event: Sort): void {
    // Update the sort properties
    this._sortBy = event.active;
    this._sortOrder = event.direction === 'desc' ? 
      this._orderService['_apiService'].sortOrder.DESCENDING : 
      this._orderService['_apiService'].sortOrder.ASCENDING;
    
    // Reset back to the first page
    if (this._paginator) {
      this._paginator.pageIndex = 0;
    }
    
    // Close the details if open
    this.closeDetails();
    
    // Load data with new sort settings
    this.loadOrdersWithCurrentSettings();
  }
  
  /**
   * Load orders with current paginator, sort, and search settings
   */
  loadOrdersWithCurrentSettings(): void {
    this.isLoading = true;
    
    // Get current pagination and sort settings
    const pageIndex = this._paginator ? this._paginator.pageIndex : 0;
    const pageSize = this._paginator ? this._paginator.pageSize : 10;
    const sortBy = this._sort && this._sort.active ? this._sort.active.toLowerCase() : 'id';
    const sortOrder = this._sort && this._sort.direction === 'desc' ? 
      this._orderService['_apiService'].sortOrder.DESCENDING : 
      this._orderService['_apiService'].sortOrder.ASCENDING;
    
    // Call service to get orders with current settings
    this._orderService.getOrders(
      pageIndex,
      pageSize,
      sortBy,
      sortOrder,
      this.searchInputControl.value || '',
      this._filterValues
    ).subscribe({
      next: () => {
        this.isLoading = false;
        this._changeDetectorRef.detectChanges();
      },
      error: (error) => {
        this.isLoading = false;
        this.isLoading = false;
        this._changeDetectorRef.detectChanges();
      }
    });
  }

  /**
   * Toggle order details
   *
   * @param orderId
   */
  toggleDetails(orderId: number): void {
    this.isCreateMode = false;
    // If the order is already selected...
    if (this.selectedOrder && this.selectedOrder.id === orderId) {
      // Close the details
      this.closeDetails();
      return;
    }
    
    // Reset the product form with clear validation
    this.selectedProductForm.reset();
    Object.keys(this.selectedProductForm.controls).forEach(key => {
      const control = this.selectedProductForm.get(key);
      control.setErrors(null);
      control.markAsPristine();
      control.markAsUntouched();
    });

    // Find the order in the current orders list
    this.orders$.pipe(
      take(1),
      map(orders => {
        const orderArray = orders as any[];
        return orderArray.find(order => order.id === orderId);
      })
    ).subscribe((order) => {
      if (order) {
        // Set the selected order
        this.selectedOrder = order;
        
        
        
        // First, ensure we have necessary IDs - extract from somewhere if not directly available
        // The organization may not be available as an ID, so we might need to look it up
        // Let's examine what order data we have to work with
        
        // If we don't have organizationId directly, we might need to find it
        const organizationId = order.organizationId || null;
        const userId = order.userId || null;
        const statusId = order.orderStatus || null;
        
        if (organizationId) {
        // Check if the organization is already in the list
        const organizationExists = this.organizations.some(org => org.id === organizationId);
        if (!organizationExists) {
        // If organization is not in the list, add a placeholder
        const placeholderOrg = { 
        id: organizationId, 
        name: order.organizationName || 'Organization ' + organizationId 
        };
        this.organizations = [...this.organizations, placeholderOrg];
        }
          
          // Load the users for this organization (specifically for the form)
          this._orderService.loadUsersByOrganization(organizationId, '', true).subscribe();
        }
        
        // If we have a user ID but haven't loaded form users yet, create a placeholder
        if (userId) {
        // We need to add this user to the formUsers observable
        this._orderService['_formUsers'].next([{
        id: userId,
        name: order.username || 'User ' + userId
        }]);
        }
        
        // Now set form values with what we have
        this.orderForm.patchValue({
          organizationId: organizationId,
          userId: userId,
          statusId: statusId
        });
        
        

        // Mark for check
        this._changeDetectorRef.markForCheck();
      }
    });
  }

  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedOrder = null;
    this.isCreateMode = false;
    this.selectedProductForm.reset();
    Object.keys(this.selectedProductForm.controls).forEach(key => {
      const control = this.selectedProductForm.get(key);
      control.setErrors(null);
      control.markAsPristine();
      control.markAsUntouched();
    });

    // Reset the order form
    this.orderForm.reset();
  }

  // clear details
  clearDetails(){
    this.selectedOrder.orderRows = [];
     
    // Reset the product form with clear validation
    this.selectedProductForm.reset();
    Object.keys(this.selectedProductForm.controls).forEach(key => {
      const control = this.selectedProductForm.get(key);
      control.setErrors(null);
      control.markAsPristine();
      control.markAsUntouched();
    });

    // Reset the order form
    this.orderForm.reset();
  }
  
  /**
   * Toggle create order form
   */
  createNewOrder(): void {
    // If already in create mode, close it
    if (this.isCreateMode) {
      this.closeDetails();
      return;
    }
    
    // Otherwise, open the create form
    this.closeDetails(); // First close any open details
    this.isCreateMode = true;
    this.resetForm();
    
    // Make sure dropdowns are loaded
    if (!this.organizations || this.organizations.length === 0) {
      this._orderService.loadMoreOrganizations().subscribe();
    }
    
    if (!this.statuses || this.statuses.length === 0) {
      // Make sure we have statuses loaded
      this._orderService.loadDropdownData().subscribe();
    }
    
    // Do NOT mark form controls as touched to avoid premature validation
    // Validation will only trigger after user interaction
    
    this._changeDetectorRef.markForCheck();
  }
  
  /**
   * Reset the form for a new order
   */
  resetForm(): void {
    // Reset forms with default values
    this.orderForm.reset({
      organizationId: null,
      userId: null,
      statusId: 1 // Default to "New" status
    });
    
    this.selectedProductForm.reset({
      id: '',
      productId: null,
      amount: '',
      statusId: 1, // Default to "New" status
      remark: '',
      inExtraOrder: false
    });
    
    // Reset all form controls to pristine and untouched to prevent premature validation
    Object.keys(this.orderForm.controls).forEach(key => {
      const control = this.orderForm.get(key);
      control.setErrors(null);
      control.markAsPristine();
      control.markAsUntouched();
    });
    
    // Also reset the product form controls
    Object.keys(this.selectedProductForm.controls).forEach(key => {
      const control = this.selectedProductForm.get(key);
      control.setErrors(null);
      control.markAsPristine();
      control.markAsUntouched();
    });
    
    // Create a blank order object for new orders
    if (this.isCreateMode) {
      this.selectedOrder = {
        id: 0,
        orderRows: [],
        orderStatus: 1,
        statusName: 'New',
        orderTotalPrice: 0,
        userId: null,
        username: '',
        name: '',
        organizationId: null,
        organizationName: '',
        lastDelayedDeliveryDate: null
      };
    }
  }



  /**
   * Update the selected product using the form data
   */
  updateSelectedProduct(): void {
    if (this.selectedProductForm.invalid) {
      // Mark form controls as touched to show validation errors
      this.selectedProductForm.markAllAsTouched();
      return;
    }
    
    if (!this.selectedOrder) {
      return;
    }
    
    const formValues = this.selectedProductForm.value;
    
    // Get the selected product details from the products array
    const selectedProduct = this.products.find(p => p.id === formValues.productId);
    
    if (!selectedProduct) {
      return;
    }
    
    // Calculate total price
    const amount = Number(formValues.amount);
    const pricePerUnit = selectedProduct.dukatenExc || 0;
    const totalPrice = amount * pricePerUnit;
    
    // Create or update order row
    const orderRow = {
      id: formValues.id || null,
      productId: formValues.productId,
      productName: selectedProduct.name,
      amount: amount,
      dukatenExc: selectedProduct.dukatenExc,
      dukatenInc: selectedProduct.dukatenInc,
      totalPrice: totalPrice,
      remark: formValues.remark || '',
      inExtraOrder: formValues.inExtraOrder || false,
      statusId: formValues.statusId,
      statusName: this.statuses.find(s => s.id === formValues.statusId)?.name || '',
      importId: selectedProduct.importId || ''
    };
    
    // If editing existing row, update it
    if (formValues.id) {
      const rowIndex = this.selectedOrder.orderRows.findIndex(row => row.id === formValues.id);
      if (rowIndex !== -1) {
        this.selectedOrder.orderRows[rowIndex] = {...orderRow};
      }
    } else {
      // For new rows, generate a temporary negative ID (will be replaced by server on save)
      orderRow.id = this.getNextTemporaryId();
      
      // If orderRows array doesn't exist, create it
      if (!this.selectedOrder.orderRows) {
        this.selectedOrder.orderRows = [];
      }
      
      this.selectedOrder.orderRows.push(orderRow);
    }
    
    // Recalculate order total
    this.recalculateOrderTotal();
    
    // Reset form for next entry with default values
    this.selectedProductForm.reset({
      id: '',
      productId: null,
      amount: '',
      statusId: 1, // Default to "New" status
      remark: '',
      inExtraOrder: false
    });
    
    // Only reset pristine/touched state, don't clear errors
    Object.keys(this.selectedProductForm.controls).forEach(key => {
      const control = this.selectedProductForm.get(key);
      control.markAsPristine();
      control.markAsUntouched();
    });
    
    // Show success message
    this.showFlashMessage('success');
    
    // Mark for changes
    this._changeDetectorRef.markForCheck();
  }
  
  /**
   * Update the order using the order form data
   */
  updateOrder(): void {
    if (this.orderForm.invalid) {
      return;
    }
    
    if (!this.selectedOrder) {
      return;
    }
    
    const orderFormValues = this.orderForm.value;
    
    // Build the order update/create model based on mode
    if (this.isCreateMode) {
      // Create model
      const orderCreateModel = {
        userId: orderFormValues.userId,
        orderStatus: orderFormValues.statusId,
        lastDelayedDeliveryDate: null, // Will be set by server
        orderRows: this.selectedOrder.orderRows.map(row => ({
          productId: row.productId,
          amount: row.amount,
          statusId: row.statusId,
          remark: row.remark || '',
          inExtraOrder: row.inExtraOrder || false,
          giftSetId: row.giftSetId
        }))
      };
      
      // Call the API to create the order
      this.isLoading = true;
      this._orderService.createOrder(orderCreateModel).subscribe({
        next: (response) => {
          this.isLoading = false;
          this.showFlashMessage('success');
          this.closeDetails();
          this._getOrders(this.searchInputControl.value);
        },
        error: (error) => {
          
          this.isLoading = false;
          this.showFlashMessage('error', (error.error && error.error.requestResult == 46 ? 'Product exceeding stock!' : null));
          this._changeDetectorRef.markForCheck();
        }
      });
    } else {
      // Update model
      const orderUpdateModel = {
        orderId: this.selectedOrder.id,
        userId: orderFormValues.userId,
        orderStatus: orderFormValues.statusId,
        lastDelayedDeliveryDate: this.selectedOrder.lastDelayedDeliveryDate,
        orderRows: this.selectedOrder.orderRows.map(row => ({
          id: row.id > 0 ? row.id : null, // Only include positive IDs (server-generated)
          productId: row.productId,
          amount: row.amount,
          statusId: row.statusId,
          remark: row.remark,
          inExtraOrder: row.inExtraOrder,
          giftSetId: row.giftSetId
        }))
      };
      
      // Call the API to update the order
      this.isLoading = true;
      this._orderService.updateOrder(orderUpdateModel).subscribe({
        next: (response) => {
          this.isLoading = false;
          this.showFlashMessage('success');
          this.closeDetails();
          this._getOrders(this.searchInputControl.value);
        },
        error: (error) => {
          
          this.isLoading = false;
          this.showFlashMessage('error', (error.error && error.error.requestResult == 46 ? 'Product exceeding stock!' : null));
          this._changeDetectorRef.markForCheck();
        }
      });
    }
  }

  /**
   * Delete the selected order
   */
  async deleteSelectedProduct(): Promise<void> {
    if (!this.selectedOrder) {
      return;
    }

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Order');

    if (confirmed) {
      // Delete the order on the server
      this._orderService.deleteOrders([this.selectedOrder.id]).subscribe(() => {
        // Show a success message
        this.showFlashMessage('success', 'Order deleted successfully!');

        // Close the details
        this.closeDetails();

        // Refresh the orders list
        this._getOrders(this.searchInputControl.value);
      });
    }
  }

  /**
   * Show flash message
   * @param type Type of message to show (success, error, or partial)
   * @param message Optional custom message to display
   */
  showFlashMessage(type: 'success' | 'error' | 'partial', message?: string): void {
    // Show the message
    this.flashMessage = type;
    
    // Store custom message if provided
    if (message) {
      this.flashMessageText = message;
    } else {
      // Default messages
      switch (type) {
        case 'success':
          this.flashMessageText = this.isCreateMode ? 'Order created successfully' : 'Order updated successfully';
          break;
        case 'error':
          this.flashMessageText = 'An error occurred, please try again!';
          break;
        case 'partial':
          this.flashMessageText = 'Operation completed with some issues';
          break;
      }
    }

    // Mark for check
    this._changeDetectorRef.markForCheck();

    // Hide it after 3 seconds
    setTimeout(() => {
      this.flashMessage = null;
      this.flashMessageText = null;

      // Mark for check
      this._changeDetectorRef.markForCheck();
    }, 3000);
  }

  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }

  /**
   * Private method to get orders with filtering, sorting, and pagination
   * 
   * @param search Optional search query
   */
  private _getOrders(search: string = ''): void {
    this.isLoading = true;
    
    // Get page and sort settings
    const pageIndex = this._paginator ? this._paginator.pageIndex : 0;
    const pageSize = this._paginator ? this._paginator.pageSize : 10;
    const sortBy = this._sort && this._sort.active ? this._sort.active.toLowerCase() : this._sortBy || 'id';
    
    // Ensure sortOrder is always valid (1 for descending, 2 for ascending)
    let sortOrder;
    if (this._sort && this._sort.direction) {
      sortOrder = this._sort.direction === 'desc' ? 
        this._orderService['_apiService'].sortOrder.DESCENDING : 
        this._orderService['_apiService'].sortOrder.ASCENDING;
    } else {
      sortOrder = this._sortOrder || this._orderService['_apiService'].sortOrder.DESCENDING;
    }
    
    // Call the service to get orders
    this._orderService.getOrders(
      pageIndex,
      pageSize,
      sortBy,
      sortOrder,
      search,
      this._filterValues
    ).subscribe({
      next: () => {
        this.isLoading = false;
        this._changeDetectorRef.detectChanges();
      },
      error: (error) => {
        console.error('Error loading orders:', error);
        this.isLoading = false;
        this._changeDetectorRef.detectChanges();
      }
    });
  }

  // Temporary negative ID counter for new order rows
  private _tempIdCounter = -1;
  
  /**
   * Gets the next temporary ID for a new order row
   */
  getNextTemporaryId(): number {
    return this._tempIdCounter--;
  }
  
  /**
   * Recalculates the total price of the selected order
   */
  recalculateOrderTotal(): void {
    if (!this.selectedOrder || !this.selectedOrder.orderRows) {
      return;
    }
    
    // Sum up the total price of all order rows that are not cancelled (status 2)
    let total = 0;
    for (const row of this.selectedOrder.orderRows) {
      if (row.statusId !== 2) { // assuming status 2 is 'Cancelled'
        total += row.totalPrice;
      }
    }
    
    this.selectedOrder.orderTotalPrice = total;
  }
  
  /**
   * Delete an order row
   * @param rowId The ID of the row to delete
   */
  /**
   * Edit an existing order row
   * @param row The row to edit
   */
  editOrderRow(row: any): void {
    if (!row) {
      return;
    }
    
    // Clear form and validation errors first
    this.selectedProductForm.reset();
    Object.keys(this.selectedProductForm.controls).forEach(key => {
      const control = this.selectedProductForm.get(key);
      control.setErrors(null);
      control.markAsPristine();
      control.markAsUntouched();
    });
    
    // Then load row data into form
    this.selectedProductForm.patchValue({
      id: row.id,
      productId: row.productId,
      amount: row.amount,
      statusId: row.statusId,
      remark: row.remark,
      inExtraOrder: row.inExtraOrder
    });
    
    // Scroll to the form for better UX
    setTimeout(() => {
      const formElement = document.querySelector('.grid.items-center.gap-4.border-b.px-5.py-3:last-child');
      if (formElement) {
        formElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 100);
  }
  
  /**
   * Update the status of an order row and recalculate totals
   * @param row The row being updated
   */
  updateRowStatus(row: any): void {
    if (!row) {
      return;
    }
    
    // Update the status name for display
    const status = this.statuses.find(s => s.id === row.statusId);
    if (status) {
      row.statusName = status.name;
    }
    
    // Recalculate order total since cancelled items affect the total
    this.recalculateOrderTotal();
    
    // Mark for check
    this._changeDetectorRef.markForCheck();
  }
  
  async deleteOrderRow(rowId: number): Promise<void> {
    if (!this.selectedOrder || !this.selectedOrder.orderRows) {
      return;
    }

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Order Row');

    if (!confirmed) {
      return;
    }

    // Find the index of the row to delete
    const rowIndex = this.selectedOrder.orderRows.findIndex(row => row.id === rowId);

    if (rowIndex === -1) {
      return;
    }

    // Remove the row
    this.selectedOrder.orderRows.splice(rowIndex, 1);

    this.recalculateOrderTotal();

    this.showFlashMessage('success');

    // Mark for check
    this._changeDetectorRef.markForCheck();
  }

  multiDeleteDisable = true;
  checkAll: boolean;

  toggleCheckAll() {
    this.multiDeleteDisable = !this.multiDeleteDisable;
    if (this.checkAll) {
      if(this.orders$) {
        this.orders$.pipe(take(1)).subscribe(orders => {
          const orderArray = orders as any[];
          orderArray.forEach((order) => {
            this.checkedItems.push(order.id);
          });
        });
      }
    } else {
      this.checkedItems = [];
    }
  }

  checkedItems = [];

  checked(orderId: number) {
    if (this.checkedItems.includes(orderId)) {
      this.checkedItems = this.checkedItems.filter(id => id !== orderId);
    } else {
      this.checkedItems.push(orderId);
    }
    
    // Update checkAll based on whether all visible items are checked
    this.orders$.pipe(
      take(1)
    ).subscribe(orders => {
      const orderArray = orders as any[];
      this.checkAll = orderArray.length > 0 && 
        orderArray.every(order => this.checkedItems.includes(order.id));
    });
  }
  
  /**
   * Bulk update order status
   */
  bulkUpdateStatus(): void {
    if (this.checkedItems.length === 0) {
      return;
    }
    
    // Open the bulk status update dialog
    const dialogRef = this._matDialog.open(BulkStatusUpdateDialogComponent, {
      width: '400px',
      data: {
        orderIds: this.checkedItems,
        statuses: this.statuses
      },
      disableClose: true
    });

    // Subscribe to dialog closed action
    dialogRef.afterClosed().subscribe((statusId) => {
      // If the user selected a status and clicked Update
      if (statusId) {
        this.isLoading = true;
        
        // Call the service to update the status
        this._orderService.bulkUpdateStatus(this.checkedItems, statusId).subscribe({
          next: () => {
            // Show a success message
            this.showFlashMessage('success');
            
            // Refresh the orders list
            this._getOrders(this.searchInputControl.value);
            
            // Clear selection
            this.checkedItems = [];
            this.checkAll = false;
            this.isLoading = false;
            this._changeDetectorRef.markForCheck();
          },
          error: (error) => {
            
            this.isLoading = false;
            this.showFlashMessage('error');
            this._changeDetectorRef.markForCheck();
          }
        });
      }
    });
  }
  
  /**
   * Send selected orders to fulfillment
   */
  async sendToFulfillment(): Promise<void> {
    if (this.checkedItems.length === 0) {
      return;
    }
    
    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Send to Fulfillment',DeleteTypes.Custom, `Are you sure you want to send ${this.checkedItems.length} selected orders to fulfillment?`, 'Send');

    if(!confirmed) {
      return;
    }

    // Show loading indicator
    this.isLoading = true;

    // Call the service to send orders to fulfillment
    this._orderService.sendToFulfillment(this.checkedItems).subscribe({
      next: (response) => {
        // Hide loading indicator
        this.isLoading = false;

        if (response.success) {
          // Show a success message
          this.showFlashMessage('success', 'Orders sent to fulfillment successfully');
        } else {
          // Check if there are partial successes
          if (response.items && response.items.some(item => item.success)) {
            this.showFlashMessage('partial', 'Some orders were sent to fulfillment. See details for more information.');
          } else {
            // Show error message
            this.showFlashMessage('error', response.errorMessage || 'Failed to send orders to fulfillment');
          }

          // If we have detailed error information, show it
          if (response.items && response.items.some(item => !item.success)) {
            const failedItems = response.items.filter(item => !item.success);
            console.error('Failed items:', failedItems);

            // Show detailed error dialog for failed items
            this._fuseConfirmationService.open({
              title: 'Fulfillment Issues',
              message: this._formatFulfillmentErrors(failedItems),
              actions: {
                confirm: {
                  label: 'OK',
                  color: 'primary'
                },
                cancel: {
                  show: false
                }
              },
              dismissible: true
            });
          }
        }

        // Refresh the orders list
        this._getOrders(this.searchInputControl.value);

        // Clear selection
        this.checkedItems = [];
        this.checkAll = false;
      },
      error: (error) => {
        // Hide loading indicator
        this.isLoading = false;

        // Show error message
        console.error('Fulfillment error:', error);
        this.showFlashMessage('error', 'An error occurred while sending orders to fulfillment');
      }
    });

  }
  
  /**
   * Format fulfillment errors for display
   * @param failedItems Array of failed fulfillment items
   * @returns Formatted HTML string with error details
   */
  private _formatFulfillmentErrors(failedItems: any[]): string {
    if (!failedItems || failedItems.length === 0) {
      return 'Unknown error occurred during fulfillment.';
    }
    
    let message = 'The following orders could not be sent to fulfillment:<br><br>';
    message += '<ul>';
    
    failedItems.forEach(item => {
      message += `<li>Order #${item.orderId}: ${item.message || 'Unknown error'}</li>`;
    });
    
    message += '</ul><br>';
    message += 'Please check that all products exist in the fulfillment system and have sufficient stock.';
    
    return message;
  }
  
  /**
   * Delete selected orders in bulk
   */
  async deleteSelectedOrders(): Promise<void> {
    if (this.checkedItems.length === 0) {
      return;
    }

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Delete Selected Orders',
      DeleteTypes.Custom,
      `Are you sure you want to delete ${this.checkedItems.length} selected orders? This action cannot be undone!`);

    // Subscribe to the confirmation dialog closed action
    if (!confirmed) {
      return;
    }

    this.isLoading = true;

    // Call the service to delete the selected orders
    this._orderService.deleteOrders(this.checkedItems).subscribe({
      next: () => {
        // Show a success message
        this.showFlashMessage('success');

        // Close the details view if one of the deleted orders was selected
        if (this.selectedOrder && this.checkedItems.includes(this.selectedOrder.id)) {
          this.closeDetails();
        }

        // Refresh the orders list
        this._getOrders(this.searchInputControl.value);

        // Clear selection
        this.checkedItems = [];
        this.checkAll = false;
        this.isLoading = false;
        this._changeDetectorRef.markForCheck();
      },
      error: (error) => {

        this.isLoading = false;
        this.showFlashMessage('error');
        this._changeDetectorRef.markForCheck();
      }
    });
  }
  
  // Track when we've truly reached the end of data for each dropdown type
  private _noMoreData = {
    partners: false,
    budgetGroups: false,
    organizations: false,
    users: false,
    formUsers: false,
    products: false
  };
  
  /**
   * Called when a dropdown is opened
   * Resets tracking state and attaches a scroll listener to load more items
   */
  onDropdownOpened(dropdownType: string): void {
    
    
    // Reset tracking state for this dropdown
    this._noMoreData[dropdownType] = false;
    
    // Reset loading and complete state to ensure we can load more
    switch (dropdownType) {
      case 'partners':
        // Reset the partners loading and complete flags
        this._orderService['_partnersLoading'].next(false);
        this._orderService['_partnersComplete'].next(false);
        break;
      case 'budgetGroups':
        // Reset the budget groups loading and complete flags
        this._orderService['_budgetGroupsLoading'].next(false);
        this._orderService['_budgetGroupsComplete'].next(false);
        break;
      case 'organizations':
        this.formUsers = [];
        // Reset the organizations loading and complete flags
        this._orderService['_organizationsLoading'].next(false);
        this._orderService['_organizationsComplete'].next(false);
        break;
      case 'users':
        // Reset the users loading and complete flags
        this._orderService['_usersLoading'].next(false);
        this._orderService['_usersComplete'].next(false);
        break;
      case 'formUsers':
        // Reset the form users loading and complete flags
        this._orderService['_formUsersLoading'].next(false);
        this._orderService['_formUsersComplete'].next(false);
        break;
      case 'products':
        // Reset the products loading and complete flags
        this._orderService['_productsLoading'].next(false);
        this._orderService['_productsComplete'].next(false);
        break;
    }
    //Pagination logic for dropdowns not used anymore!
    // // Use setTimeout to ensure the panel is rendered in the DOM
    // setTimeout(() => {
    //   // Try the specific selector first - normally this is .mat-select-panel
    //   const panel = document.querySelector('.mat-select-panel, .mat-mdc-select-panel');
      
    //   if (panel) {
        
        
    //     // Add scroll event listener to the panel
    //     panel.addEventListener('scroll', () => {
    //       // Get the elements that should be used for scroll calculations
    //       const panelElement = panel as HTMLElement;
          
    //       // Check if user scrolled to the bottom (with a small buffer)
    //       const isAtBottom = panelElement.scrollTop + panelElement.clientHeight >= panelElement.scrollHeight - 5;
          
    //       if (isAtBottom && !this._noMoreData[dropdownType]) {
            
            
    //         // Call the appropriate method to load more items
    //         switch (dropdownType) {
    //           case 'partners':
                
    //             // Force states to ensure the service loads more data
    //             this._orderService['_partnersLoading'].next(false);
    //             this._orderService['_partnersComplete'].next(false);
    //             this._orderService['_partnersPage']++;
                
    //             // Store current length to check if new data is loaded
    //             const currentPartnersLength = this._orderService['_partners'].value.length;
                
    //             this._orderService.loadMorePartners(this.partnersSearchControl.value || '').subscribe({
    //               next: () => {
    //                 // Check if any new data was added
    //                 const newLength = this._orderService['_partners'].value.length;
    //                 if (newLength <= currentPartnersLength) {
                      
    //                   this._noMoreData.partners = true;
    //                 }
    //               }
    //             });
    //             break;
                
    //           case 'budgetGroups':
                
    //             // Force states to ensure the service loads more data
    //             this._orderService['_budgetGroupsLoading'].next(false);
    //             this._orderService['_budgetGroupsComplete'].next(false);
    //             this._orderService['_budgetGroupsPage']++;
                
    //             // Store current length to check if new data is loaded
    //             const currentBudgetGroupsLength = this._orderService['_budgetGroups'].value.length;
                
    //             this._orderService.loadMoreBudgetGroups(this.budgetGroupsSearchControl.value || '').subscribe({
    //               next: () => {
    //                 // Check if any new data was added
    //                 const newLength = this._orderService['_budgetGroups'].value.length;
    //                 if (newLength <= currentBudgetGroupsLength) {
                      
    //                   this._noMoreData.budgetGroups = true;
    //                 }
    //               }
    //             });
    //             break;
                
    //           case 'organizations':
                
    //             // Force states to ensure the service loads more data
    //             this._orderService['_organizationsLoading'].next(false);
    //             this._orderService['_organizationsComplete'].next(false);
                
    //             // We don't increment page here because it's done in the service method
                
    //             // Store current length to check if new data is loaded
    //             const currentOrganizationsLength = this._orderService['_organizations'].value.length;
                
    //             this._orderService.loadMoreOrganizations(this.organizationsSearchControl.value || '').subscribe({
    //               next: (response) => {
    //                 // Check if any new data was added
    //                 const newLength = this._orderService['_organizations'].value.length;
    //                 if (newLength <= currentOrganizationsLength) {
                      
    //                   this._noMoreData.organizations = true;
    //                 } else {
    //                   // If we have more data, ensure we know there's more data available
    //                   if (response?.result?.organizations?.count > newLength) {
                      
    //                     this._noMoreData.organizations = false;
    //                   }
    //                 }
    //               }
    //             });
    //             break;
                
    //           case 'users':
                
    //             // Force states to ensure the service loads more data
    //             this._orderService['_usersLoading'].next(false);
    //             this._orderService['_usersComplete'].next(false);
                
    //             // We don't increment page here because it's done in the service method
                
    //             // Store current length to check if new data is loaded
    //             const currentUsersLength = this._orderService['_users'].value.length;
                
    //             // Check if we need to filter by organization
    //             const organizationId = this.filterForm.get('organizationId').value;
    //             if (organizationId) {
    //               // If organization is selected, load users for this organization
    //               this._orderService.loadUsersByOrganization(organizationId, this.usersSearchControl.value || '', false).subscribe({
    //                 next: (response) => {
    //                   // Check if any new data was added
    //                   const newLength = this._orderService['_users'].value.length;
    //                   if (newLength <= currentUsersLength) {
                        
    //                     this._noMoreData.users = true;
    //                   } else {
    //                     // If we have more data, ensure we know there's more data available
    //                     if (response?.result?.users?.count > newLength) {
                          
    //                       this._noMoreData.users = false;
    //                     }
    //                   }
    //                 }
    //               });
    //             } else {
    //               // Otherwise load all users
    //               this._orderService.loadMoreUsers(this.usersSearchControl.value || '').subscribe({
    //                 next: (response) => {
    //                   // Check if any new data was added
    //                   const newLength = this._orderService['_users'].value.length;
    //                   if (newLength <= currentUsersLength) {
    //                     //console.log(('No more users data available');
    //                     this._noMoreData.users = true;
    //                   } else {
    //                     // If we have more data, ensure we know there's more data available
    //                     if (response?.result?.users?.count > newLength) {
    //                       //console.log((`Users data available: ${newLength} of ${response.result.users.count}`);
    //                       this._noMoreData.users = false;
    //                     }
    //                   }
    //                 }
    //               });
    //             }
    //             break;
                
    //           case 'formUsers':
                
    //             // Force states to ensure the service loads more data
    //             this._orderService['_formUsersLoading'].next(false);
    //             this._orderService['_formUsersComplete'].next(false);
                
    //             // For form users, we always need an organization
    //             const formOrganizationId = this.orderForm.get('organizationId').value;
    //             if (formOrganizationId) {
    //               // Store current length to check if new data is loaded
    //               const currentFormUsersLength = this._orderService['_formUsers'].value.length;
                  
    //               this._orderService.loadMoreFormUsers(this.formUsersSearchControl.value || '', formOrganizationId).subscribe({
    //                 next: (response) => {
    //                   // Check if any new data was added
    //                   const newLength = this._orderService['_formUsers'].value.length;
    //                   if (newLength <= currentFormUsersLength) {
                        
    //                     this._noMoreData.formUsers = true;
    //                   } else {
    //                     // If we have more data, ensure we know there's more data available
    //                     if (response?.result?.users?.count > newLength) {
                          
    //                       this._noMoreData.formUsers = false;
    //                     }
    //                   }
    //                 }
    //               });
    //             }
    //             break;
                
    //           case 'products':
                
    //             // Force states to ensure the service loads more data
    //             this._orderService['_productsLoading'].next(false);
    //             this._orderService['_productsComplete'].next(false);
    //             this._orderService['_productsPage']++;
                
    //             // Store current length to check if new data is loaded
    //             const currentProductsLength = this._orderService['_products'].value.length;
                
    //             // Load all products regardless of organization
    //             this._orderService.loadMoreProducts(this.productsSearchControl.value || '').subscribe({
    //               next: (response) => {
    //                 // Check if any new data was added
    //                 const newLength = this._orderService['_products'].value.length;
    //                 if (newLength <= currentProductsLength) {
    //                   //console.log(('No more products data available');
    //                   this._noMoreData.products = true;
    //                 } else {
    //                   // If we have more data, ensure we know there's more data available
    //                   if (response?.result?.products?.count > newLength) {
    //                     //console.log((`Products data available: ${newLength} of ${response.result.products.count}`);
    //                     this._noMoreData.products = false;
    //                   }
    //                 }
    //               }
    //             });
    //             break;
    //         }
    //       }
    //     });
    //   } else {
    //     // If the panel wasn't found, try searching for any overlay pane
        
        
    //     // Use a different approach - look for any open overlay
    //     const fallbackPanel = document.querySelector('.cdk-overlay-pane');
    //     if (fallbackPanel) {
          
          
    //       // Try to find scrollable elements inside the fallback panel
    //       const scrollableElements = fallbackPanel.querySelectorAll('.mat-select-panel-wrap, .mat-select-content, .mat-optgroup, .mat-option');
          
          
          
    //       scrollableElements.forEach(element => {
    //         element.addEventListener('scroll', (event) => {
    //           const target = event.target as HTMLElement;
              
    //           // Check if scrolled to bottom
    //           if (target.scrollTop + target.clientHeight >= target.scrollHeight - 5 && !this._noMoreData[dropdownType]) {
                
                
    //             // Call the appropriate method to load more items
    //             switch (dropdownType) {
    //               case 'partners':
                    
    //                 this._orderService.loadMorePartners(this.partnersSearchControl.value || '').subscribe();
    //                 break;
    //               case 'budgetGroups':
                    
    //                 this._orderService.loadMoreBudgetGroups(this.budgetGroupsSearchControl.value || '').subscribe();
    //                 break;
    //               case 'organizations':
                    
    //                 this._orderService.loadMoreOrganizations(this.organizationsSearchControl.value || '').subscribe();
    //                 break;
    //               case 'users':
                    
    //                 const usersOrgId = this.filterForm.get('organizationId').value;
    //                 if (usersOrgId) {
    //                   this._orderService.loadUsersByOrganization(usersOrgId, this.usersSearchControl.value || '', false).subscribe();
    //                 } else {
    //                   this._orderService.loadMoreUsers(this.usersSearchControl.value || '').subscribe();
    //                 }
    //                 break;
    //               case 'formUsers':
                    
    //                 const formOrgId = this.orderForm.get('organizationId').value;
    //                 if (formOrgId) {
    //                   // Force page increment and reset loading state
    //                   this._orderService['_formUsersLoading'].next(false);
    //                   this._orderService['_formUsersComplete'].next(false);
    //                   // Don't increment page here as it's done in the loadMoreFormUsers function
    //                   this._orderService.loadMoreFormUsers(this.formUsersSearchControl.value || '', formOrgId).subscribe();
    //                 }
    //                 break;
    //               case 'products':
    //                 this._orderService.loadMoreProducts(this.productsSearchControl.value || '').subscribe();
    //                 break;
    //             }
    //           }
    //         });
    //       });
          
    //       // Also add listener to the fallback panel itself
    //       fallbackPanel.addEventListener('scroll', () => {
    //         const target = fallbackPanel as HTMLElement;
            
    //         // Check if scrolled to bottom
    //         if (target.scrollTop + target.clientHeight >= target.scrollHeight - 5 && !this._noMoreData[dropdownType]) {
              
              
    //           // Call the appropriate method to load more items
    //           switch (dropdownType) {
    //             case 'partners':
    //               this._orderService.loadMorePartners(this.partnersSearchControl.value || '').subscribe();
    //               break;
    //             case 'budgetGroups':
    //               this._orderService.loadMoreBudgetGroups(this.budgetGroupsSearchControl.value || '').subscribe();
    //               break;
    //             case 'organizations':
    //               this._orderService.loadMoreOrganizations(this.organizationsSearchControl.value || '').subscribe();
    //               break;
    //             case 'users':
    //             const fallbackUsersOrgId = this.filterForm.get('organizationId').value;
    //             if (fallbackUsersOrgId) {
    //                   this._orderService.loadUsersByOrganization(fallbackUsersOrgId, this.usersSearchControl.value || '', false).subscribe();
    //             } else {
    //               this._orderService.loadMoreUsers(this.usersSearchControl.value || '').subscribe();
    //               }
    //               break;
    //           case 'formUsers':
    //               const fallbackFormOrgId = this.orderForm.get('organizationId').value;
    //               if (fallbackFormOrgId) {
    //                 // Force page increment and reset loading state
    //                 this._orderService['_formUsersLoading'].next(false);
    //                 this._orderService['_formUsersComplete'].next(false);
    //                 // Don't increment page here as it's done in the loadMoreFormUsers function
    //                 this._orderService.loadMoreFormUsers(this.formUsersSearchControl.value || '', fallbackFormOrgId).subscribe();
    //               }
    //               break;
    //           case 'products':
    //               this._orderService.loadMoreProducts(this.productsSearchControl.value || '').subscribe();
    //               break;
    //           }
    //         }
    //       });
    //     }
    //   }
    // }, 100);
  }
  
  /**
   * Clear search input for a specific dropdown
   * @param searchControl FormControl for the search input
   * @param type Type of dropdown to clear search for
   */
  clearDropdownSearch(searchControl: UntypedFormControl, type: string): void {
    searchControl.setValue('');
    
    // Trigger search with empty string to reset the dropdown
    switch (type) {
      case 'partners':
        this._orderService.loadMorePartners('').subscribe();
        break;
      case 'budgetGroups':
        this._orderService.loadMoreBudgetGroups('').subscribe();
        break;
      case 'organizations':
        this._orderService.loadMoreOrganizations('').subscribe();
        break;
      case 'users':
        // We're in the filter form - check if an organization is selected
        const filterOrgId = this.filterForm.get('organizationId').value;
        if (filterOrgId) {
          // If we have an organization selected, load users for this organization
          this._orderService.loadUsersByOrganization(filterOrgId, '', false).subscribe();
        } else {
          // Otherwise load all users
          this._orderService.loadMoreUsers('').subscribe();
        }
        break;
      case 'formUsers':
        // We're in the edit form - check if an organization is selected
        const editOrgId = this.orderForm.get('organizationId').value;
        if (editOrgId) {
          // If we have an organization selected, load users for this organization
          this._orderService.loadMoreFormUsers('', editOrgId).subscribe();
        }
        break;
      case 'products':
        this._orderService.loadMoreProducts('').subscribe();
        break;
    }
  }

  onSelectionChange(value: any) {
    if(value && value !=''){      
      this.selectedProductForm.get(value).markAsTouched();      
    }
  }
}

