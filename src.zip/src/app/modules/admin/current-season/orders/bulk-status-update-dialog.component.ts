import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-bulk-status-update-dialog',
  standalone: true,
  imports: [
    NgIf,
    FormsModule,
    ReactiveFormsModule, 
    MatButtonModule, 
    MatFormFieldModule, 
    MatSelectModule,
    MatProgressSpinnerModule,
    MatDialogModule
  ],
  template: `
    <h2 mat-dialog-title>Bulk Status Change</h2>
    <div mat-dialog-content>
      <p>Are you sure to change selected orders to selected status?</p>
      @if (errorMessage) {
        <div class="error-message" style="color: red; margin-bottom: 10px;">
          {{ errorMessage }}
        </div>
      }
      <form [formGroup]="statusForm" class="status-form">
        <mat-form-field appearance="outline" class="w-full global-input">
          <mat-label>Status</mat-label>
          <mat-select formControlName="statusId">
            @for (status of statuses; track status.id) {
              <mat-option [value]="status.id">
                {{ status.name }}
              </mat-option>
            }
          </mat-select>
          @if (statusForm.get('statusId').hasError('required')) {
            <mat-error>Status is required</mat-error>
          }
        </mat-form-field>
      </form>
    </div>
    <div mat-dialog-actions class="justify-end">
      <button 
        mat-button 
        [mat-dialog-close]="false" 
        cdkFocusInitial
        [disabled]="isLoading"
      >
        Cancel
      </button>
      <button 
        mat-flat-button 
        color="primary" 
        [disabled]="statusForm.invalid || isLoading" 
        (click)="updateStatus()"
      >
        @if (isLoading) {
          <span class="mr-2">
            <mat-spinner diameter="20"></mat-spinner>
          </span>
        }
        Change Status
      </button>
    </div>
  `,
  styles: [`
    .status-form {
      min-width: 300px;
      margin-top: 20px;
    }
    
    .justify-end {
      display: flex;
      justify-content: flex-end;
    }
    
    button {
      margin-left: 8px;
    }
  `]
})
export class BulkStatusUpdateDialogComponent implements OnInit {
  statusForm: UntypedFormGroup;
  isLoading = false;
  errorMessage: string | null = null;

  constructor(
    private _dialogRef: MatDialogRef<BulkStatusUpdateDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { orderIds: number[], statuses: any[] },
    private _formBuilder: UntypedFormBuilder
  ) { }

  ngOnInit(): void {
    this.statusForm = this._formBuilder.group({
      statusId: [null, Validators.required]
    });
  }

  get statuses(): any[] {
    return this.data.statuses || [];
  }

  updateStatus(): void {
    if (this.statusForm.invalid) {
      return;
    }

    const statusId = this.statusForm.get('statusId').value;
    this._dialogRef.close(statusId);
  }
}
