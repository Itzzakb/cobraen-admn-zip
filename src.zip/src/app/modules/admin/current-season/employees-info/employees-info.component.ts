import {
  AsyncPipe,
  CommonModule,
  CurrencyPipe,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDatepickerModule } from '@angular/material/datepicker';

import {
  InventoryCategory,
  InventoryPagination,
  InventoryProduct,
  InventoryTag,
  InventoryVendor,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  takeUntil,
} from 'rxjs';
import { products } from 'app/mock-api/apps/ecommerce/inventory/data';
import { ChristmasFairList, CommonDropdownItem, EmployeeCount, EmployeeInfo, OrganizationList } from 'app/shared/types/interfaces';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { NlTimezonePipe } from 'app/shared/pipes/nl-rimezone.pipe';
import { SearchableDropdownComponent } from 'app/shared/components/searchable-dropdown/searchable-dropdown.component';

@Component({
  selector: 'app-employees-info',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 1fr 50px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 1fr 50px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 1fr 50px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 1fr 50px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    MatTooltipModule,
    MatDatepickerModule,
    CommonModule,
    NlTimezonePipe,
    SearchableDropdownComponent
  ],
  templateUrl: './employees-info.component.html',
  styleUrl: './employees-info.component.scss',
})
export class EmployeesInfoComponent
  implements OnInit, AfterViewInit, OnDestroy
{
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  products$: Observable<InventoryProduct[]>;
  categories: InventoryCategory[];
  filteredTags: InventoryTag[];
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: InventoryPagination;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: EmployeeInfo | null = null;
  selectedProductForm: UntypedFormGroup;
  tags: InventoryTag[];
  tagsEditMode: boolean = false;
  vendors: InventoryVendor[];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  employeesArray: EmployeeInfo[] = [];
  selectedEmployees: Map<number, boolean> = new Map(); // Tracks selected giftsets
  allSelected: boolean = false;

  searchQuery: string = '';
  searchSubject = new Subject<string>();
  searchSubscription: any;

  @ViewChild('pageSizeDropdown') pageSizeDropdown!: MatPaginator;
  @ViewChild('paginator') paginator!: MatPaginator;  

  errorMessage = '';

  // Pagination properties
  pageIndex: number = 0;
  pageSize: number = 10;
  totalCount: number = 0;
  sortOrder: number = 1;
  sortColumn: string = 'id';

  registered: boolean = null;
  arrived: boolean = null;
  coming: string = null;
  fairId: number = null;
  organizationId: number = null;
  lastSendMail: boolean = null;
  active: boolean = null;

  employeeCount: EmployeeCount;

  createEmployee = false;

  organizationList: OrganizationList[] = [];
  christmasFairList: CommonDropdownItem[] = [];

  inlineEditData: string | number = '';
  isInlineEdit: boolean = false;
  editField: string = '';
  selectedProductId: number | null = null;
  isArrived: boolean = false;
  emptyInlineData = null;

  isDataLoaded: boolean = false; // Flag to check if data is loaded
  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _formBuilder: UntypedFormBuilder,
    private apiService: ApiService,
    private toastr: ToastrService
  ) {}

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.selectedProductForm = this._formBuilder.group({
      id: [''],
      userId: [''],
      name: [''],
      username: [''],
      email: [[]],
      organizationId: [''],
      organizationName: [''],
      coming: [''],
      comingText: [''],
      arrived: [false],
      arrivedDateTime: [''],
      scannedByName: [''],
      barcode: [''],
      fairIds: [[]],
      lastDateSendMail: [''],
      remark: [''],
      active: [false],
      questionAnswers: [[]],
    });

    // Debounce search input to optimize API calls
    this.searchSubscription = this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe(query => {
        this.searchQuery = query;
        this.pageIndex = 0; // Reset to first page on new search
        this.paginator.firstPage();
        this.getAllEmployees();
      });

      //get employee count
      this.getEmployeeCount();

      //get dropdown data
      this.getChristmasFairList();
      this.getOrganizationList();

    
  }

  getOrganizationList() {
    this.apiService.getAllOrganizations().subscribe((data) => {
      this.organizationList = data.result;
    },
      () => {
        this.errorMessage = 'Unable to fetch organizations for dropdown';
        this.showError();
      })
  }

  getChristmasFairList() {
    this.apiService.getAllChristmasFairs().subscribe((data) => {
      this.christmasFairList = data.result.data;
    },
      () => {
        this.errorMessage = 'Unable to fetch christmas fairs for dropdown';
        this.showError();
      })
  }

  // Toggle selection for a single employee
  toggleSelection(id: number) {
    if (this.selectedEmployees.has(id)) {
      this.selectedEmployees.delete(id); // Unselect
    } else {
      this.selectedEmployees.set(id, true); // Select
    }
    this.updateSelectAllState();
  }

  // Toggle Select All
  toggleSelectAll() {
    if (this.allSelected) {
      this.selectedEmployees.clear(); // Unselect all
    } else {
      this.employeesArray.forEach(brand => this.selectedEmployees.set(brand.id, true)); // Select all
    }
    this.allSelected = !this.allSelected;
  }

  // Update the "Select All" checkbox state
  updateSelectAllState() {
    this.allSelected = this.selectedEmployees.size === this.employeesArray.length;
  }

  //get selectedStandardGifts' Ids
  getSelectedEmployeeIds(): number[] {
    return Array.from(this.selectedEmployees.entries()) // Convert Map to an array of key-value pairs
      .filter(([, isSelected]) => isSelected) // Filter selected brands
      .map(([id]) => id); // Extract only the IDs
  }

  // get all Free Gifts
    getAllEmployees() {
      const params = {
        sortColumn: this.sortColumn,
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        sortOrder: this.sortOrder,
        searchQuery: this.searchQuery,
        registered: this.registered,
        arrived: this.arrived,
        coming: this.coming,
        fairId: this.fairId,
        organizationId: this.organizationId,
        active: this.active

      }
      this.apiService.getEmployees(params).subscribe((data) => {
        this.isDataLoaded = false;
        this.employeesArray = data.result.data;
        this.pageIndex = data.result.pageIndex;
        this.pageSize = data.result.pageSize;
        this.totalCount = data.result.count;
        if (this.employeesArray.length == 0) {
          this.isDataLoaded = true;
        }

        this.resetInlineEdit();
      }, (error)=>{
        this.isDataLoaded = false;
        this.errorMessage = 'Unable to get employee info data';
        this.showError();
      });
    }

    getEmployeeCount(){
      this.apiService.getEmployeeCount().subscribe((data)=>{
        if (data.requestResult == 1) {
          this.employeeCount = data.result;          
        } else {
          this.errorMessage = 'Unable to fetch the employee';
          this.showError();
        }
      },
        (error) => {
          this.errorMessage = 'Unable to fetch the employee';
          console.error(error.error.responseTip);
          this.showError();
        })
    }
  
    showSuccess(type: string) {
      const message = this.getSuccessMessage(type);
      this.toastr.success(message, 'Success!');
    }
      //get success message based on type
      getSuccessMessage(type: string) {
        switch (type) {
          case 'create':
            return 'Employee info created successfully.';
            break;
          case 'update':
            return 'Employee info updated successfully.';
            break;
          case 'delete':
            return 'Employee info deleted successfully.';
            break;
          case 'statusUpdate':
            return 'Employee info status updated successfully.'
            break;
        }
      }
    showError() {
      this.toastr.error(this.errorMessage, 'Error!');
    }
  
    // Triggers a search operation with the provided query string.
    onSearch(query: string): void {
      this.createEmployee = false;
      this.closeDetails();
      this.searchSubject.next(query);
    }
  
    // Handle pagination changes
    onPageChange(event: any): void {
      this.pageIndex = event.pageIndex;
      this.pageSize = event.pageSize;
      this.getAllEmployees();
    }

    newProduct = {
      id: 0,
      userId: '',
      name: '',
      username: '',
      email: '',
      organizationId: 0,
      organizationName: '',
      coming: '',
      comingText: '',
      arrived: false,
      arrivedDateTime: '',
      scannedByName: '',
      barcode: '',
      fairIds: [],
      budgetChristmasFair: null,
      budgetName: '',
      lastDateSendMail: '',
      remark: '',
      active: false,
      questionAnswers: [],
    }
  
    toggleCreateStandardGiftForm() {
      //close the edit form if open
      this.closeDetails();
  
      this.createEmployee = !this.createEmployee;
      if (this.createEmployee) {
  
        
        // Go to new product
        this.selectedProduct = this.newProduct;
  
        // Fill the form
        this.selectedProductForm.patchValue(this.newProduct);
  
        // Mark for check
        this._changeDetectorRef.markForCheck();
      } else {
        this.selectedProductForm.reset();
      }
    }
  
    updateStatus(isFromTable=false, id: number, arrived: null | boolean =null) {
      let body = {
        "arrived": isFromTable ? !arrived : this.selectedProductForm.getRawValue().arrived,
        "employeeId": id
      }
  
      this.apiService.updateEmployeeStatus(body).subscribe((data) => {
        if (data.requestResult == 1) {
          this.showSuccess('statusUpdate');
          this.getAllEmployees();
        } else {
          this.errorMessage = data.responseTip;
          this.showError();
        }
      },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        })
    }  
    
    updateEmployeeInfo() {
      const employee = this.selectedProductForm.getRawValue();
        const body = {
          "employeeId": employee.id,
          "remark": employee.remark.trim()
        }
        
        this.apiService.updateEmployeeRemark(body).subscribe((data) => {
          if (data.requestResult == 1) {
            this.getAllEmployees();
            this.resetForm();
            this.closeDetails();
            this.showSuccess('update');
          } else {
            this.errorMessage = data.responseTip;
            this.showError();
          }
        },
          (error) => {
            this.errorMessage = error.error.responseTip;
            this.showError();
          });
    }

    updaterrivedData(status: boolean, scannedBy: string = null){
      this.isArrived = status;
      if(this.isArrived){
        this.selectedProduct.arrivedDateTime = new Date().toString();
        //console.log((new Date());
        this.selectedProduct.scannedByName = scannedBy ? scannedBy : localStorage.getItem('userName');
      }
    }

  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * After view init
   */
  ngAfterViewInit(): void {
    if (this._sort && this._paginator) {
      setTimeout(() => {
        // Set the initial sort
        this._sort.sort({
          id: 'id',
          start: 'desc',
          disableClear: true,
        });
      });

      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;
          this.pageIndex = 0;

          //reset and close the form if it is open
          this.resetForm();
          this.closeDetails();

          // set the sort column and sort order
          this.sortColumn = this._sort.active;
          this.sortOrder = this._sort.direction === 'asc' ? 2 : 1;

          // Get the Free gifts
          this.getAllEmployees();
        });
    }
  }

  getOrganizationName(id: number): string {
    const organization = this.organizationList.find((org) => org.id === id);
    return organization ? organization.name : '';
  }

  getComingStatus(status: string){
    switch (status) {
      case '1':
        return 'Yes';
        break;
      case '2':
        return 'No';
        break;
      case '3':
        return 'Let colleague shop';
        break;
      default:
        return ''
    }
  }
  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggle product details
   *
   * @param id
   */
  toggleDetails(id: number): void {
    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct.id === id) {
      // Close the details
      this.closeDetails();
      return;
    }
    const myMap = new Map(this.employeesArray.map((obj) => [obj.id, obj]));

    this.selectedProduct = myMap.get(id);
    this.selectedProductForm.patchValue(this.selectedProduct);
    this.updaterrivedData(this.selectedProduct.arrived, this.selectedProduct.scannedByName);
   
  }

  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
  }

  //resetForm
  resetForm(){
    this.selectedProductForm.patchValue(this.newProduct);
  }

  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }

  toggleInlineEdit(id: number, field: string) {
    this.editField = field;
    this.selectedProductId = id;
    this.isInlineEdit = true;
    this.toggleDetails(id);
    this.inlineEditData = this.selectedProduct[field];
  }

  resetInlineEdit() {
    this.editField = '';
    this.selectedProductId = null;
    this.inlineEditData = '';
    this.isInlineEdit = false;
  }

  editInlineData(field: string) {
    this.selectedProductForm.patchValue({
      [field]: this.inlineEditData,
    });
    this.updateEmployeeInfo();
  }

  onSelectionChange(value: any) {
    // if(value && value !=''){
    //     this.selectedProductForm.get(value).markAsTouched();      
    // }
    debugger;
    if(value == 'fairId'){
      console.log(value);
    }
  }


}

