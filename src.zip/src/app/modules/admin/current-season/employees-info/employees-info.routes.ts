import { Routes } from "@angular/router";
import { EmployeesInfoComponent } from "./employees-info.component";

export default [
    {
        path: '',
        component: EmployeesInfoComponent
    }
] as Routes