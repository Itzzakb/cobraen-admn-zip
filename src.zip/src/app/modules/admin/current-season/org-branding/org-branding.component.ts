import {
  AsyncPipe,
  CommonModule,
  CurrencyPipe,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ColorPickerModule } from 'ngx-color-picker';
import { ImageLibraryComponent } from 'app/modules/image-library/image-library.component';
import { MatRadioModule } from '@angular/material/radio';

import {
  InventoryBrand,
  InventoryCategory,
  InventoryPagination,
  InventoryProduct,
  InventoryTag,
  InventoryVendor,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  takeUntil,
} from 'rxjs';
import { products } from 'app/mock-api/apps/ecommerce/inventory/data';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';
import {
  faqTypeName,
  ImageLibraryContent,
  OrganizationBranding,
  OrganizationList,
} from 'app/shared/types/interfaces';
import { ApiService } from '@fuse/services/api-service.service';
import { SearchableDropdownComponent } from 'app/shared/components/searchable-dropdown/searchable-dropdown.component';
import { ImageLibraryDialog } from 'app/shared/components/image-library/image-library.component';
import { DeleteConfirmationService } from 'app/shared/services/delete-confirmation.service';
import { OrganizationCopyForm } from 'app/shared/utils/dialog-with-org-form/dialog-with-org-form.component';

@Component({
  selector: 'app-org-branding',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 10% 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 136px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 10% 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 136px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 10% 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 136px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 10% 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 136px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    MatTooltipModule,
    ColorPickerModule,
    ImageLibraryComponent,
    MatRadioModule,
    CommonModule,
    SearchableDropdownComponent,
  ],
  templateUrl: './org-branding.component.html',
  styleUrl: './org-branding.component.scss',
})
export class OrgBrandingComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  products$: Observable<InventoryProduct[]>;

  brands: InventoryBrand[];
  categories: InventoryCategory[];
  filteredTags: InventoryTag[];
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: InventoryPagination;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: OrganizationBranding | null = null;
  selectedProductForm: UntypedFormGroup;
  tags: InventoryTag[];
  tagsEditMode: boolean = false;
  vendors: InventoryVendor[];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  organizationBrandingArray: OrganizationBranding[] = [];
  selectedOrganizationBrandings: Map<number, boolean> = new Map(); // Tracks selected Organization brandings
  allSelected: boolean = false;

  searchQuery: string = '';
  searchSubject = new Subject<string>();
  searchSubscription: any;

  // Pagination properties
  pageIndex: number = 0;
  pageSize: number = 10;
  totalCount: number = 0;
  sortOrder: number = 1;
  sortColumn: number = 0;

  createOrganizationBranding = false;
  selectedOrganizationBrandingId: number | null = null;

  errorMessage = '';
  appLogoErrorMessage: string = '';
  appQRCodeImageErrorMessage: string = '';
  organizationList: OrganizationList[] = [];
  filteredOrganizationList: OrganizationList[] = [];

  defaultLogo: string | null = '';
  defaultLogoFile: File | null = null;
  bannerImage: string | null = '';
  bannerImageFile: File | null = null;
  backgroundImage: string | null = '';
  backgroundImageFile: File | null = null;
  appLogo: string | null = '';
  appLogoFile: File | null = null;
  appQrCodeImage: string | null = '';
  appQrCodeFile: File | null = null;
  isDataLoaded: boolean = false;
  isOrganizationAvailableForApp: boolean = false;

  @ViewChild('headerPaginator') headerPaginator!: MatPaginator;
  @ViewChild('footerPaginator') footerPaginator!: MatPaginator;

  @ViewChild('background_image', { static: false })
  background_image!: ElementRef;
  @ViewChild('default_logo', { static: false }) default_logo!: ElementRef;
  @ViewChild('app_logo', { static: false }) app_logo!: ElementRef;
  @ViewChild('app_qr_code_immage', { static: false })
  app_qr_code_immage!: ElementRef;
  @ViewChild('banner_image', { static: false }) banner_image!: ElementRef;

  sloganTextColor = '';
  filtersTextColor = '';
  headingColor = '';
  backgroundColor = '';
  bodyColor = '';
  moduleColor = '';
  textColor = '';
  menuTextColor = '';
  logoBackgroundColor = '';
  appMainColor = '';
  appSubColor = '';
  LibraryBackgroundImage: ImageLibraryContent = null;
  LibraryBannerImage: ImageLibraryContent = null;

  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _deleteConfirmationService: DeleteConfirmationService,
    private _formBuilder: UntypedFormBuilder,
    private toastr: ToastrService,
    private dialog: MatDialog,
    private apiService: ApiService
  ) {}

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.selectedProductForm = this._formBuilder.group({
      id: [''],
      organizationId: ['', [Validators.required]],
      headingColor: [''],
      backgroundColor: [''],
      bodyColor: [''],
      moduleColor: [''],
      textColor: [''],
      menuTextColor: [''],
      headingTransparency: [''],
      bodyTransparency: [''],
      moduleTransparency: [''],
      appMainColor: [this.appMainColor],
      appSubColor: [this.appSubColor],
      sloganText: [''],
      sloganTextColor: [''],
      filtersTextColor: [''],
      shoppingCartIcon: [''],
      logoBackgroundColor: [''],
    });

    // Debounce search input to optimize API calls
    this.searchSubscription = this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe((query) => {
        this.searchQuery = query;
        this.pageIndex = 0; // Reset to first page on new search
        this.footerPaginator.firstPage();
        this.getAllOrganizationBrandings();
      });
  }

  // Toggle selection for a single faq group
  toggleSelection(id: number) {
    if (this.selectedOrganizationBrandings.has(id)) {
      this.selectedOrganizationBrandings.delete(id); // Unselect
    } else {
      this.selectedOrganizationBrandings.set(id, true); // Select
    }
    this.updateSelectAllState();
  }

  // Toggle Select All
  toggleSelectAll() {
    if (this.allSelected) {
      this.selectedOrganizationBrandings.clear(); // Unselect all
    } else {
      this.organizationBrandingArray.forEach((brand) =>
        this.selectedOrganizationBrandings.set(brand.id, true)
      ); // Select all
    }
    this.allSelected = !this.allSelected;
  }

  // Update the "Select All" checkbox state
  updateSelectAllState() {
    this.allSelected =
      this.selectedOrganizationBrandings.size ===
      this.organizationBrandingArray.length;
  }

  //get selectedOrganizationBrandings' Ids
  getSelecteOrganizationBrandingIds(): number[] {
    return Array.from(this.selectedOrganizationBrandings.entries()) // Convert Map to an array of key-value pairs
      .filter(([id, isSelected]) => isSelected) // Filter selected organization branding
      .map(([id]) => id); // Extract only the IDs
  }

  /**
   * Deletes the selected organization branding by sending their IDs to the API.
   *
   * This method retrieves the IDs of the selected organization branding, sends them to the API service to delete the organization branding,
   * and handles the response. On successful deletion, it clears the selected organization branding, refreshes the organization branding list,
   * and shows a success message. On failure, it sets an error message and shows an error message.
   */
  deleteOrganizationBranding() {
    this.apiService
      .deleteOrganizationBranding(this.getSelecteOrganizationBrandingIds())
      .subscribe(
        (response) => {
          if (response.requestResult == 1) {
            //getting requestresult 3 with success tip
            this.selectedOrganizationBrandings = new Map();
            this.getAllOrganizationBrandings();
            this.showSuccess('delete');
          } else {
            this.errorMessage = response.responseTip;
            this.showError();
          }
        },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        }
      );
  }

  /**
   * Fetches all budget groups based on the current pagination, sorting, and search query parameters.
   * Updates the budget group array, pagination properties, and handles any errors by displaying an error message.
   */
  getAllOrganizationBrandings() {
    const params = {
      sortColumn: this.sortColumn,
      pageIndex: this.pageIndex,
      pageSize: this.pageSize,
      sortOrder: this.sortOrder,
      searchQuery: this.searchQuery,
    };
    this.apiService.getOrganizationBrandings(params).subscribe(
      (data) => {
        this.getAllOrganizations();
        this.organizationBrandingArray = data.result.data;
        this.pageIndex = data.result.pageIndex;
        this.pageSize = data.result.pageSize;
        this.totalCount = data.result.count;
        this.isDataLoaded = true;
      },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      }
    );
  }

  showSuccess(type: string) {
    const message = this.getSuccessMessage(type);
    this.toastr.success(message, 'Success!');
  }

  //get success message based on type
  getSuccessMessage(type: string) {
    switch (type) {
      case 'create':
        return 'Organization branding created successfully.';
        break;
      case 'update':
        return 'Organization branding updated successfully.';
        break;
      case 'delete':
        return 'Organization branding deleted successfully.';
        break;
      case 'copy':
        return 'Organization branding copied successfully.';
        break;
      case 'statusUpdate':
        return 'Organization branding status updated successfully.';
        break;
    }
  }
  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }

  // Triggers a search operation with the provided query string.
  onSearch(query: string): void {
    this.createOrganizationBranding = false;
    this.closeDetails();
    this.searchSubject.next(query);
  }

  // Handle pagination changes
  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.getAllOrganizationBrandings();
  }

  toggleCreateOrganizationBrandingForm() {
    this.createOrganizationBranding = !this.createOrganizationBranding;
    this.filteredOrganizationList = this.organizationList?.filter(
      (org) => org.noBranding
    );
    this.resetForm();
    if (this.createOrganizationBranding) {
      const newProduct = {
        id: 0,
        organizationId: null,
        organizationName: '',
        headingColor: '',
        backgroundColor: '',
        backgroundImage: '',
        bodyColor: '',
        moduleColor: '',
        textColor: '',
        menuTextColor: '',
        headingTransparency: 0,
        bodyTransparency: 0,
        moduleTransparency: 0,
        appLogo: null,
        appMainColor: this.appMainColor,
        appSubColor: this.appSubColor,
        appQrCodeImage: null,
        sloganText: '',
        bannerImage: null,
        sloganTextColor: '',
        filtersTextColor: '',
        shoppingCartIcon: '',
        logoBackgroundColor: '',
        defaultLogo: null,
      };
      // Go to new product
      this.selectedProduct = newProduct;

      // Fill the form
      this.selectedProductForm.patchValue(newProduct);

      // Mark for check
      this._changeDetectorRef.markForCheck();
    } else {
      this.selectedProductForm.reset();
    }
  }

  checkAppLogo() {
    if (
      this.appLogo == '' &&
      !this.appLogoFile &&
      this.isOrganizationAvailableForApp
    ) {
      this.appLogoErrorMessage = 'App logo is required';
    } else {
      this.appLogoErrorMessage = '';
    }
    if (this.isOrganizationAvailableForApp) {
      this.selectedProductForm
        .get('appSubColor')
        .setValidators([Validators.required]);
      this.selectedProductForm
        .get('appMainColor')
        .setValidators([Validators.required]);
    } else {
      this.selectedProductForm.get('appMainColor').clearValidators();
      this.selectedProductForm.get('appSubColor').clearValidators();
    }
  }
  checkAppQRCodeImage() {
    if (
      this.appQrCodeImage == '' &&
      !this.appQrCodeFile &&
      this.isOrganizationAvailableForApp
    ) {
      this.appQRCodeImageErrorMessage = 'App QR code Image is required';
    } else {
      this.appQRCodeImageErrorMessage = '';
    }
  }

  /**
   * Adds a Organization if the form is valid. The method collects form data,
   * appends it to a FormData object, and sends it to the API service to create a Organization.
   * If the creation is successful, it refreshes the budget groups list, resets the form, closes the details view,
   * and shows a success message. If the creation fails, it shows an error message.
   * If the form is invalid, it marks all form fields as touched.
   */
  addOrganizationBranding() {
    this.checkAppLogo();
    this.checkAppQRCodeImage();
    if (
      (this.selectedProductForm.valid && ((this.appMainColor != '' &&
        this.appSubColor != '' &&
        this.appLogoErrorMessage == '' &&
        this.appQRCodeImageErrorMessage == '') ||
        !this.isOrganizationAvailableForApp))
    ) {
      const organizationBranding = this.selectedProductForm.getRawValue();
      var formData = new FormData();
      const appendIfNotNull = (key: string, value: any) => {
        if (value !== null && value !== undefined) {
          formData.append(key, value);
        }
      };
      formData.append('OrganizationId', organizationBranding.organizationId);
      appendIfNotNull(
        'OrganizationName',
        organizationBranding.organizationName
      );
      appendIfNotNull('HeadingColor', this.headingColor);
      appendIfNotNull('BackgroundColor', this.backgroundColor);
      appendIfNotNull('BodyColor', this.bodyColor);
      appendIfNotNull('ModuleColor', this.moduleColor);
      appendIfNotNull('TextColor', this.textColor);
      appendIfNotNull('MenuTextColor', this.menuTextColor);
      appendIfNotNull(
        'HeadingTransparency',
        organizationBranding.headingTransparency
      );
      appendIfNotNull(
        'BodyTransparency',
        organizationBranding.bodyTransparency
      );
      appendIfNotNull(
        'ModuleTransparency',
        organizationBranding.moduleTransparency
      );

      appendIfNotNull('SloganText', organizationBranding.sloganText);
      appendIfNotNull('SloganTextColor', this.sloganTextColor);
      appendIfNotNull('FiltersTextColor', this.filtersTextColor);
      appendIfNotNull(
        'ShoppingCartIcon',
        organizationBranding.shoppingCartIcon
      );
      appendIfNotNull('LogoBackgroundColor', this.logoBackgroundColor);

      if (this.defaultLogoFile != null) {
        formData.append('DefaultLogo', this.defaultLogoFile);
      }
      if (this.backgroundImageFile != null) {
        formData.append('BackgroundImage', this.backgroundImageFile);
      }
      if (this.bannerImageFile != null) {
        formData.append('BannerImage', this.bannerImageFile);
      }
      if (this.isOrganizationAvailableForApp) {
        if (this.appLogoFile != null) {
          formData.append('AppLogo', this.appLogoFile);
        }
        if (this.appQrCodeFile != null) {
          formData.append('AppQrCodeImage', this.appQrCodeFile);
        }

        appendIfNotNull('AppMainColor', this.appMainColor);
        appendIfNotNull('AppSubColor', this.appSubColor);
      }

      this.apiService.createOrganizationBranding(formData).subscribe(
        (data) => {
          if (data.requestResult == 1) {
            this.getAllOrganizationBrandings();
            this.resetForm();
            this.closeDetails();
            this.createOrganizationBranding = false;
            this.showSuccess('create');
          } else {
            this.errorMessage = data.responseTip;
            this.showError();
          }
        },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        }
      );
    } else {
      this.selectedProductForm.markAllAsTouched();
      this.errorMessage = 'Please fill all the required fields';
      this.showError();
    }
  }

  /**
   * Updates the Organization with the form data if the form is valid.
   *
   * This method collects the form data, appends it to a FormData object,
   * and sends it to the API service to update the Organization. If the
   * update is successful, it refreshes the Organizations list, resets the
   * form, closes the details view, and shows a success message. If the
   * update fails, it shows an error message.
   *
   * @remarks
   * - The form data is appended to the FormData object only if the values are not null or undefined.
   * - The API service method `updateBudgtGroup` is used to send the form data.
   * - The method handles both success and error responses from the API.
   * - If the form is invalid, all form fields are marked as touched to show validation errors.
   */
  updateOrganizationBranding() {
    this.checkAppLogo();
    this.checkAppQRCodeImage();
    if (
      (this.appMainColor != '' &&
      this.appSubColor != '' &&
      this.appLogoErrorMessage == '' &&
      this.appQRCodeImageErrorMessage == '') ||
      !this.isOrganizationAvailableForApp
    ) {
      const organizationBranding = this.selectedProductForm.getRawValue();
      var formData = new FormData();

      //append the form field if the value is not null
      const appendIfNotNull = (key: string, value: any) => {
        if (value !== null && value !== undefined) {
          formData.append(key, value);
        }
      };
      formData.append('Id', organizationBranding.id);
      formData.append('OrganizationId', organizationBranding.organizationId);
      appendIfNotNull(
        'OrganizationName',
        organizationBranding.organizationName
      );
      appendIfNotNull('HeadingColor', this.headingColor);
      appendIfNotNull('BackgroundColor', this.backgroundColor);
      appendIfNotNull('BodyColor', this.bodyColor);
      appendIfNotNull('ModuleColor', this.moduleColor);
      appendIfNotNull('TextColor', this.textColor);
      appendIfNotNull('MenuTextColor', this.menuTextColor);
      appendIfNotNull(
        'HeadingTransparency',
        organizationBranding.headingTransparency
      );
      appendIfNotNull(
        'BodyTransparency',
        organizationBranding.bodyTransparency
      );
      appendIfNotNull(
        'ModuleTransparency',
        organizationBranding.moduleTransparency
      );
      appendIfNotNull('SloganText', organizationBranding.sloganText);
      appendIfNotNull('SloganTextColor', this.sloganTextColor);
      appendIfNotNull('FiltersTextColor', this.filtersTextColor);
      appendIfNotNull(
        'ShoppingCartIcon',
        organizationBranding.shoppingCartIcon
      );
      appendIfNotNull('LogoBackgroundColor', this.logoBackgroundColor);
      formData.append('DefaultLogo', this.defaultLogoFile);
      formData.append('BackgroundImage', this.backgroundImageFile);
      formData.append('BannerImage', this.bannerImageFile);
      if (this.isOrganizationAvailableForApp) {
        appendIfNotNull('AppSubColor', this.appSubColor);
        appendIfNotNull('AppMainColor', this.appMainColor);
        formData.append('AppLogo', this.appLogoFile);
        formData.append('AppQrCodeImage', this.appQrCodeFile);
      }

      if (!this.bannerImageFile && !this.LibraryBannerImage){
        formData.append('ExistingBannerImage', this.bannerImage);
      }

      if (!this.backgroundImageFile && !this.LibraryBackgroundImage){
        formData.append('ExistingBackgroundImage', this.backgroundImage);
      }

      if(!this.backgroundImageFile && this.LibraryBackgroundImage){
        formData.append('LibraryBackgroundImage.UrlPath', this.LibraryBackgroundImage.urlPath);
        formData.append('LibraryBackgroundImage.FileName', this.LibraryBackgroundImage.fileName);
      }

      if(!this.bannerImageFile && this.LibraryBannerImage){
        formData.append('LibraryBannerImage.UrlPath', this.LibraryBannerImage.urlPath);
        formData.append('LibraryBannerImage.FileName', this.LibraryBannerImage.fileName);
      }

      this.apiService.updateOrganizationBranding(formData).subscribe(
        (data) => {
          if (data.requestResult == 1) {
            this.getAllOrganizationBrandings();
            this.resetForm();
            this.closeDetails();
            this.showSuccess('update');
          } else {
            this.errorMessage = data.responseTip;
            this.showError();
          }
        },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        }
      );
    } else {
      this.selectedProductForm.markAllAsTouched();
      this.errorMessage = 'Please fill all the required fields';
      this.showError();
    }
  }

  openDialog(id: number) {
    const dialogRef = this.dialog.open(OrganizationCopyForm, {data: { orgList: this.organizationList.filter((x) => x.noBranding) }});
    dialogRef.afterClosed().subscribe((result) => {
      if(result && result.orgId){
        this.copyOrganizationBranding(id, result.orgId);
      }
    });
  }

  //copy an organization branding but with a different name
  copyOrganizationBranding(id: number, orgId: string) {
    const formData = new FormData();
    formData.append('Id', id.toString());
    formData.append('organizationId', orgId);

    this.apiService.copyOrganizationBranding(formData).subscribe(
      (data) => {
        if (data.requestResult == 1) {
          this.getAllOrganizationBrandings();
          this.showSuccess('copy');
        } else {
          this.errorMessage = data.responseTip;
          this.showError();
        }
      },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      }
    );
  }

  getAllOrganizations() {
    this.apiService.getAllOrganizations().subscribe(
      (data) => {
        if (data.requestResult == 1) {
          this.organizationList = data.result;
          this.filteredOrganizationList = this.organizationList;
        } else {
          this.errorMessage = data.responseTip;
          this.showError();
        }
      },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      }
    );
  }

  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * After view init
   */
  ngAfterViewInit(): void {
    if (this._sort && this._paginator) {
      setTimeout(() => {
        // Set the initial sort
        this._sort.sort({
          id: 'id',
          start: 'desc',
          disableClear: true,
        });
      });

      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;
          this.pageIndex = 0;

          //reset and close the form if it is open
          this.resetForm();
          this.closeDetails();

          // set the sort column and sort order
          this.sortColumn = this.getSortColumn(this._sort.active);
          this.sortOrder = this._sort.direction === 'asc' ? 2 : 1;

          // Get the Brands
          this.getAllOrganizationBrandings();
        });
    }
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
    if (this.searchSubscription) {
      this.searchSubscription.unsubscribe();
    }
  }

  getSortColumn(name: string) {
    switch (name) {
      case 'orgName':
        return 1;
      case 'headingColor':
        return 2;
      case 'headingTransparency':
        return 3;
      case 'bgColor':
        return 4;
      case 'bodyColor':
        return 5;
      case 'bodyTransparency':
        return 6;
      case 'moduleColor':
        return 7;
      case 'ModuleTransparency':
        return 8;
      case 'textColor':
        return 9;
      case 'menuTextColor':
        return 10;
      default:
        return 0;
    }
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggle product details
   *
   * @param id
   */
  toggleDetails(id: number): void {
    this.filteredOrganizationList = this.organizationList;
    this.createOrganizationBranding = false;
    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct.id === id) {
      // Close the details
      this.closeDetails();
      return;
    }
    const myMap = new Map(
      this.organizationBrandingArray.map((obj) => [obj.id, obj])
    );
    
    this.selectedProduct = myMap.get(id);
    this.selectedProductForm.patchValue(this.selectedProduct);
    this.isOrganizationAvailableForApp = this.filteredOrganizationList.find(
      (x) => x.id == this.selectedProduct.organizationId
    ).app;

    this.defaultLogo = this.selectedProduct.defaultLogo;
    this.bannerImage = this.selectedProduct.bannerImage;
    this.backgroundImage = this.selectedProduct.backgroundImage;
    this.appLogo = this.selectedProduct.appLogo;
    this.appQrCodeImage = this.selectedProduct.appQrCodeImage;

    this.sloganTextColor = this.selectedProduct.sloganTextColor;
    this.filtersTextColor = this.selectedProduct.filtersTextColor;
    this.headingColor = this.selectedProduct.headingColor;
    this.backgroundColor = this.selectedProduct.backgroundColor;
    this.bodyColor = this.selectedProduct.bodyColor;
    this.moduleColor = this.selectedProduct.moduleColor;
    this.textColor = this.selectedProduct.textColor;
    this.menuTextColor = this.selectedProduct.menuTextColor;
    this.logoBackgroundColor = this.selectedProduct.logoBackgroundColor;
    this.appMainColor = this.selectedProduct.appMainColor;
    this.appSubColor = this.selectedProduct.appSubColor;
  }

  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
    this.filteredOrganizationList = this.organizationList;
  }

  //reset form
  resetForm() {   
    let preservedId = this.selectedProductForm?.get('id')?.value ?? 0;
    this.selectedProductForm.reset({
      id : preservedId,
      organizationId: this.selectedProductForm?.get('organizationId')?.value,
      headingTransparency: 0,
      bodyTransparency: 0,
      moduleTransparency: 0,
    });
    if(preservedId != 0){
      this.selectedProductForm.markAllAsTouched();
    }

    this.sloganTextColor = '';
    this.filtersTextColor = '';
    this.headingColor = '';
    this.backgroundColor = '';
    this.bodyColor = '';
    this.moduleColor = '';
    this.textColor = '';
    this.menuTextColor = '';
    this.logoBackgroundColor = '';
    this.appMainColor = '';
    this.appSubColor = '';

    this.defaultLogo = '';
    this.defaultLogoFile = null;
    this.bannerImage = '';
    this.bannerImageFile = null;
    this.backgroundImage = '';
    this.backgroundImageFile = null;
    this.appLogo = '';
    this.appLogoFile = null;
    this.appQrCodeImage = '';
    this.appQrCodeFile = null;

    this.appLogoErrorMessage = '';
    this.appQRCodeImageErrorMessage = '';
  }

  /**
   * Delete the selected product using the form data
   */
  async deleteSelectedProduct(id: number | null, isFromDeleteBtn = false): Promise<void> {

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Organization Branding');

    if (!confirmed) {
      return;
    }

    if (!isFromDeleteBtn) {

      this.selectedOrganizationBrandings.clear();
      this.selectedOrganizationBrandings.set(id, true);
    }
    this.deleteOrganizationBranding();
    this.closeDetails();
  }

  /**
   * Show flash message
   */
  showFlashMessage(type: 'success' | 'error'): void {
    // Show the message
    this.flashMessage = type;

    // Mark for check
    this._changeDetectorRef.markForCheck();

    // Hide it after 3 seconds
    setTimeout(() => {
      this.flashMessage = null;

      // Mark for check
      this._changeDetectorRef.markForCheck();
    }, 3000);
  }

  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }

  multiDeleteDisable = true;
  checkAll: boolean;
  toggleCheckAll() {
    this.multiDeleteDisable = !this.multiDeleteDisable;
    if (this.checkAll) {
      products.forEach((item) => {
        this.checkedItems.push(item.barcode);
      });
    } else {
      this.checkedItems = [];
    }
  }

  checkedItems = [];

  checked(barcode: string) {
    if (this.checkedItems.includes(barcode)) {
      let newArray = this.checkedItems.filter((item) => {
        item != barcode;
      });
      this.checkedItems = newArray;
    } else {
      this.checkedItems.push(barcode);
    }
    this._paginator.pageSize == this.checkedItems.length
      ? (this.checkAll = true)
      : (this.checkAll = false);
  }

  // defaultStyling = this.formBuilder.group(
  //   {
  //     slogan_text: [''],
  //     slogan_text_color: [this.sloganTextColor],
  //     filters_text_color: [this.filtersTextColor],
  //     heading_color: [this.headingColor],
  //     heading_transparancy: [''],
  //     background_color: [this.backgroundColor],
  //     body_color: [this.bodyColor],
  //     body_transparancy: [''],
  //     module_color: [this.moduleColor],
  //     module_transparancy: [''],
  //     text_color: [this.textColor],
  //     menu_text_color: [this.menuTextColor],
  //     logo_background_color: [this.logoBackgroundColor],
  //     app_main_color: [this.appMainColor, Validators.required],
  //     app_sub_color: [this.appSubColor, Validators.required],
  //   }
  // )
  uploadImage(fileList: FileList): void {
    // Return if canceled
    if (!fileList.length) {
      return;
    }

    const allowedTypes = ['image/jpeg', 'image/png'];
    const file = fileList[0];

    // Return if the file is not allowed
    if (!allowedTypes.includes(file.type)) {
      return;
    }
  }

  public GetFileOnLoad(event: any, name: string) {
    if (event.target.files && event.target.files[0]) {
      var file = event.target.files[0] as File;

      this.getImageFilePreview(name, URL.createObjectURL(file), file);
    }
  }

  getImageFilePreview(name: string, imageURL: string, file: File) {
    switch (name) {
      case 'default logo':
        this.defaultLogo = imageURL;
        this.defaultLogoFile = file;
        break;
      case 'banner image':
        this.bannerImage = imageURL;
        this.bannerImageFile = file;
        break;
      case 'background image':
        this.backgroundImage = imageURL;
        this.backgroundImageFile = file;
        break;
      case 'app logo':
        this.appLogo = imageURL;
        this.appLogoFile = file;
        this.checkAppLogo();
        break;
      case 'app QR code image':
        this.appQrCodeImage = imageURL;
        this.appQrCodeFile = file;
        this.checkAppQRCodeImage();
        break;
    }
  }

  removeImageFile(name: string, inputBox: string) {
    switch (name) {
      case 'banner image':
        this.bannerImage = '';
        var element = document.getElementById(
          inputBox
        ) as HTMLInputElement | null;
        if (element != null) {
          element.value = '';
          element.blur();
        }
        this.LibraryBannerImage = null;
        break;
      case 'background image':
        this.backgroundImage = '';
        var element = document.getElementById(
          inputBox
        ) as HTMLInputElement | null;
        if (element != null) {
          element.value = '';
          element.blur();
        }
        this.LibraryBackgroundImage = null;
        break;
    }
  }

  changeColor(color: string, name: string) {
    switch (name) {
      case 'slogan text color':
        this.sloganTextColor = color;
        break;
      case 'filters text color':
        this.filtersTextColor = color;
        break;
      case 'heading color':
        this.headingColor = color;
        break;
      case 'background color':
        this.backgroundColor = color;
        break;
      case 'body color':
        this.bodyColor = color;
        break;
      case 'module color':
        this.moduleColor = color;
        break;
      case 'text color':
        this.textColor = color;
        break;
      case 'menu text color':
        this.menuTextColor = color;
        break;
      case 'logo background color':
        this.logoBackgroundColor = color;
        break;
      case 'app main color':
        this.appMainColor = color;
        break;
      case 'app sub color':
        this.appSubColor = color;
        break;
    }
  }

  openImageLibrary(type: string) {
    const dialogRef = this.dialog.open(ImageLibraryDialog);

    dialogRef.afterClosed().subscribe(result => {
      if (type == 'bannerImage') {
        this.LibraryBannerImage = result;
        this.bannerImage = this.LibraryBannerImage.urlPath + this.LibraryBannerImage.fileName;
      } else if (type == 'backgroundImage') {
        this.LibraryBackgroundImage = result;
        this.backgroundImage = this.LibraryBackgroundImage.urlPath + this.LibraryBackgroundImage.fileName;
      }
    });
  }

  onSelectionChange(value: any) {
    if (value && value != '') {
      this.selectedProductForm.get(value).markAsTouched();
      var id = this.selectedProductForm.value.organizationId;
      this.isOrganizationAvailableForApp = this.filteredOrganizationList.find(
        (x) => x.id == id
      ).app;
    }
  }

  onDropdownBlur() {
    this.selectedProductForm.get('organizationId').markAsTouched();
    this.selectedProductForm.get('organizationId').updateValueAndValidity();
  }

}
