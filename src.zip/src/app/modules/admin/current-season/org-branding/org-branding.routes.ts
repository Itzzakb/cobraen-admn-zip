import { OrgBrandingComponent } from "./org-branding.component";
import { Routes } from "@angular/router";

export default [
    {
        path: '',
        component: OrgBrandingComponent
    }
] as Routes