import {
  AsyncPipe,
  CurrencyPipe,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormControl,
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatCheckboxChange,
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { InventoryService } from 'app/shared/services/inventory.service';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatTooltipModule } from '@angular/material/tooltip';

import {
  InventoryBrand,
  InventoryCategory,
  InventoryPagination,
  InventoryProduct,
  InventoryTag,
  InventoryVendor,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  map,
  merge,
  switchMap,
  takeUntil,
} from 'rxjs';
import { products } from 'app/mock-api/apps/ecommerce/inventory/data';
@Component({
  selector: 'app-org-giftset',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 80px 1fr 1fr 100px 120px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 80px 1fr 1fr 100px 120px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 80px 1fr 1fr 100px 120px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 80px 1fr 1fr 100px 120px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    MatTooltipModule,
  ],
  templateUrl: './org-giftset.component.html',
  styleUrl: './org-giftset.component.scss',
})
export class OrgGiftsetComponent implements OnInit {
  brands: InventoryBrand[] = [
    {
      id: '1',
      name: 'brand1',
      slug: 'brand1',
    },
    {
      id: '2',
      name: 'brand2',
      slug: 'brand2',
    },
    {
      id: '3',
      name: 'brand3',
      slug: 'brand3',
    },
  ];
  formFieldHelpers: string[] = [''];
  fixedSubscriptInput: FormControl = new FormControl('', [Validators.required]);
  dynamicSubscriptInput: FormControl = new FormControl('', [
    Validators.required,
  ]);
  fixedSubscriptInputWithHint: FormControl = new FormControl('', [
    Validators.required,
  ]);
  dynamicSubscriptInputWithHint: FormControl = new FormControl('', [
    Validators.required,
  ]);

  /**
   * Constructor
   */
  constructor(private _formBuilder: UntypedFormBuilder) {}

  minDate: Date;
  maxDate: Date;
  ngOnInit() {
    const currentYear = new Date().getFullYear();
    this.minDate = new Date();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Get the form field helpers as string
   */
  getFormFieldHelpersAsString(): string {
    return this.formFieldHelpers.join(' ');
  }

  uploadImage(fileList: FileList): void {
    // Return if canceled
    if (!fileList.length) {
      return;
    }

    const allowedTypes = ['image/jpeg', 'image/png'];
    const file = fileList[0];

    // Return if the file is not allowed
    if (!allowedTypes.includes(file.type)) {
      return;
    }
  }
}
