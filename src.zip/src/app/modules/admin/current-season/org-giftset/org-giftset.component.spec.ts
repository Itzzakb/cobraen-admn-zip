import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrgGiftsetComponent } from './org-giftset.component';

describe('OrgGiftsetComponent', () => {
  let component: OrgGiftsetComponent;
  let fixture: ComponentFixture<OrgGiftsetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OrgGiftsetComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrgGiftsetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
