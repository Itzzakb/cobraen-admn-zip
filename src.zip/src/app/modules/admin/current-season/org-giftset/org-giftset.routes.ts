import { Routes } from "@angular/router";
import { OrgGiftsetComponent } from "./org-giftset.component";

export default [
    {
        path: '',
        component: OrgGiftsetComponent
    }
] as Routes