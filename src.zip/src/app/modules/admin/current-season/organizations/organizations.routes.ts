import { Routes } from "@angular/router";
import { OrganizationsComponent } from "./organizations.component";

export default [
    {
        path: '',
        component: OrganizationsComponent
    }
] as Routes