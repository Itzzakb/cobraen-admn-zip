import {
  AsyncPipe,
  CommonModule,
  CurrencyPipe,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatRadioModule } from '@angular/material/radio';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatTooltipModule } from '@angular/material/tooltip';
import { CommonHelperService } from 'app/shared/services/common-helper.service';

import {
  InventoryBrand,
  InventoryCategory,
  InventoryPagination,
  InventoryProduct,
  InventoryTag,
  InventoryVendor,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  takeUntil,
} from 'rxjs';
import {
  budgetGroupList,
  faqTypeName,
  Organization,
} from 'app/shared/types/interfaces';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';
import { DialogWithForm } from 'app/shared/utils/dialog-with-form/dialog-with-form.component';
import { SearchableDropdownComponent } from 'app/shared/components/searchable-dropdown/searchable-dropdown.component';
import { DeleteConfirmationService } from 'app/shared/services/delete-confirmation.service';

interface productImageType {
  id: number;
  url: string;
  filename: string;
}

@Component({
  selector: 'app-organizations',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 80px 1fr 100px 100px 120px 120px 80px 1fr 184px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 80px 1fr 100px 100px 120px 120px 80px 1fr 184px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 80px 1fr 100px 100px 120px 120px 80px 1fr 184px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 80px 1fr 100px 100px 120px 120px 80px 1fr 184px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    MatRadioModule,
    MatDatepickerModule,
    MatTooltipModule,
    CommonModule,
    SearchableDropdownComponent,
  ],
  templateUrl: './organizations.component.html',
  styleUrl: './organizations.component.scss',
})
export class OrganizationsComponent
  implements OnInit, AfterViewInit, OnDestroy
{
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  products$: Observable<InventoryProduct[]>;

  brands: InventoryBrand[];
  categories: InventoryCategory[];
  filteredTags: InventoryTag[];
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: InventoryPagination;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: Organization | null = null;
  organizationForm: UntypedFormGroup;
  tags: InventoryTag[];
  tagsEditMode: boolean = false;
  vendors: InventoryVendor[];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  OrganizationArray: Organization[] = [];
  selectedOrganizations: Map<number, boolean> = new Map(); // Tracks selected Organizations
  allSelected: boolean = false;

  searchQuery: string = '';
  searchSubject = new Subject<string>();
  searchSubscription: any;

  // Pagination properties
  pageIndex: number = 0;
  pageSize: number = 10;
  totalCount: number = 0;
  sortOrder: number = 1;
  sortColumn: number = 0;

  status: number = 0;

  createOrganization = false;
  selectedOrganizationId: number | null = null;

  // Current season ID
  currentSeasonId: number = 0;

  errorMessage = '';
  isDataLoaded: boolean = false;

  faqGroupList: faqTypeName[] = [];
  budgetGroupList: budgetGroupList[] = [];

  logo: string | null = '';
  logoFile: File | null = null;

  @ViewChild('headerPaginator') headerPaginator!: MatPaginator;
  @ViewChild('footerPaginator') footerPaginator!: MatPaginator;

  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _deleteConfirmationService: DeleteConfirmationService,
    private _formBuilder: UntypedFormBuilder,
    private apiService: ApiService,
    private toastr: ToastrService,
    private dialog: MatDialog
  ) {}

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.organizationForm = this._formBuilder.group({
      id: [''],
      name: ['', [Validators.required]],
      startShop: [''],
      endShop: [[]],
      app: [''],
      url: [''],
      incExVat: [false],
      welcomeText: [''],
      welcomeTextEng: [''],
      thankYouText: [''],
      thankYouTextEng: [''],
      closedShopText: [''],
      closedShopTextEng: [''],
      landingsPage: [''],
      landingsPageEng: [''],
      welcomeTextApp: [''],
      welcomeTextAppEng: [''],
      closedShopTextApp: [''],
      closedShopTextAppEng: [''],
      seasonName: [{ value: '', disabled: true }],
      thankYouTextCompany: [''],
      thankYouTextCompanyEng: [''],
      startApp: [''],
      endApp: [''],
      webShopType: [''],
      extraInfoProfile: [''],
      extraInfoProfileEng: [''],
      active: [false, [Validators.required]],
      budgetGroupIds: [''],
      faqGroupIds: [''],
    });

    // Get the current season ID
    this.getCurrentSeason();

    //get all faq groups for dropdown
    this.getFaqGroupList();

    //get all budget groups for dropdown
    this.getBudgetGroupList();

    // Debounce search input to optimize API calls
    this.searchSubscription = this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe((query) => {
        this.searchQuery = query;
        this.pageIndex = 0; // Reset to first page on new search
        this.footerPaginator.firstPage();
        this.getAllOrganizations();
      });
  }

  // Toggle selection for a single faq group
  toggleSelection(id: number) {
    if (this.selectedOrganizations.has(id)) {
      this.selectedOrganizations.delete(id); // Unselect
    } else {
      this.selectedOrganizations.set(id, true); // Select
    }
    this.updateSelectAllState();
  }

  // Toggle Select All
  toggleSelectAll() {
    if (this.allSelected) {
      this.selectedOrganizations.clear(); // Unselect all
    } else {
      this.OrganizationArray.forEach((brand) =>
        this.selectedOrganizations.set(brand.id, true)
      ); // Select all
    }
    this.allSelected = !this.allSelected;
  }

  // Update the "Select All" checkbox state
  updateSelectAllState() {
    this.allSelected =
      this.selectedOrganizations.size === this.OrganizationArray.length;
  }

  //get selectedOrganizations' Ids
  getSelecteOrganizationIds(): number[] {
    return Array.from(this.selectedOrganizations.entries()) // Convert Map to an array of key-value pairs
      .filter(([id, isSelected]) => isSelected) // Filter selected BudgetGroup
      .map(([id]) => id); // Extract only the IDs
  }

  /**
   * Deletes the selected budget groups by sending their IDs to the API.
   *
   * This method retrieves the IDs of the selected budget groups, sends them to the API service to delete the budget groups,
   * and handles the response. On successful deletion, it clears the selected budget groups, refreshes the budget groups list,
   * and shows a success message. On failure, it sets an error message and shows an error message.
   */
  deleteOrganizations() {
    this.apiService
      .deleteOrganization(this.getSelecteOrganizationIds())
      .subscribe(
        (response) => {
          if (response.requestResult == 1) {
            this.selectedOrganizations = new Map();
            this.getAllOrganizations();
            this.showSuccess('delete');
          } else {
            this.errorMessage = response.responseTip;
            this.showError();
          }
        },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        }
      );
  }

  /**
   * Fetches all budget groups based on the current pagination, sorting, and search query parameters.
   * Updates the budget group array, pagination properties, and handles any errors by displaying an error message.
   */
  getAllOrganizations() {
    const params = {
      sortColumn: this.sortColumn,
      pageIndex: this.pageIndex,
      pageSize: this.pageSize,
      sortOrder: this.sortOrder,
      searchQuery: this.searchQuery,
      status: this.status,
    };
    this.apiService.getOrganizations(params).subscribe(
      (data) => {
        this.OrganizationArray = data.result.data;
        this.pageIndex = data.result.pageIndex;
        this.pageSize = data.result.pageSize;
        this.totalCount = data.result.count;
        this.isDataLoaded = true;
      },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      }
    );
  }

  onStatusChange() {
    this.getAllOrganizations();
  }

  showSuccess(type: string) {
    const message = this.getSuccessMessage(type);
    this.toastr.success(message, 'Success!');
  }

  //get success message based on type
  getSuccessMessage(type: string) {
    switch (type) {
      case 'create':
        return 'Organization created successfully.';
        break;
      case 'update':
        return 'Organization updated successfully.';
        break;
      case 'delete':
        return 'Organization deleted successfully.';
        break;
      case 'copy':
        return 'Organization copied successfully.';
        break;
      case 'statusUpdate':
        return 'Organization status updated successfully.';
        break;
    }
  }
  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }

  // Triggers a search operation with the provided query string.
  onSearch(query: string): void {
    this.createOrganization = false;
    this.closeDetails();
    this.searchSubject.next(query);
  }

  // Handle pagination changes
  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.getAllOrganizations();
  }

  /**
   * Toggles the visibility of the create budget group form.
   *
   * When the form is toggled to be visible, it initializes a new product object with default values,
   * sets it as the selected product, fills the form with the new product's values, and marks the
   * change detector for check to update the view.
   *
   * When the form is toggled to be hidden, it resets the form.
   */
  toggleCreateOrganizationForm() {
    this.createOrganization = !this.createOrganization;
    if (this.createOrganization) {
      this.logo = '';
      this.logoFile = null; 
      const newProduct : Organization = {
        id: 0,
        name: '',
        startShop: '',
        endShop: '',
        app: false,
        logo: '',
        url: '',
        incExVat: false,
        welcomeText: '',
        welcomeTextEng: '',
        thankYouText: '',
        thankYouTextEng: '',
        closedShopText: '',
        closedShopTextEng: '',
        landingsPage: '',
        landingsPageEng: '',
        welcomeTextApp: '',
        welcomeTextAppEng: '',
        closedShopTextApp: '',
        closedShopTextAppEng: '',
        seasonName: this.currentSeasonId, // Set the current season ID by default
        thankYouTextCompany: '',
        thankYouTextCompanyEng: '',
        startApp: '',
        endApp: '',
        webShopType: 0,
        extraInfoProfile: '',
        extraInfoProfileEng: '',
        active: false,
        budgetGroupIds: [],
        faqGroupIds: [],
      };
      // Go to new product
      this.selectedProduct = newProduct;

      // Fill the form
      this.organizationForm.patchValue(newProduct);

      // Mark for check
      this._changeDetectorRef.markForCheck();
    } else {
      this.organizationForm.reset();
    }
  }

  /**
   * Adds a Organization if the form is valid. The method collects form data,
   * appends it to a FormData object, and sends it to the API service to create a Organization.
   * If the creation is successful, it refreshes the budget groups list, resets the form, closes the details view,
   * and shows a success message. If the creation fails, it shows an error message.
   * If the form is invalid, it marks all form fields as touched.
   */
  addOrganization() {
    if (this.organizationForm.valid) {
      const organization = this.organizationForm.getRawValue();
      var formData = new FormData();
      const appendIfNotNull = (key: string, value: any) => {
        if (value !== null && value !== undefined) {
          formData.append(key, value);
        }
      };
      formData.append('Name', organization.name);

      if(organization.startShop) {
        formData.append('StartShop', CommonHelperService.GenerateISODateTimeString(organization.startShop, null));
      }

      if(organization.endShop) {
        formData.append('EndShop', CommonHelperService.GenerateISODateTimeString(organization.endShop, null));
      }

      formData.append('App', organization.app);
      formData.append('Url', organization.url);
      formData.append('IncExVat', organization.incExVat);
      formData.append('WelcomeText', organization.welcomeText);
      formData.append('WelcomeTextEng', organization.welcomeTextEng);
      formData.append('ThankYouText', organization.thankYouText);
      formData.append('ThankYouTextEng', organization.thankYouTextEng);
      formData.append('ClosedShopText', organization.closedShopText);
      formData.append('ClosedShopTextEng', organization.closedShopTextEng);
      formData.append('LandingsPage', organization.landingsPage);
      formData.append('LandingsPageEng', organization.landingsPageEng);
      formData.append('WelcomeTextApp', organization.welcomeTextApp);
      formData.append('WelcomeTextAppEng', organization.welcomeTextAppEng);
      formData.append('ClosedShopTextApp', organization.closedShopTextApp);
      formData.append(
        'ClosedShopTextAppEng',
        organization.closedShopTextAppEng
      );
      formData.append('SeasonName', organization.seasonName);
      formData.append('ThankYouTextCompany', organization.thankYouTextCompany);
      formData.append(
        'ThankYouTextCompanyEng',
        organization.thankYouTextCompanyEng
      );
      formData.append('ExtraInfoProfile', organization.extraInfoProfile);
      formData.append('ExtraInfoProfileEng', organization.extraInfoProfileEng);
      formData.append('Active', organization.active);
      if (organization.app) {
        formData.append('StartApp', CommonHelperService.GenerateISODateTimeString(organization.startApp, null));
        formData.append('EndApp', CommonHelperService.GenerateISODateTimeString(organization.endApp, null));
      }

      if (
        organization.budgetGroupIds &&
        organization.budgetGroupIds?.length != 0
      ) {
        organization.budgetGroupIds.forEach((item) => {
          formData.append('BudgetGroupIds', item.toString());
        });
      } else {
        formData.append('BudgetGroupIds', '0');
      }

      if (organization.faqGroupIds && organization.faqGroupIds?.length != 0) {
        organization.faqGroupIds.forEach((item) => {
          formData.append('FaqGroupIds', item.toString());
        });
      } else {
        formData.append('FaqGroupIds', '0');
      }

      if (this.logoFile != null) {
        formData.append('Logo', this.logoFile);
      }

      this.apiService.createOrganization(formData).subscribe(
        (data) => {
          if (data.requestResult == 1) {
            this.getAllOrganizations();
            this.resetForm();
            this.closeDetails();
            this.createOrganization = false;
            this.showSuccess('create');
          } else {
            this.errorMessage = data.responseTip;
            this.showError();
          }
        },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        }
      );
    } else {
      this.organizationForm.markAllAsTouched();
      this.errorMessage = 'Please fill all the required fields';
      this.showError();
    }
  }

  /**
   * Updates the Organization with the form data if the form is valid.
   *
   * This method collects the form data, appends it to a FormData object,
   * and sends it to the API service to update the Organization. If the
   * update is successful, it refreshes the Organizations list, resets the
   * form, closes the details view, and shows a success message. If the
   * update fails, it shows an error message.
   *
   * @remarks
   * - The form data is appended to the FormData object only if the values are not null or undefined.
   * - The API service method `updateBudgtGroup` is used to send the form data.
   * - The method handles both success and error responses from the API.
   * - If the form is invalid, all form fields are marked as touched to show validation errors.
   */
  updateOrganization() {
    if (this.organizationForm.valid) {
      const organization = this.organizationForm.getRawValue();
      var formData = new FormData();

      //append the form field if the value is not null
      const appendIfNotNull = (key: string, value: any) => {
        if (value !== null && value !== undefined) {
          formData.append(key, value);
        }
      };
      formData.append('Id', organization.id);
      formData.append('Name', organization.name);

      if(organization.startShop) {
        formData.append('StartShop', CommonHelperService.GenerateISODateTimeString(organization.startShop, null));
      }

      if(organization.endShop) {
        formData.append('EndShop', CommonHelperService.GenerateISODateTimeString(organization.endShop, null));
      }

      appendIfNotNull('App', organization.app);
      appendIfNotNull('Url', organization.url);
      appendIfNotNull('IncExVat', organization.incExVat);
      appendIfNotNull('WelcomeText', organization.welcomeText);
      appendIfNotNull('WelcomeTextEng', organization.welcomeTextEng);
      appendIfNotNull('ThankYouText', organization.thankYouText);
      appendIfNotNull('ThankYouTextEng', organization.thankYouTextEng);
      appendIfNotNull('ClosedShopText', organization.closedShopText);
      appendIfNotNull('ClosedShopTextEng', organization.closedShopTextEng);
      appendIfNotNull('LandingsPage', organization.landingsPage);
      appendIfNotNull('LandingsPageEng', organization.landingsPageEng);
      appendIfNotNull('WelcomeTextApp', organization.welcomeTextApp);
      appendIfNotNull('WelcomeTextAppEng', organization.welcomeTextAppEng);
      appendIfNotNull('ClosedShopTextApp', organization.closedShopTextApp);
      appendIfNotNull(
        'ClosedShopTextAppEng',
        organization.closedShopTextAppEng
      );
      appendIfNotNull('SeasonName', organization.seasonName);
      appendIfNotNull('ThankYouTextCompany', organization.thankYouTextCompany);
      appendIfNotNull(
        'ThankYouTextCompanyEng',
        organization.thankYouTextCompanyEng
      );
      appendIfNotNull('ExtraInfoProfile', organization.extraInfoProfile);
      appendIfNotNull('ExtraInfoProfileEng', organization.extraInfoProfileEng);
      appendIfNotNull('Active', organization.active);

      if (organization.app) {
        appendIfNotNull('StartApp', CommonHelperService.GenerateISODateTimeString(organization.startApp, null));
        appendIfNotNull('EndApp', CommonHelperService.GenerateISODateTimeString(organization.endApp, null));
      }

      if (
        organization.budgetGroupIds &&
        organization.budgetGroupIds?.length != 0
      ) {
        organization.budgetGroupIds.forEach((item) => {
          formData.append('BudgetGroupIds', item.toString());
        });
      } else {
        formData.append('BudgetGroupIds', '0');
      }

      if (organization.faqGroupIds && organization.faqGroupIds?.length != 0) {
        organization.faqGroupIds.forEach((item) => {
          formData.append('FaqGroupIds', item.toString());
        });
      } else {
        formData.append('FaqGroupIds', '0');
      }

      if (this.logoFile != null) {
        formData.append('Logo', this.logoFile);
      }

      this.apiService.updateOrganization(formData).subscribe(
        (data) => {
          if (data.requestResult == 1) {
            this.getAllOrganizations();
            this.resetForm();
            this.closeDetails();
            this.showSuccess('update');
          } else {
            this.errorMessage = data.responseTip;
            this.showError();
          }
        },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        }
      );
    } else {
      this.organizationForm.markAllAsTouched();
      this.errorMessage = 'Please fill all the required fields';
      this.showError();
    }
  }

  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  //Update Organization Status
  updateStatus(id: number) {
    const formData = new FormData();
    formData.append('organizationId', id.toString());

    this.apiService.updateOrganizationStatus(formData).subscribe(
      (data) => {
        if (data.requestResult == 1) {
          this.showSuccess('statusUpdate');
          this.getAllOrganizations();
        } else {
          this.errorMessage = data.responseTip;
          this.showError();
        }
      },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      }
    );
  }

  //get FAQ group list for dropdown
  getFaqGroupList() {
    this.apiService.getAllFAQGroupsForDropdown().subscribe(
      (data) => {
        if (data.requestResult == 1) {
          this.faqGroupList = data.result;
        } else {
          this.errorMessage = data.responseTip;
          this.showError();
        }
      },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      }
    );
  }
  //get Budget group list for dropdown
  getBudgetGroupList() {
    this.apiService.getAllBudgetGroupsForDropdown().subscribe(
      (data) => {
        if (data.requestResult == 1) {
          this.budgetGroupList = data.result;
        } else {
          this.errorMessage = data.responseTip;
          this.showError();
        }
      },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      }
    );
  }

  //open the modal or dialog box to enter a name to copy an organization with a different name
  openDialog(id: number) {
    const dialogRef = this.dialog.open(DialogWithForm, {
      data: { showKeepProduct: true },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result && result.name) {
        this.copyOrganization(id, result.name, result.keepProduct);
      }
    });
  }

  //copy an organization but with a different name
  copyOrganization(id: number, name: string, keepProduct: boolean) {
    const formData = new FormData();
    formData.append('Id', id.toString());
    formData.append('Name', name);
    formData.append('copyProducts', keepProduct.toString());

    this.apiService.copyOrganization(formData).subscribe(
      (data) => {
        if (data.requestResult == 1) {
          this.getAllOrganizations();
          this.showSuccess('copy');
        } else {
          this.errorMessage = data.responseTip;
          this.showError();
        }
      },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      }
    );
  }
  /**
   * After view init
   */
  ngAfterViewInit(): void {
    if (this._sort && this._paginator) {
      setTimeout(() => {
        // Set the initial sort
        this._sort.sort({
          id: 'id',
          start: 'desc',
          disableClear: true,
        });
      });

      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;
          this.pageIndex = 0;

          //reset and close the form if it is open
          this.resetForm();
          this.closeDetails();

          // set the sort column and sort order
          this.sortColumn = this.getSortColumn(this._sort.active);
          this.sortOrder = this._sort.direction === 'asc' ? 2 : 1;

          // Close the details
          this.closeDetails();

          this.getAllOrganizations();
        });
    }
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
    if (this.searchSubscription) {
      this.searchSubscription.unsubscribe();
    }
  }

  getSortColumn(name: string) {
    switch (name) {
      case 'name':
        return 1;
        break;
      case 'startShop':
        return 2;
        break;
      case 'endShop':
        return 3;
        break;
      case 'startApp':
        return 4;
        break;
      case 'endApp':
        return 5;
        break;
      case 'app':
        return 6;
        break;
      case 'url':
        return 7;
        break;
      default:
        return 0;
    }
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggle product details
   *
   * @param id
   */
  toggleDetails(id: number): void {
    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct.id === id) {
      // Close the details
      this.closeDetails();
      return;
    }
    this.createOrganization = false;

    const myMap = new Map(this.OrganizationArray.map((obj) => [obj.id, obj]));

    this.selectedProduct = myMap.get(id);
    this.organizationForm.patchValue(this.selectedProduct);
    this.logo = this.selectedProduct.logo;
  }

  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
  }

  /**
   * Fetches the current season from the API and stores its ID.
   * This is used to set the default season ID for new organizations.
   */
  getCurrentSeason(): void {
    this.apiService.getCurrentSeason().subscribe(
      (data) => {
        if (data && data.season) {
          // Based on the API response, the season.name field contains the ID we need
          this.currentSeasonId = data.season.name;
          //console.log(('Current season ID set to:', this.currentSeasonId);
          this._changeDetectorRef.markForCheck();
        }
      },
      (error) => {
        this.errorMessage = 'Failed to fetch current season';
        console.error('Error fetching current season:', error);
        this.showError();
      }
    );
  }

  //reset form
  resetForm() {
    const preservedId = this.organizationForm.get('id').value ?? 0;
      this.organizationForm.reset({
      id: preservedId,
      app: false,
      incExVat: false,
      active: false,
      seasonName: this.currentSeasonId
    });
    if(preservedId != 0){
      this.organizationForm.markAllAsTouched();
    }
    this.logo = '';
    this.logoFile = null;
  }

  /**
   * Delete the selected product using the form data
   */
  async deleteSelectedProduct(id: number | null, isFromDeleteBtn = false): Promise<void> {

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Organization');

    if (!confirmed) {
      return;
    }

    if (!isFromDeleteBtn) {
      this.selectedOrganizations.clear();
      this.selectedOrganizations.set(id, true)
    }

    this.deleteOrganizations();

    // Close the details
    this.closeDetails();

  }

  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }

  public GetFileOnLoad(event: any, inputBox: string) {
    if (event.target.files && event.target.files[0]) {
      var file = event.target.files[0] as File;
      this.logoFile = file;
      this.logo = URL.createObjectURL(file);
    }
  }

  removeImageFile(inputBox: string) {
    this.logo = '';
    this.logoFile = null;
    var element = document.getElementById(inputBox) as HTMLInputElement | null;
    if (element != null) {
      element.value = '';
    }
  }

  onSelectionChange(value: any) {
    if (value && value != '') {
      this.organizationForm.get(value).markAsTouched();
    }
  }
}
