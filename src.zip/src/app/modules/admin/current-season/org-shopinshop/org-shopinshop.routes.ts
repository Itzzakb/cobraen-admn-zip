import { Routes } from "@angular/router";
import { OrgShopinshopComponent } from "./org-shopinshop.component";

export default [
    {
        path: '',
        component: OrgShopinshopComponent
    }
] as Routes