import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrgShopinshopComponent } from './org-shopinshop.component';

describe('OrgShopinshopComponent', () => {
  let component: OrgShopinshopComponent;
  let fixture: ComponentFixture<OrgShopinshopComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OrgShopinshopComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrgShopinshopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
