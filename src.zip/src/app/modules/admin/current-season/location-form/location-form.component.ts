import {
  CommonModule,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormsModule,
  NgModel,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatTooltipModule } from '@angular/material/tooltip';

import {
  Subject,
  Subscription,
} from 'rxjs';
import { ChristmasFair, GiftPickupLocation, Location, OrganizationList, TimeSlot } from 'app/shared/types/interfaces';
import { ToastrService } from 'ngx-toastr';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { NgxMatTimepickerModule } from 'ngx-mat-timepicker';
import { SearchableDropdownComponent } from 'app/shared/components/searchable-dropdown/searchable-dropdown.component';
import { DeleteConfirmationService, DeleteTypes } from 'app/shared/services/delete-confirmation.service';

@Component({
  selector: 'app-location-form',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 80px 1fr 1fr 100px 120px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 80px 1fr 1fr 100px 120px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 80px 1fr 1fr 100px 120px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 80px 1fr 1fr 100px 120px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    MatTooltipModule,
    MatDatepickerModule,
    NgxMatTimepickerModule,
    CommonModule,
    SearchableDropdownComponent
  ],
  templateUrl: './location-form.component.html',
  styleUrl: './location-form.component.scss',
})
export class LocationFormComponent
  implements OnInit, OnDestroy {

  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: TimeSlot | null = null;
  selectedProductForm: UntypedFormGroup;


  locationGroup: UntypedFormGroup;
  giftGroup: UntypedFormGroup;
  selectedChristmasFairLoactions: Location[] = [];
  selectedChristmasFairGiftLoactions: GiftPickupLocation[] = [];
  selectedLocation: Location;
  selectedGiftLocation: GiftPickupLocation;
  selectedLocationTimeSlots: TimeSlot[] = [];
  selectedGiftLocationTimeSlots: TimeSlot[] = [];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  christmasFairsArray: ChristmasFair[] = [];
  selectedChristmasFairs: Map<number, boolean> = new Map(); // Tracks selected brands
  allSelected: boolean = false;

  searchQuery: string = '';
  searchSubject = new Subject<string>();
  searchSubscription: any;



  organizationList: OrganizationList[] = [];
  selectedOrganizations: number[] = [];

  createTimeslot = false;
  minDate: Date;

  locatioName: string = '';


  errorMessage = '';

  isValidTime: boolean = true;

  @Input() timeSlotsList: Location;
  @Input() selctedOrganizationsFromParent: number[];
  @Input() organizationLists: OrganizationList[];
  @Input() dynamicOrganizationsEmitter: EventEmitter<any>;

  @Output() locationTimeSlotsEmitter: EventEmitter<any> = new EventEmitter<any>();

  @ViewChild('locName') locName!: NgModel;


  private SubscriptionListener: Subscription;

  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _deleteConfirmationService: DeleteConfirmationService,
    private _formBuilder: UntypedFormBuilder,
    private toastr: ToastrService
  ) { }

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.selectedProductForm = this._formBuilder.group({
      id: [''],
      date: [new Date(), Validators.required],
      startTime: ['', Validators.required],
      endTime: ['', Validators.required],
      capacity: ['', Validators.required],
      organizations: [[], Validators.required],  // Multiselect
    });

    this.selectedOrganizations = [];

    this.SubscriptionListener = this.dynamicOrganizationsEmitter.asObservable().subscribe((data: number[]) => {

      //Update organizations list when updated from parent
      this.organizationList = this.getOrganizations(data);
      this.selectedProduct.organizations = this.selectedProduct.organizations.filter(y => data.includes(y.id));
      this.selectedOrganizations = this.selectedProduct.organizations.map(y => y.id);
    });

    this.minDate = new Date();
    this.locatioName = this.timeSlotsList.locationName;
    this.createTimeslot = this.timeSlotsList.locationName == '';

  }

  showSuccess(type: string) {
    const message = type === 'create' ? 'Brand created successfully.' : (type == 'update' ? 'Brand updated successfully.' : 'Brand deleted successfully.');
    this.toastr.success(message, 'Success!');
  }
  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }


  toggleTimeslotForm() {
    //close the edit form if open
    this.closeDetails();

    this.createTimeslot = !this.createTimeslot;
    if (this.createTimeslot) {
      const newProduct = {
        id: 0,
        date: '',
        startTime: '',
        endTime: '',
        capacity: 0,
        organizations: []
      }
      // Go to new product
      this.selectedProduct = newProduct;

      this.organizationList = this.getOrganizations(this.selctedOrganizationsFromParent);

      // Fill the form
      this.selectedProductForm.patchValue(newProduct);

      // Mark for check
      this._changeDetectorRef.markForCheck();
    } else {
      this.selectedProductForm.reset();
    }
  }


  /**
   * Updates the list of time slots by removing the time slot with the ID matching the selected product's ID
   * and adding the current form's raw value as a new time slot. The updated list is then sorted by ID in ascending order.
   *
   * @remarks
   * - The function assumes that `this.timeSlotsList.timeSlots` is an array of objects, each containing an `id` property.
   * - The `this.selectedProductForm` is expected to be a form group with an `id` control and other relevant fields.
   *
   * @example
   * // Before calling updateTimeslots:
   * this.timeSlotsList.timeSlots = [{ id: 1, name: 'Slot 1' }, { id: 2, name: 'Slot 2' }];
   * this.selectedProductForm.get('id').value = 2;
   * this.selectedProductForm.getRawValue() = { id: 2, name: 'Updated Slot 2' };
   *
   * // After calling updateTimeslots:
   * this.timeSlotsList.timeSlots = [{ id: 1, name: 'Slot 1' }, { id: 2, name: 'Updated Slot 2' }];
   */
  updateTimeslots() {

    if (this.selectedProductForm.valid) {
      if (this.selectedProductForm.getRawValue().startTime > this.selectedProductForm.getRawValue().endTime) {
        this.errorMessage = `'Time from' should be less than 'Time till'.`;
        this.showError();

        return;
      }
      this.timeSlotsList.locationName = this.locatioName;

      this.timeSlotsList.timeSlots = this.timeSlotsList.timeSlots.filter(item => item.id != this.selectedProductForm.get('id').value);
      this.timeSlotsList.timeSlots.push(this.selectedProductForm.getRawValue());
      this.timeSlotsList.timeSlots.sort((a, b) => a.id - b.id);

      this.emitTimeslots(this.timeSlotsList);
      this.closeDetails();
      this.resetForm();
    } else {
      this.selectedProductForm.markAllAsTouched();
      this.locName.control.markAsTouched();
      this.errorMessage = 'Please fill all required fields.';
      this.showError();
    }

  }

  saveTimeslots() {
    if (this.selectedProductForm.valid) {
      if (this.timeSlotsList.locationName == '' && this.timeSlotsList.timeSlots.length == 0) {
        this.timeSlotsList.id = 0;
      }
      if (this.selectedProductForm.getRawValue().startTime > this.selectedProductForm.getRawValue().endTime) {
        this.errorMessage = `'Time from' should be less than 'Time till'.`;
        this.showError();

        return;
      }
      this.timeSlotsList.locationName = this.locatioName;
      this.timeSlotsList.timeSlots.push(this.selectedProductForm.getRawValue());
      this.emitTimeslots(this.timeSlotsList);
      this.closeDetails();
      this.toggleTimeslotForm();
      this.resetForm();
    } else {
      this.selectedProductForm.markAllAsTouched();
      this.locName.control.markAsTouched();
      this.errorMessage = 'Please fill all required fields.';
      this.showError();
    }
  }


  emitTimeslots(timeslotList: Location) {
    this.locationTimeSlotsEmitter.emit(timeslotList);
  }


  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * After view init
   */


  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this.SubscriptionListener?.unsubscribe();
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggle product details
   *
   * @param id
   */
  toggleDetails(timeslot: TimeSlot): void {
    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct === timeslot) {
      // Close the details
      this.closeDetails();
      return;
    }

    this.selectedProduct = this.timeSlotsList.timeSlots.find(slot => slot === timeslot);
    this.selectedProductForm.patchValue(this.selectedProduct);
    this.selectedOrganizations = this.selectedProduct.organizations.map(y => y.id);
    this.organizationList = this.getOrganizations(this.selctedOrganizationsFromParent);
  }

  getOrganizations(orgs: number[]): OrganizationList[] {
    return this.organizationLists.filter(org => orgs.includes(org.id));
  }

  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
  }


  //reset the form
  resetForm() {
    this.selectedProductForm.reset();
  }

  /**
   * Delete the selected product using the form data
   */
  async deleteSelectedProduct(timeSlot: TimeSlot): Promise<void> {

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('DateTime', DeleteTypes.CustomNoTitle, 'Are you sure you want to remove this DateTime?',);

    if (confirmed) {

      var removedIndex = this.timeSlotsList.timeSlots.indexOf(timeSlot);

      if (removedIndex !== -1) {
        this.timeSlotsList.timeSlots.splice(removedIndex, 1);
      }
    }
  }


  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }

  onSelectionChange(value: any) {
    if (value && value != '') {
      this.selectedProductForm.get(value).markAsTouched();
    }
  }

  onDropdownBlur() {
    this.selectedProductForm.get('organizations').markAsTouched();
  }

}
