import {
  AsyncPipe,
  CommonModule,
  CurrencyPipe,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormsModule,
  NgModel,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDatepickerModule } from '@angular/material/datepicker';

import {
  InventoryCategory,
  InventoryPagination,
  InventoryProduct,
  InventoryTag,
  InventoryVendor,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  takeUntil,
} from 'rxjs';
import { products } from 'app/mock-api/apps/ecommerce/inventory/data';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { Answer, ChristmasFairList, ChristmasFairQuestion, OrganizationList, Question } from 'app/shared/types/interfaces';
import { QuestionCopyForm } from 'app/shared/utils/copy-question-form/copy-question-form.component';
import { MatDialog } from '@angular/material/dialog';
import { SearchableDropdownComponent } from 'app/shared/components/searchable-dropdown/searchable-dropdown.component';
import { DeleteConfirmationService, DeleteTypes } from 'app/shared/services/delete-confirmation.service';

@Component({
  selector: 'app-questions',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 1fr 88px;
        width: 100%;
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    MatTooltipModule,
    MatDatepickerModule,
    CommonModule,
    SearchableDropdownComponent
  ],
  templateUrl: './questions.component.html',
  styleUrl: './questions.component.scss',
})
export class QuestionsComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  products$: Observable<InventoryProduct[]>;

 
  categories: InventoryCategory[];
  filteredTags: InventoryTag[];
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: InventoryPagination;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: ChristmasFairQuestion | null = null;
  selectedProductForm: UntypedFormGroup;
  tags: InventoryTag[];
  tagsEditMode: boolean = false;
  vendors: InventoryVendor[];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  christmasFairQuestionsArray: ChristmasFairQuestion[] = [];
    selectedChristmasFairs: Map<number, boolean> = new Map(); // Tracks selected brands
    allSelected: boolean = false;
  
    searchQuery: string = '';
    searchSubject = new Subject<string>();
    searchSubscription: any;
  
    // Pagination properties
    pageIndex: number = 0;
    pageSize: number = 10;
    totalCount: number = 0;
    sortOrder: number = 1;
    sortColumn: 'fairname' | 'organizationname';
  
    organizationList: OrganizationList[] = [];
    christmasFairList: ChristmasFairList[] = [];

    selectedOrganizationId: number | null = null;
    selectedFairId: number | null = null;
    
  
    errorMessage = '';
    isDataLoaded: boolean = false;

    createQuestion: boolean = false;

    questions: Question[] = [];
    selectedQuestion: Question | null = null;

    answers: Answer[] = [];
    selectedAnswer: Answer | null = null;
    selectedQuestionType: string = '';

    selectedQuestionForm: UntypedFormGroup;
    atleastOneAnswerValidation: boolean = false;
  
    @ViewChild('headerPaginator') headerPaginator!: MatPaginator;
    @ViewChild('footerPaginator') footerPaginator!: MatPaginator;

    @ViewChild('questionType') questionType!: NgModel;
    

  /**
   * Constructor
   */
  constructor(
    private _formBuilder: UntypedFormBuilder,
    private _deleteConfirmationService: DeleteConfirmationService,
    private apiService: ApiService,
    private toastr: ToastrService,
    private dialog: MatDialog,
  ) {}

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.selectedProductForm = this._formBuilder.group({
      fairId: ['', ],
      organizationId: ['', ],
      organizationName: ['', ],
      fairName: ['', ],
      eventNameDutch: ['', [Validators.required]],
      eventNameEnglish: ['', [Validators.required]],
      introTextDutch: ['', [Validators.required]],
      introTextEnglish: ['', [Validators.required]],
    });

    this.selectedQuestionForm = this._formBuilder.group({
      id: [''],
      questionDutch: ['', [Validators.required]],
      questionEnglish: ['', [Validators.required]],
      coming: [false],
      christmasGiftPickup: [false],
      isMandatory: [false],
    });




     //get all organizations 
    this.getAllOrganizations();

    //get all christmas fairs
    this.getAllChristmasFairs();
    
        // Debounce search input to optimize API calls
        this.searchSubscription = this.searchSubject
          .pipe(debounceTime(300), distinctUntilChanged())
          .subscribe(query => {
            this.searchQuery = query;
            this.pageIndex = 0; // Reset to first page on new search
            this.footerPaginator.firstPage();
            this.getAllChristmasFairQuestions();
          });
    
  }

  getAllOrganizations() {
    this.apiService.getAllOrganizations().subscribe((data) => {
      this.organizationList = data.result;
    },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      })
  }

  getAllChristmasFairs() {
    this.apiService.getAllChristmasFairs().subscribe((data) => {
      this.christmasFairList = data.result.data;
    },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      })
  }

  // get all christmas fair questions
  getAllChristmasFairQuestions() {
    const params = {
      sortColumn: this.sortColumn,
      pageIndex: this.pageIndex,
      pageSize: this.pageSize,
      sortOrder: this.sortOrder,
      searchQuery: this.searchQuery,
      orgId: this.selectedOrganizationId,
      fairId: this.selectedFairId
    }
    this.apiService.getChristmasFairQuestions(params).subscribe((data) => {
      this.christmasFairQuestionsArray = data.result.data;
      this.pageIndex = data.result.pageIndex;
      this.pageSize = data.result.pageSize;
      this.totalCount = data.result.count;
      this.isDataLoaded = true;
    }, 
  (error)=>{
    this.errorMessage = error.error.responseTip;
    this.showError();
  });
  }

  openDialog(sourceFairId: number, sourceOrgId: number) {
    const dialogRef = this.dialog.open(QuestionCopyForm, {
      data: {
        fairList: this.christmasFairList.filter(y => y.organizations != null && y.organizations.length > 0), defaultFairId: sourceFairId
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result && result.fairId && result.orgId) {
        this.copyChristmasFairQuestion(sourceFairId, sourceOrgId, result.fairId, result.orgId);
      }
    });
  }

  copyChristmasFairQuestion(sourceFairId: number, sourceOrgId: number, targetFairId: number, targetOrgId: number) {
    let requestBody = {
      "sourceFairId": sourceFairId,
      "sourceOrganizationId": sourceOrgId,
      "targetFairId": targetFairId,
      "targetOrganizationId": targetOrgId
    }

    this.apiService.copyChristmasFairQuestion(requestBody).subscribe((data) => {
      if (data.requestResult == 1) {
        this.getAllChristmasFairQuestions();
        this.showSuccess('copy');
      } else {
        this.errorMessage = data.responseTip;
        this.showError()
      }
    },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      })
  }

  showSuccess(type: string) {
    switch (type) {
      case 'update':
        this.toastr.success('Christmas fair setting updated successfully.', 'Success!');
        break;
      case 'copy':
        this.toastr.success('Christmas fair setting copied successfully.', 'Success!');
        break;  
      default:
        this.toastr.success('Christmas fair setting deleted successfully.', 'Success!');
        break;
    }    
  }

  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }

  // Triggers a search operation with the provided query string.
  onSearch(query: string): void {
    this.closeDetails();
    this.searchSubject.next(query);
  }

  // Handle pagination changes
  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.getAllChristmasFairQuestions();
  }
  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * After view init
   */
  ngAfterViewInit(): void {
    if (this._sort && this._paginator) {
      setTimeout(()=>{
        // Set the initial sort
      this._sort.sort({
        id: 'name',
        start: 'asc',
        disableClear: true,
      });
      })


      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;
          this.pageIndex = 0;

          //reset and close the form if it is open
          this.resetForm();
          this.closeDetails();

          // set the sort column and sort order
          this.sortColumn = this._sort.active == 'name' ? 'fairname' : 'organizationname';
          this.sortOrder = this._sort.direction === 'asc' ? 2 : 1;

          // Close the details
          this.closeDetails();

          this.getAllChristmasFairQuestions();
        });

      
    }
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggle product details
   *
   * @param id
   */
  toggleDetails(fairId: number, orgId: number): void {
    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct.fairId === fairId && this.selectedProduct.organizationId === orgId) {
      // Close the details
      this.closeDetails();
      return;
    }

    const myMap = new Map(this.christmasFairQuestionsArray.map(obj => [`${obj.fairId}-${obj.organizationId}`, obj]));

    this.selectedProduct = myMap.get(`${fairId}-${orgId}`);
    this.questions = this.selectedProduct.questions;
    this.selectedProductForm.patchValue(this.selectedProduct);
  }

  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
  }

  resetForm(){
    let property = this.selectedProductForm.getRawValue();
    this.selectedProductForm.reset({
      id : property.id,
      fairId : property.fairId,
      fairName : property.fairName,
      organizationId : property.organizationId,
      organizationName : property.organizationName,
    });
    if(property.id != 0){
      this.selectedProductForm.markAllAsTouched();
    }
    this.selectedQuestionForm.reset();
    this.selectedQuestion = null;
    this.questions = [];
    this.selectedQuestionType = '';
  }

  resetQuestionForm(){
    this.selectedQuestionForm.reset();
    this.selectedQuestionType = '';
    this.answers = 
    [ {
        id: 0,
        answerDutch: "",
        answerEnglish: ""
      }];
    }
      


  closeQuestionDetails(): void {
    this.selectedQuestion = null;
    this.selectedQuestionForm.reset();
  }


  toggleQuestionDetails(question: Question): void {
    
    this.createQuestion = false;
    
    if (this.selectedQuestion === question) {
      this.closeQuestionDetails();
      return;
    }

    this.selectedQuestion = this.questions.find(y => y === question);

    this.answers = this.selectedQuestion.answers.length > 0 ? this.selectedQuestion.answers :
      [{
        id: 0,
        answerDutch: "",
        answerEnglish: ""
      }];

    this.selectedQuestionType = this.selectedQuestion.questionType;

    this.selectedQuestionForm.patchValue(this.selectedQuestion);
  }

  async deleteQuestions(question: Question) {

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Question', DeleteTypes.ItemNoTitle);

    if (!confirmed) {
      return;
    }

    var removedIndex = this.questions.indexOf(question);

    if (removedIndex !== -1) {
      this.questions.splice(removedIndex, 1);
    }
  }

  addMulitpleChoiceAnswer() {
    var ans: Answer = {
      id: 0,
      answerDutch: '',
      answerEnglish: ''
    }
    this.answers.push(ans);
  }

  async deleteMulitpleChoiceAnswer(answer: Answer) {
    
    var removedIndex = this.answers.indexOf(answer);

    var confirmed = answer.id == 0 && !answer.answerDutch && !answer.answerEnglish;
        
    if (!confirmed) {
      confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Option', DeleteTypes.ItemNoTitle);
    }
    
    if (!confirmed) {
      return;
    }
    
    if (removedIndex !== -1) {
      this.answers.splice(removedIndex, 1);
    }
  }


  updateChristmasFairQuestion() {
    if (this.selectedProductForm.valid) {
      // filter empty answers from the questions array
      this.questions = this.questions.filter((question) => {
        question.answers = question.answers.filter((answer) => answer.answerEnglish.trim() != '' && answer.answerDutch.trim() != '');
          return question;
      });

      const christmasFairQuestion = this.selectedProductForm.getRawValue();
      const body = {
        "christmasFairId": christmasFairQuestion.fairId,
        "organizationId": christmasFairQuestion.organizationId,
        "eventNameDutch": christmasFairQuestion.eventNameDutch,
        "eventNameEnglish": christmasFairQuestion.eventNameEnglish,
        "introTextDutch": christmasFairQuestion.introTextDutch,
        "introTextEnglish": christmasFairQuestion.introTextEnglish,
        "questions": this.questions
      }


      this.apiService.updateChristmasFairQuestion(body).subscribe((data) => {
        if (data.requestResult == 1) {
          this.getAllChristmasFairQuestions();
          // this.resetForm();
          this.closeDetails();
          this.showSuccess('update');
        } else {
          this.errorMessage = data.responseTip;
          this.showError();
        }
      },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        });
    } else {
      this.selectedProductForm.markAllAsTouched();
      this.errorMessage = 'Please fill all the required fields.';
      this.showError();
    }
  }

  toggleCreateQuestion() {
    this.closeQuestionDetails();

    this.createQuestion = !this.createQuestion;
    if (this.createQuestion) {
      this.selectedQuestionForm.reset();
      this.selectedQuestionForm.patchValue({
        questionType: '',
        coming: false,
        christmasGiftPickup: false,
        isMandatory: false,
        questionDutch: '',
        quesionEnglish: '',
      });

      this.answers = 
    [{
        id: 0,
        answerDutch: "",
        answerEnglish: ""
      }];
    this.selectedQuestionType = '';
    }
  }

  answerValidationBasedOnType() {
    this.atleastOneAnswerValidation = true;
    if(this.selectedQuestionType == '2'){
      if(this.answers.length == 1 && this.answers[0].answerEnglish.trim() == '' && this.answers[0].answerDutch.trim() == ''){
        this.atleastOneAnswerValidation = false;
        return;
      }
    }
  }

  saveQuestion() {
    this.answerValidationBasedOnType();
    if (this.selectedQuestionForm.valid && this.selectedQuestionType != '' && this.atleastOneAnswerValidation) {
      if (this.checkIfAllAnswersFilled()) {
        this.errorMessage = 'Please fill all the answers.';
        this.showError();
        return;
      }
      let question = this.selectedQuestionForm.getRawValue();
      question.answers = (this.answers.length == 1 && this.answers[0].answerEnglish.trim() == '' && this.answers[0].answerDutch.trim() == '') ? [] : this.answers;
      question.questionType = this.selectedQuestionType;
      this.questions.push(question);

      this.createQuestion = false;
      this.closeQuestionDetails();
    } else {
      if (this.atleastOneAnswerValidation) {
        this.errorMessage = 'Please fill all the required fields.';
      }
      else {
        this.errorMessage = 'Please add at least one answer';
      }
      this.selectedQuestionForm.markAllAsTouched();
      this.questionType.control?.markAsTouched();
      this.showError();
    }
  }

  updateQuestion() {
    this.answerValidationBasedOnType();
    if (this.selectedQuestionForm.valid && this.selectedQuestionType != '' && this.atleastOneAnswerValidation) {
      if (this.checkIfAllAnswersFilled()) {
        this.errorMessage = 'Please fill all the answers.';
        this.showError();
        return;
      }
      let question = this.selectedQuestionForm.getRawValue();
      question.answers = (this.answers.length == 1 && this.answers[0].answerEnglish.trim() == '' && this.answers[0].answerDutch.trim() == '') ? [] : this.answers;
      question.questionType = this.selectedQuestionType;
      this.questions = this.questions.filter((item) => item.id != question.id);
      this.questions.push(question);
      this.questions.sort((a, b) => a.id - b.id);

      this.closeQuestionDetails();
    }
    else {
      if (this.atleastOneAnswerValidation) {
        this.errorMessage = 'Please fill all the required fields.';
      }
      else {
        this.errorMessage = 'Please add at least one answer';
      }
      this.selectedQuestionForm.markAllAsTouched();
      this.questionType.control.markAsTouched();
      this.showError();
    }
  }


  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }

  multiDeleteDisable = true;
  checkAll: boolean;
  toggleCheckAll() {
    this.multiDeleteDisable = !this.multiDeleteDisable;
    if (this.checkAll) {
      products.forEach((item) => {
        this.checkedItems.push(item.barcode);
      });
    } else {
      this.checkedItems = [];
    }
  }

  checkedItems = [];

  checked(barcode: string) {
    if (this.checkedItems.includes(barcode)) {
      let newArray = this.checkedItems.filter((item) => {
        item != barcode;
      });
      this.checkedItems = newArray;
    } else {
      this.checkedItems.push(barcode);
    }
    this._paginator.pageSize == this.checkedItems.length
      ? (this.checkAll = true)
      : (this.checkAll = false);
  }
  onSelectionChange(value: any) {
    if(value && value !=''){
        this.selectedProductForm.get(value).markAsTouched();      
    }
  }

  checkIfAllAnswersFilled(){
    // Check if all answers are filled for multiple choice question type
    let isEmptyAnswers = this.answers.some((answer) => 
      (answer.answerEnglish.trim() !== '' && answer.answerDutch.trim() === '') || 
      (answer.answerEnglish.trim() === '' && answer.answerDutch.trim() !== '') 
    );
    return isEmptyAnswers && this.selectedQuestionType == '2';
  }
}
