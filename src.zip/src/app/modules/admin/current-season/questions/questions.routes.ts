import { Routes } from "@angular/router";
import { QuestionsComponent } from "./questions.component";

export default [
    {
        path: '',
        component: QuestionsComponent
    }
] as Routes