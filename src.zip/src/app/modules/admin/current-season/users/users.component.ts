import {
  AsyncPipe,
  CommonModule,
  CurrencyPipe,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatTooltipModule } from '@angular/material/tooltip';

import {
  InventoryCategory,
  InventoryPagination,
  InventoryProduct,
  InventoryTag,
  InventoryVendor,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  takeUntil,
} from 'rxjs';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { budgetGroupList, CommonDropdownItem, country, OrganizationList, User } from 'app/shared/types/interfaces';
import { SearchableDropdownComponent } from 'app/shared/components/searchable-dropdown/searchable-dropdown.component';
import { DeleteConfirmationService } from 'app/shared/services/delete-confirmation.service';

@Component({
  selector: 'app-users',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 1fr 1fr 13% 13% 80px 1fr 136px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 1fr 1fr 13% 13% 80px 1fr 136px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 1fr 1fr 13% 13% 80px 1fr 136px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 1fr 1fr 13% 13% 80px 1fr 136px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    MatTooltipModule,
    CommonModule,
    SearchableDropdownComponent
  ],
  templateUrl: './users.component.html',
  styleUrl: './users.component.scss',
})
export class UsersComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  products$: Observable<InventoryProduct[]>;

  categories: InventoryCategory[];
  filteredTags: InventoryTag[];
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: InventoryPagination;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: User | null = null;
  selectedProductForm: UntypedFormGroup;
  tags: InventoryTag[];
  tagsEditMode: boolean = false;
  vendors: InventoryVendor[];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  usersArray: User[] = [];
    selectedUsers: Map<string, boolean> = new Map(); // Tracks selected Users
    allSelected: boolean = false;
  
    searchQuery: string = '';
    searchSubject = new Subject<string>();
    searchSubscription: any;
  
    // Pagination properties
    pageIndex: number = 0;
    pageSize: number = 10;
    totalCount: number = 0;
    sortOrder: number = 1;
    sortColumn: number = 0;

    countryList: country [] = [];
    
  
    createUser = false;

    errorMessage = '';
    isDataLoaded: boolean = false;

    organizationList: OrganizationList[] = [];

    orgBudgetGroupList: budgetGroupList[] = [];

    eventPartnersList: CommonDropdownItem[] = [];

    isDemo: boolean = false;
    isChristmasFairUser: boolean = false;

    patternErrorMessage = `Use a combo of uppercase letters, lowercase letters, numbers, some special characters ( !, @, $, %, ^, &, *, +,#) and minimum length should be 12.`;

    // for filter dropdowns
    selectedOrgId: number = null;
    selectedStatus: number = null;
    selectedSendDateMail: number = null;
  
    @ViewChild('headerPaginator') headerPaginator!: MatPaginator;
    @ViewChild('footerPaginator') footerPaginator!: MatPaginator;

  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _deleteConfirmationService: DeleteConfirmationService,
    private _formBuilder: UntypedFormBuilder,
    private apiService: ApiService,
    private toastr: ToastrService
  ) { }

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.selectedProductForm = this._formBuilder.group({
      id: [''],
      userName: ['', [Validators.required, Validators.pattern(/^\S*$/)]],
      email: [''],
      correspondenceEmail: [''],
      externalId: [''],
      name: [''],
      password: [''],
      street: [''],
      houseNumber: [''],
      zipCode: [''],
      city: [''],
      countryId: [''],
      phone: [''],
      dukatenAvailable: [''],
      organizationId: ['', [Validators.required]],
      budgetGroupId: ['', [Validators.required]],
      active: ['', [Validators.required]],
      typeUser: ['', [Validators.required]],
      remark: [''],
      demo: [false],
      showPrices: [false],
      christmasFairUser: [false],
      userWebShopMailSent: [false],
      eventPartnerId: ['']
    });

    // Not needed as getAllUsers() is alreade calling this
    // this.getOrganizationList();

    //get all countries
    this.getAllCountries();

    //get event partners list
    this.getEventPartnersList();


    // Debounce search input to optimize API calls
    this.searchSubscription = this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe(query => {
        this.searchQuery = query;
        this.pageIndex = 0; // Reset to first page on new search
        this.footerPaginator.firstPage();
        this.getAllUsers();
      });
  }

  getAllCountries(){
    this.apiService.getAllCountries().subscribe((data) => {
      this.countryList = data.result;
    },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      });
  }

  getOrganizationBudgetGroupList(id: number){
    this.selectedProductForm.get('budgetGroupId').setValue(null);
    this.orgBudgetGroupList = [];
    this.apiService.getOrganizationBudgetGroups(id).subscribe((data) => {
      this.orgBudgetGroupList = data.result;
    },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      });
  }

  getAllBudgetGroups(){
    this.orgBudgetGroupList = [];

    this.apiService.getAllBudgetGroupsForDropdown().subscribe((data) => {
      this.orgBudgetGroupList = data.result;
    },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      });
  }

  getEventPartnersList(){
    this.apiService.getEventPartners().subscribe((data) => {
      this.eventPartnersList = data.result;
    },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      });
  }

  // Toggle selection for a single User
  toggleSelection(UserId: string) {
    if (this.selectedUsers.has(UserId)) {
      this.selectedUsers.delete(UserId); // Unselect
    } else {
      this.selectedUsers.set(UserId, true); // Select
    }
    this.updateSelectAllState();
  }

  // Toggle Select All
  toggleSelectAll() {
    if (this.allSelected) {
      this.selectedUsers.clear(); // Unselect all
    } else {
      this.usersArray.forEach(user => this.selectedUsers.set(user.id, true)); // Select all
    }
    this.allSelected = !this.allSelected;
  }

  // Update the "Select All" checkbox state
  updateSelectAllState() {
    this.allSelected = this.selectedUsers.size === this.usersArray.length;
  }

  //get selectedUsers' Ids
  getSelectedUserIds(): string[] {
    return Array.from(this.selectedUsers.entries()) // Convert Map to an array of key-value pairs
      .filter(([id, isSelected]) => isSelected) // Filter selected Users
      .map(([id]) => id); // Extract only the IDs
  }
  //Deletes the selected User entries by calling the API service. If the deletion is successful, it clears the selected Users map.
  deleteUsers(){
    this.apiService.deleteUser(this.getSelectedUserIds()).subscribe((response)=>{
      if(response.requestResult == 1 ){
        this.selectedUsers = new Map();
        this.getAllUsers();
        this.showSuccess('delete');
      }else{
        this.errorMessage = response.responseTip;
        this.showError();
      }
    }, (error) => {
      this.errorMessage = error.error.responseTip;
      this.showError();
    })
  }

  // get all Users
  getAllUsers() {
    // If organization list is empty, fetch it first
    if (this.organizationList.length === 0) {
      this.getOrganizationList(() => this.fetchUsers());
    } else {
      this.fetchUsers();
    }
  }

  // Fetch users data from API
  fetchUsers() {
    const params = {
      sortColumn: this.sortColumn,
      pageIndex: this.pageIndex,
      pageSize: this.pageSize,
      sortOrder: this.sortOrder,
      searchQuery: this.searchQuery,
      organizationId: this.selectedOrgId,
      status: this.selectedStatus,
      sendDateMail: this.selectedSendDateMail
    }
    this.apiService.getUsers(params).subscribe((data) => {
      this.usersArray = data.result.data;
      this.pageIndex = data.result.pageIndex;
      this.pageSize = data.result.pageSize;
      this.totalCount = data.result.count;
      this.isDataLoaded = true;
    });
  }

  showSuccess(type: string) {
    const message = this.getSuccessMessage(type);
    this.toastr.success(message, 'Success!');
  }

    //get success message based on type
    getSuccessMessage(type: string) {
      switch (type) {
        case 'create':
          return 'User created successfully.';
          break;
        case 'update':
          return 'User updated successfully.';
          break;
        case 'delete':
          return 'User deleted successfully.';
          break;
        case 'statusUpdate':
          return 'User status updated successfully.';
          break;
      }
    }
  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }

  // Triggers a search operation with the provided query string.
  onSearch(query: string): void {
    this.createUser = false;
    this.closeDetails();
    this.searchSubject.next(query);
  }

  // Handle pagination changes
  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.getAllUsers();
  }



  /**
   * Sets or clears validation rules for the `organizationId` and `budgetGroupId` fields
   * in the `selectedProductForm` based on the `isChristmasFairUser` flag.
   *
   * - If `isChristmasFairUser` is `false`, the `organizationId` and `budgetGroupId` fields
   *   are marked as required.
   * - If `isChristmasFairUser` is `true`, the validators for these fields are cleared.
   *
   * After modifying the validators, the method ensures that the value and validity
   * of the fields are updated.
   *
   * @remarks
   * This method is useful for dynamically adjusting form validation rules based on
   * user type or context.
   */
  setValidationsForOrgIdAndBudgetGrpId() {
    if (!this.isChristmasFairUser) {
      this.selectedProductForm.get('organizationId')?.setValidators([Validators.required]);
      this.selectedProductForm.get('budgetGroupId')?.setValidators([Validators.required]);
    } else {
      this.selectedProductForm.get('organizationId')?.clearValidators();
      this.selectedProductForm.get('budgetGroupId')?.clearValidators();
    }
  
    // Always update value and validity after changing validators
    this.selectedProductForm.get('organizationId')?.updateValueAndValidity();
    this.selectedProductForm.get('budgetGroupId')?.updateValueAndValidity();
  }
  

  /**
   * Sets or clears validation rules for the 'password' field in the form based on the `createUser` flag.
   * 
   * - If `createUser` is `true`, the 'password' field is required and must match the pattern:
   * After updating the validators, the method ensures the form control's validation state is refreshed.
   */
  setValidationForPassword(){
    if(this.createUser){
      this.selectedProductForm.get('password').setValidators([Validators.required, Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?!.*[,)(={}\\]\\[;'_:><?/ `~]).{12,}$")]);
    }else{
      this.selectedProductForm.get('password').clearValidators();
    }

    this.selectedProductForm.get('password').updateValueAndValidity();
  }


  /**
   * Toggles the state of the create user form. 
   * Resets or populates the form based on the toggle state.
   */
  toggleCreateUserForm() {
    //close the edit form if open
    this.closeDetails();
    
    this.createUser = !this.createUser;
    this.setValidationForPassword();
    this.setValidationsForOrgIdAndBudgetGrpId()
    
    // Load all budget groups for dropdown in create mode
    this.getAllBudgetGroups();
    
    if (this.createUser) {
      const newProduct = {
        id: '',
        userName: null,
        email: null,
        correspondenceEmail: null,
        externalId: null,
        name: null,
        street: null,
        houseNumber: null,
        zipCode: null,
        city: null,
        countryId: null,
        phone: null,
        dukatenAvailable: null,
        organizationId: null,
        budgetGroupId: null,
        active: false,
        typeUser: 2,
        remark: null,
        demo: false,
        showPrices: false,
        christmasFairUser: false,
        userWebShopMailSent: null,
        eventPartnerId: null
      }
      // Go to new product
      this.selectedProduct = newProduct;

      // Fill the form
      this.selectedProductForm.patchValue(newProduct);

      // Mark for check
      this._changeDetectorRef.markForCheck();
    } else {
      this.selectedProductForm.reset();
    }
  }

  getOrganizationList(callback?: () => void) {
    this.apiService.getAllOrganizations().subscribe(
      (data) => {
        this.organizationList = data.result;
        if (callback) {
          callback();
        }
      },
      (error) => {
        this.errorMessage = 'Unable to fetch organization dropdown data';
        this.showError();
      })
  }

  addUser() {
    if(this.selectedProductForm.valid){
    const user = this.selectedProductForm.getRawValue();
    var formData = new FormData();
    const appendIfNotNull = (key: string, value: any) => {
      if (value !== null && value !== undefined) {
        formData.append(key, value);
      }
    };
    appendIfNotNull('UserName', user.userName);
    appendIfNotNull('Email', user.email);
    appendIfNotNull('CorrespondenceEmail', user.correspondenceEmail);
    appendIfNotNull('Password', user.password );
    appendIfNotNull('ExternalId', user.externalId);
    appendIfNotNull('Name', user.name);
    appendIfNotNull('Email', user.email);
    appendIfNotNull('Street', user.street);
    appendIfNotNull('HouseNumber', user.houseNumber );
    appendIfNotNull('ZipCode', user.zipCode);
    appendIfNotNull('City', user.city);
    appendIfNotNull('Phone', user.phone);
    appendIfNotNull('OrganizationId', user.organizationId);
    appendIfNotNull('BudgetGroupId', user.budgetGroupId);
    appendIfNotNull('Active', user.active);
    appendIfNotNull('TypeUser', user.typeUser);
    appendIfNotNull('Remark', user.remark);
    appendIfNotNull('Demo', this.isDemo);
    appendIfNotNull('ShowPrices', user.showPrices);
    appendIfNotNull('ChristmasFairUser', this.isChristmasFairUser);
    appendIfNotNull('EventPartnerId', user.eventPartnerId);
    
    appendIfNotNull('CountryId', user.countryId);
    appendIfNotNull('DukatenAvailable', user.dukatenAvailable );



    this.apiService.createUser(formData).subscribe((data) => {
      if(data.requestResult == 1){
        this.getAllUsers();
        this.resetForm();
        this.closeDetails();
        this.createUser = false;
        this.showSuccess('create');
      }else{
        this.errorMessage = data.responseTip;
        this.showError();
      }
    },
  (error) => {
    this.errorMessage = error.error.responseTip;
    this.showError();
  });
    }else{
      this.selectedProductForm.markAllAsTouched();
      this.errorMessage = "Please fill all the required fields.";
      this.showError();
    }
  }


  updateUser() {
    if(this.selectedProductForm.valid){
    const user = this.selectedProductForm.getRawValue();
    var formData = new FormData();
    const appendIfNotNull = (key: string, value: any) => {
      if (value !== null && value !== undefined) {
        formData.append(key, value);
      }
    };
    formData.append('Id', this.selectedProduct.id);
    appendIfNotNull('UserName', user.userName);
    appendIfNotNull('Email', user.email);
    appendIfNotNull('CorrespondenceEmail', user.correspondenceEmail);
    appendIfNotNull('Password', user.password );
    appendIfNotNull('ExternalId', user.externalId);
    appendIfNotNull('Name', user.name);
    appendIfNotNull('Email', user.email);
    appendIfNotNull('Street', user.street);
    appendIfNotNull('HouseNumber', user.houseNumber );
    appendIfNotNull('ZipCode', user.zipCode);
    appendIfNotNull('City', user.city);
    appendIfNotNull('Phone', user.phone);
    appendIfNotNull('OrganizationId', user.organizationId);
    appendIfNotNull('BudgetGroupId', user.budgetGroupId);
    appendIfNotNull('Active', user.active);
    appendIfNotNull('TypeUser', user.typeUser);
    appendIfNotNull('Remark', user.remark);
    appendIfNotNull('Demo', this.isDemo);
    appendIfNotNull('ShowPrices', user.showPrices);
    appendIfNotNull('ChristmasFairUser', this.isChristmasFairUser);
    appendIfNotNull('EventPartnerId', user.eventPartnerId);
    
    appendIfNotNull('CountryId', user.countryId);
    appendIfNotNull('DukatenAvailable', user.dukatenAvailable );

    this.apiService.updateUser(formData).subscribe((data) => {
      if(data.requestResult == 1){
        this.getAllUsers();
        this.resetForm();
        this.closeDetails();
        this.showSuccess('update');
      }else{
        this.errorMessage = data.responseTip;
        this.showError();
      }
    },
  (error) => {
    this.errorMessage = error.error.responseTip;
    this.showError();
  });
  }else{
    this.selectedProductForm.markAllAsTouched();
    this.errorMessage = "Please fill all the required fields.";
    this.showError();
  }
}

  //Update Product Status
  updateStatus(id: string) {
    const formData = new FormData();
    formData.append('userId', id.toString());

    this.apiService.updateUserStatus(formData).subscribe((data) => {
      if (data.requestResult == 1) {
        this.showSuccess('statusUpdate');
        this.getAllUsers();
      } else {
        this.errorMessage = data.responseTip;
        this.showError();
      }
    },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      })
  }

  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * After view init
   */
  ngAfterViewInit(): void {
    if (this._sort && this._paginator) {
      setTimeout(()=>{
        // Set the initial sort
      this._sort.sort({
        id: '',
        start: 'desc',
        disableClear: true,
      });
      })

      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;
          this.pageIndex = 0;

          //reset and close the form if it is open
          this.resetForm();
          this.closeDetails();

          // set the sort column and sort order
          this.sortColumn = this.getSortColumn(this._sort.active);
          this.sortOrder = this._sort.direction === 'asc' ? 2 : 1;
          

          // Close the details
          this.closeDetails();

          // Get the Brands
          this.getAllUsers();
        });

    }
  }

  getSortColumn(name: string){
    switch(name) {
      case 'userName':
        return 1;
        break;
      case 'name':
        return 2;
        break;
      case 'organization':
        return 3;
        break;
      case 'email':
        return 4;
        break;
      case 'type':
        return 5;
        break;
      case 'userWebShopMailSent':
        return 6;
        break;
      default:
        return 0;
    }
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggle product details
   *
   * @param id
   */
  toggleDetails(id: string): void {
    this.createUser = false;
    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct.id === id) {
      // Close the details
      this.closeDetails();
      return;
    }

    const myMap = new Map(this.usersArray.map(obj => [obj.id, obj]));

    this.selectedProduct = myMap.get(id);
    
    // Load organization's budget groups before patching form values
    if (this.selectedProduct.organizationId) {
      this.getOrganizationBudgetGroupList(this.selectedProduct.organizationId);
    }
    
    this.selectedProductForm.patchValue(this.selectedProduct);
    
    this.isDemo = this.selectedProduct.demo;
    this.isChristmasFairUser = this.selectedProduct.christmasFairUser;

    this.setValidationsForOrgIdAndBudgetGrpId();
    this.setValidationForPassword();
  }

  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
    this.setValidationForPassword();
  }

  resetForm(){
    this.selectedProductForm.reset();
    this.isDemo = false;
    this.isChristmasFairUser = false;
    setTimeout(() => {
      this.selectedProductForm.get('active').setValue(false);
      this.selectedProductForm.get('typeUser').setValue(2);
    });
  }


  /**
   * Delete the selected product using the form data
   */
  async deleteSelectedProduct(id: string | null, isFromDeleteBtn = false): Promise<void> {

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('User');

    if (!confirmed) {
      return;
    }

    if (!isFromDeleteBtn) {

      this.selectedUsers.clear();
      this.selectedUsers.set(id, true)
    }

    this.deleteUsers();
    this.closeDetails();

  }

  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: string, item: any): any {
    return item.id || index;
  }

  /**
   * Returns the organization name for a given organization ID.
   * If the organization ID is null or not found, returns a placeholder string.
   * 
   * @param organizationId - The ID of the organization to look up
   * @returns The name of the organization or a placeholder if not found
   */
  getOrganizationName(organizationId: number): string {
    if (organizationId === null || organizationId === undefined) {
      return 'N/A';
    }
    
    const organization = this.organizationList.find(org => org.id === organizationId);
    return organization ? organization.name : organizationId.toString();
  }

  /**
   * Prevents space key input in the username field
   * @param event Keyboard event
   * @returns void
   */
  preventSpaces(event: KeyboardEvent): void {
    if (event.code === 'Space' || event.key === ' ') {
      event.preventDefault();
    }
  }

  onSelectionChange(value: any) {
    if(value && value !=''){
      if(value == 'organizationId'){
        if(this.selectedProductForm.get(value).value){
          this.getOrganizationBudgetGroupList(this.selectedProductForm.get(value).value);
        }
      }
        this.selectedProductForm.get(value).markAsTouched();      
    }
  }

  onDropdownBlur(type: string) {
    switch (type) {
      case 'partner':
        this.selectedProductForm.get('partner').markAsTouched();
        break;
      case 'vatId':
        this.selectedProductForm.get('vatId').markAsTouched();
        break;
      case 'categories':
        this.selectedProductForm.get('categories').markAsTouched();
        break;
     
      default:
        break;
    }
  }
}
