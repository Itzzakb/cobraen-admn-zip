import {
  AsyncPipe,
  CommonModule,
  CurrencyPipe,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormArray,
  FormControl,
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatTooltipModule } from '@angular/material/tooltip';

import {
  InventoryBrand,
  InventoryCategory,
  InventoryPagination,
  InventoryProduct,
  InventoryTag,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  takeUntil,
} from 'rxjs';
import { ChristmasFair, GiftPickupLocation, Location, OrganizationList, TimeSlot } from 'app/shared/types/interfaces';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { LocationFormComponent } from '../location-form/location-form.component';
import { GiftPickupLocationFormComponent } from '../gift-pickup-location-form/gift-pickup-location-form.component';
import { SearchableDropdownComponent } from 'app/shared/components/searchable-dropdown/searchable-dropdown.component';
import { DeleteConfirmationService, DeleteTypes } from 'app/shared/services/delete-confirmation.service';
import { CommonHelperService } from 'app/shared/services/common-helper.service';

@Component({
  selector: 'app-christmasfair',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 80px 1fr 1fr 70px 88px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 80px 1fr 1fr 70px 88px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 80px 1fr 1fr 70px 88px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 80px 1fr 1fr 70px 88px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    MatTooltipModule,
    LocationFormComponent,
    CommonModule,
    GiftPickupLocationFormComponent,
    SearchableDropdownComponent
  ],
  templateUrl: './christmasfair.component.html',
  styleUrl: './christmasfair.component.scss',
})
export class ChristmasfairComponent
  implements OnInit, AfterViewInit, OnDestroy
{
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  products$: Observable<InventoryProduct[]>;

  brands: InventoryBrand[];
  categories: InventoryCategory[];
  filteredTags: InventoryTag[];
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: InventoryPagination;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: ChristmasFair | null = null;
  selectedProductForm: UntypedFormGroup;


  locationGroup: UntypedFormGroup;
  giftGroup: UntypedFormGroup;
  selectedChristmasFairLocations: Location [] = [];
  selectedChristmasFairGiftLocations: GiftPickupLocation [] = [];
  selectedLocation: Location;
  selectedGiftLocation: GiftPickupLocation;
  selectedLocationTimeSlots: TimeSlot[]= [];
  selectedGiftLocationTimeSlots: TimeSlot[]= [];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  christmasFairsArray: ChristmasFair[] = [];
  selectedChristmasFairs: Map<number, boolean> = new Map(); // Tracks selected brands
  allSelected: boolean = false;

  searchQuery: string = '';
  searchSubject = new Subject<string>();
  searchSubscription: any;

  // Pagination properties
  pageIndex: number = 0;
  pageSize: number = 10;
  totalCount: number = 0;
  sortOrder: number = 1;
  sortColumn: string = 'id';

  organizationList: OrganizationList[] = [];
  selectedOrganizations: OrganizationList[]= [];

  createChristmasFair = false;
  addNewLocation = false;
  addNewGiftLocation = false;
  locationName = '';
  giftLocationName = '';

  errorMessage = '';
  isDataLoaded: boolean = false;

  @ViewChild('headerPaginator') headerPaginator!: MatPaginator;
  @ViewChild('footerPaginator') footerPaginator!: MatPaginator;

  orgDropdownInput = new FormControl('', [Validators.required]);


  isSaveLocationClicked: boolean = false;
  isSaveGiftLocationClicked: boolean = false;

  // @Input() locationTimeSlotsData: Location;
  // @Input() giftLocationTimeSlotsData: GiftPickupLocation;

  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _deleteConfirmationService: DeleteConfirmationService,
    private _formBuilder: UntypedFormBuilder,
    private apiService: ApiService,
    private toastr: ToastrService
  ) {}

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.selectedProductForm = this._formBuilder.group({
      id: [''],
      name: ['', Validators.required],
      slogan: ['', Validators.required],
      titleDutch: ['', Validators.required],
      titleEnglish: ['', Validators.required],
      descriptionDutch: [''],
      descriptionEnglish: [''],
      active: [false],
      locationTitleDutch: ['', [Validators.required]],
      locationTitleEnglish: ['', [Validators.required]],
      eventPartnerId: [''],
      organizations: [[]],  // Multiselect
      organizationDetails:[[]],
      locations: [[]],  // Nested FormArray
      giftPickupLocations: [[]]
    });

    this.locationGroup = this._formBuilder.group({
      locationName: ['', Validators.required],
      organizations: [[]],  // Multiselect for nested organizations
      timeSlots: this._formBuilder.array([
        this._formBuilder.group({
          date: ['', Validators.required],
          startTime: ['', Validators.required],
          endTime: ['', Validators.required],
          capacity: ['', Validators.required]
        })
      ])
    });

    this.giftGroup = this._formBuilder.group({
      locationName: ['', Validators.required],
      timeSlots: this._formBuilder.array([
        this._formBuilder.group({
          date: ['', Validators.required],
          startTime: ['', Validators.required],
          endTime: ['', Validators.required],
          capacity: ['', Validators.required]
        })
      ])
    });


    //get all organizations 
    this.getAllOrganizations();

    // Debounce search input to optimize API calls
    this.searchSubscription = this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe(query => {
        this.searchQuery = query;
        this.pageIndex = 0; // Reset to first page on new search
        this.footerPaginator.firstPage();
        this.getAllChristmasFairs();
      });

    
  }



  // Toggle selection for a single brand
  toggleSelection(brandId: number) {
    if (this.selectedChristmasFairs.has(brandId)) {
      this.selectedChristmasFairs.delete(brandId); // Unselect
    } else {
      this.selectedChristmasFairs.set(brandId, true); // Select
    }
    this.updateSelectAllState();
  }

  // Toggle Select All
  toggleSelectAll() {
    if (this.allSelected) {
      this.selectedChristmasFairs.clear(); // Unselect all
    } else {
      this.christmasFairsArray.forEach(brand => this.selectedChristmasFairs.set(brand.id, true)); // Select all
    }
    this.allSelected = !this.allSelected;
  }

  // Update the "Select All" checkbox state
  updateSelectAllState() {
    this.allSelected = this.selectedChristmasFairs.size === this.christmasFairsArray.length;
  }

  //get selectedChristmasFairs' Ids
  getSelectedChristmasIds(): number[] {
    return Array.from(this.selectedChristmasFairs.entries()) // Convert Map to an array of key-value pairs
      .filter(([id, isSelected]) => isSelected) // Filter selected Christmas fairs
      .map(([id]) => id); // Extract only the IDs
  }
  //Deletes the selected Brand entries by calling the API service. If the deletion is successful, it clears the selected Christmas fairs map.
  deleteChristmasFair(){
    this.apiService.deleteChristmasFair(this.getSelectedChristmasIds()).subscribe((response)=>{
      if(response.requestResult == 1 ){
        this.selectedChristmasFairs = new Map();
        this.getAllChristmasFairs();
        this.showSuccess('delete');
      }else{
        this.errorMessage = response.responseTip;
        this.showError();
      }
    }, (error) => {
      this.errorMessage = error.error.responseTip;
      this.showError();
    })
  }

  // get all Christmas Fairs
  getAllChristmasFairs() {
    const params = {
      sortColumn: this.sortColumn,
      pageIndex: this.pageIndex,
      pageSize: this.pageSize,
      sortOrder: this.sortOrder,
      searchQuery: this.searchQuery
    }
    this.apiService.getChristmasFairs(params).subscribe((data) => {
      this.christmasFairsArray = data.result.data;
      this.pageIndex = data.result.pageIndex;
      this.pageSize = data.result.pageSize;
      this.totalCount = data.result.count;
      this.isDataLoaded = true;
    });
  }

  getAllOrganizations(){
    this.apiService.getAllOrganizations().subscribe((data)=>{
      this.organizationList = data.result;
    },
  (error)=>{
    this.errorMessage = error.error.responseTip;
    this.showError();
  })
  }

  showSuccess(type: string) {
    const message = this.getSuccessMessage(type);
    this.toastr.success(message, 'Success!');
  }

   //get success message based on type
   getSuccessMessage(type:string){
    switch(type){
      case 'create':
        return 'Christmas Fair created successfully.';
        break;
      case 'update':
        return 'Christmas Fair updated successfully.';
        break;
      case 'delete':
        return 'Christmas Fair deleted successfully.';
        break;
      case 'copy':
        return 'Christmas Fair copied successfully.';
        break;
      case 'statusUpdate':
        return 'Christmas Fair status updated successfully.'
    }
  }
  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }

  toggleAddNewLocation(){
    this.addNewLocation = !this.addNewLocation;
    
  }

  saveNewLocation(){
    this.isSaveLocationClicked = true;
    if(this.locationName){
      this.selectedChristmasFairLocations.push(
        {
          id: 0,
          locationName: this.locationName,
          timeSlots: []
        }
      )
      this.addNewLocation = false;
      this.locationName = '';
    }

  }
  toggleAddNewGiftLocation(){
    this.addNewGiftLocation = !this.addNewGiftLocation;    
  }

  saveNewGiftLocation(){
    this.isSaveGiftLocationClicked = true;

    if(this.giftLocationName){
      this.selectedChristmasFairGiftLocations.push(
        {
          id: 0,
          locationName: this.giftLocationName,
          timeSlots: []
        }
      )
      this.addNewGiftLocation = false;
      this.giftLocationName = '';
    }

  }

  clearLocationName(){
    this.locationName = '';
    this.isSaveLocationClicked = false;
  }

  clearGiftLocationName(){
    this.giftLocationName = '';
    this.isSaveGiftLocationClicked = false;
  }

  // Triggers a search operation with the provided query string.
  onSearch(query: string): void {
    this.createChristmasFair = false;
    this.closeDetails();
    this.searchSubject.next(query);
  }

  // Handle pagination changes
  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.getAllChristmasFairs();
  }

  toggleCreateChristmasFairForm() {
    //close the edit form if open
    this.closeDetails();

    this.selectedChristmasFairGiftLocations = [];
    this.selectedChristmasFairLocations = [];
    
    this.createChristmasFair = !this.createChristmasFair;
    if (this.createChristmasFair) {
      const newProduct = {
        id: 0,
        name: '',
        slogan: '',
        titleDutch: '',
        titleEnglish: '',
        descriptionDutch: '',
        descriptionEnglish: '',
        active: false,
        locationTitleDutch: '',
        locationTitleEnglish: '',
        eventPartnerId: 0,
        organizations: [],
        organizationDetails: [],
        locations: [],
        giftPickupLocations: []

      }

      this.selectedOrganizations = [];
      // Go to new product
      this.selectedProduct = newProduct;

      // Fill the form
      this.selectedProductForm.patchValue(newProduct);

      // Mark for check
      this._changeDetectorRef.markForCheck();
    } else {
      this.selectedProductForm.reset();
    }
  }

  get locations(): FormArray {
    return this.selectedProductForm.get('locations') as FormArray;
  }

  get giftPickupLocations(): FormArray {
    return this.selectedProductForm.get('giftPickupLocations') as FormArray;
  }

  // Add a location with nested organizations
  addLocation() {
    this.locations.push(this.locationGroup);
  }

  // Add a gift pickup location
  addGiftPickupLocation() {
    this.giftPickupLocations.push(this.giftGroup);
  }

  // Add timeslot dynamically
  addTimeSlot(locationIndex: number) {
    const timeSlotGroup = this._formBuilder.group({
      date: ['', Validators.required],
      startTime: ['', Validators.required],
      endTime: ['', Validators.required],
      capacity: ['', Validators.required]
    });

    const timeSlots = this.locations
      .at(locationIndex)
      .get('timeSlots') as FormArray;
    timeSlots.push(timeSlotGroup);
  }

  updateStatus(id: number, status: boolean) {
    this.apiService.updateChristmasFairStatus(id, !status).subscribe((response)=>{
      if(response.requestResult == 1 ){
        this.showSuccess('statusUpdate');
        this.getAllChristmasFairs();
        this.closeDetails();
      }else{
        this.errorMessage = response.responseTip;
        this.showError();
      }
    });
  }

  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * After view init
   */
  ngAfterViewInit(): void {
    if (this._sort && this._paginator) {
      setTimeout(()=>{
        // Set the initial sort
      this._sort.sort({
        id: 'id',
        start: 'desc',
        disableClear: true,
      });
      })

      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;
          this.pageIndex = 0;

          //reset and close the form if it is open
          this.resetForm();
          this.closeDetails();

          // set the sort column and sort order
          this.sortColumn = this._sort.active;
          this.sortOrder = this._sort.direction === 'asc' ? 2 : 1;

          // Get the Brands
          this.getAllChristmasFairs();
        });
    }
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggle product details
   *
   * @param id
   */
  toggleDetails(id: number): void {
    this.createChristmasFair = false;
    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct.id === id) {
      // Close the details
      this.closeDetails();
      return;
    }

    const myMap = new Map(this.christmasFairsArray.map(obj => [obj.id, obj]));

    this.selectedProduct = myMap.get(id);
    this.selectedProductForm.patchValue(this.selectedProduct);
    this.selectedOrganizations = this.extractOrganizations(this.selectedProductForm.get('organizationDetails').value);
    this.selectedChristmasFairLocations = this.selectedProduct.locations;
    this.selectedChristmasFairGiftLocations = this.selectedProduct.giftPickupLocations;
  }


  /**
   * Transforms an array of location objects by modifying their structure.
   * Each location's `timeSlots` array is updated to include only the `id` of each organization.
   *
   * @param locations - An array of location objects. Each location contains a `timeSlots` array,
   * where each time slot has an `organizations` array.
   * @returns A new array of location objects with transformed `timeSlots`. Each time slot's
   * `organizations` array is replaced with an array of organization IDs.
   */
  transformLocationData(locations: any[]) {
    return locations.map(location => ({
      ...location,
      timeSlots: location.timeSlots.map(timeSlot => ({
        ...timeSlot,
        date: CommonHelperService.GenerateISODateTimeString(timeSlot.date, null),
        organizationIds: timeSlot.organizations.map(org => typeof org === "object" && org.id ? org.id : org)
      })).map(({ organizations, ...rest }) => rest) // Remove the old 'organizations' key
    }));
  }

  transformGiftLocationData(locations: any[]) {
    return locations.map(location => ({
      ...location,
      timeSlots: location.timeSlots.map(({ organizations, capacity, ...timeSlot }) => ({
        ...timeSlot,
        date: CommonHelperService.GenerateISODateTimeString(timeSlot.date, null),
        capacity: 1,
        organizationIds: organizations.map(org => 
          typeof org === "object" && org.id ? org.id : org
        )
      }))
    }));
  }

  extractOrganizations(organizationDetails: any[]) {
    if (!organizationDetails) {
      return [];
    }
    return organizationDetails.map(org => org.organizationId);
  }

  /**
   * Toggle the location details
   *
   * @param location
   */
  toggleLocationDetails(location: Location) {
    this.addNewLocation = false;
    this.locationName = '';
    this.selectedLocationTimeSlots = [];
    // If the product is already selected...
    if (this.selectedLocation && this.selectedLocation === location) {
      // Close the details
      this.closeLocationForm();
      return;
    }
    this.selectedLocation = this.selectedChristmasFairLocations.find(loc => loc === location);   
    this._changeDetectorRef.markForCheck();
    this.selectedLocationTimeSlots = this.selectedLocation.timeSlots;
  }

  /**
   * Toggle the gift location details
   *
   * @param id
   */
  toggleGiftLocationDetails(giftLocation: GiftPickupLocation) {

    this.addNewGiftLocation = false;
    this.giftLocationName = '';
    this.selectedGiftLocationTimeSlots = [];

    // If the product is already selected...
    if (this.selectedGiftLocation && this.selectedGiftLocation === giftLocation) {
      // Close the details
      this.closeGiftLocationForm();

      return;
    }
    this.selectedGiftLocation = this.selectedChristmasFairGiftLocations.find(loc => loc === giftLocation);
    this._changeDetectorRef.markForCheck();
    this.selectedGiftLocationTimeSlots = this.selectedGiftLocation.timeSlots;
  }

  //  returnSelectedOrganizations(){
  //   return this.organizationList.filter( i => this.selectedProductForm.);
  //  }
  

  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
    this.orgDropdownInput.reset();
  }

  /**
   * Close the Location form
   */
  closeLocationForm(): void {
    this.selectedLocation = null;
  }

  /**
   * Close the Gift Location form
   */
  closeGiftLocationForm(): void {
    this.selectedGiftLocation = null;
  }


  //reset the form
  resetForm() {
    let preservedId = this.selectedProductForm?.get('id')?.value ?? 0;
    this.selectedProductForm.reset({
      id : preservedId,
      active : false
    });
    if(preservedId != 0){
      this.selectedProductForm.markAllAsTouched();
    }
    this.orgDropdownInput.reset();
    this.selectedOrganizations = [];
  }

  async deleteSelectedItem(item: Location | GiftPickupLocation, locationType: 'location' | 'gift location'): Promise<void> {
    
    if (locationType === 'location') {
      const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Location', DeleteTypes.ItemNoTitle);

      if (!confirmed) {
        return;
      }

      var removedIndex = this.selectedChristmasFairLocations.indexOf(item);

      if (removedIndex !== -1) {
        this.selectedChristmasFairLocations.splice(removedIndex, 1);
      }      
    }
    else {
      const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Gift location', DeleteTypes.ItemNoTitle);
      
      if (!confirmed) {
        return;
      }
      var removedIndex = this.selectedChristmasFairGiftLocations.indexOf(item);

      if (removedIndex !== -1) {
        this.selectedChristmasFairGiftLocations.splice(removedIndex, 1);
      }
      
      return;
    }
  }
  /**
   * Delete the selected product using the form data
   */
  async deleteSelectedProduct(selectedId: number | null, type: string): Promise<void> {

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Christmas fair', DeleteTypes.ItemNoTitle);

    if (!confirmed) {
      return;
    }

    switch (type) {
      case 'inlineDelete':
        this.selectedChristmasFairs.clear();
        this.selectedChristmasFairs.set(selectedId, true)
        this.deleteChristmasFair();
        return;

      case 'deleteBtn':
        this.deleteChristmasFair();
        return;
    }
  }


  updateChristmasFair(){
    if(this.selectedProductForm.valid && this.selectedOrganizations.length > 0){
      let christmasFair = this.selectedProductForm.getRawValue();
    let requestBody = {
      "id": christmasFair.id,
      "name": christmasFair.name,
      "slogan": christmasFair.slogan,
      "titleDutch": christmasFair.titleDutch,
      "titleEnglish": christmasFair.titleEnglish,
      "descriptionDutch": christmasFair.descriptionDutch,
      "descriptionEnglish": christmasFair.descriptionEnglish,
      "locationTitleDutch": christmasFair.locationTitleDutch,
      "locationTitleEnglish": christmasFair.locationTitleEnglish,
      "active": christmasFair.active,
      "eventPartnerId": christmasFair.eventPartnerId,
      "organizations": this.transformorginizationData(this.selectedOrganizations),
      "locations": this.transformLocationData(this.selectedChristmasFairLocations),
      "giftPickupLocations": this.transformGiftLocationData(this.selectedChristmasFairGiftLocations)
    };
    this.apiService.updateChristmasFair(requestBody).subscribe((response)=>{
      if(response.requestResult == 1 ){
        this.showSuccess('update');
        this.getAllChristmasFairs();
        this.closeDetails();
      }else{
        if(response.requestResult == 29){
          this.errorMessage = "Delete Failed!!! TimeSlot is linked to employees";
          this.showError();
          return;
        }
        this.errorMessage = response.responseTip;
        this.showError();
      }
    }, (error) => {
      this.errorMessage = error.error.responseTip;
      this.showError();
    })
    }else{
      this.selectedProductForm.markAllAsTouched();
      this.errorMessage = 'Please fill all the required fields';
      this.showError();
    }
  }

  transformorginizationData(organizations: any[]) {
    return organizations.map(organization => ({
      ...organization,
      organizationId: organization
    }));
  }

  addChristmasFair(){
    if(this.selectedProductForm.valid){
    let christmasFair = this.selectedProductForm.getRawValue();
    let requestBody = {
      "name": christmasFair.name,
      "slogan": christmasFair.slogan,
      "titleDutch": christmasFair.titleDutch,
      "titleEnglish": christmasFair.titleEnglish,
      "descriptionDutch": christmasFair.descriptionDutch,
      "descriptionEnglish": christmasFair.descriptionEnglish,
      "locationTitleDutch": christmasFair.locationTitleDutch,
      "locationTitleEnglish": christmasFair.locationTitleEnglish,
      "active": christmasFair.active,
      "eventPartnerId": christmasFair.eventPartnerId,
      "organizations": this.transformorginizationData(this.selectedOrganizations),
      "locations": this.transformLocationData(this.selectedChristmasFairLocations),
      "giftPickupLocations": this.transformGiftLocationData(this.selectedChristmasFairGiftLocations)
    };
    this.apiService.createChristmasFair(requestBody).subscribe((response)=>{
      if(response.requestResult == 1 ){
        this.showSuccess('create');
        this.getAllChristmasFairs();
        this.closeDetails();
        this.createChristmasFair = false;
      }else{
        this.errorMessage = response.responseTip;
        this.showError();
      }
    }, (error) => {
      this.errorMessage = error.error.responseTip;
      this.showError();
    })
  }else{
    this.selectedProductForm.markAllAsTouched();
    this.orgDropdownInput.markAsTouched();
    this.errorMessage = 'Please fill all the required fields';
    this.showError();
  }
  }


  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }

  onSelectionChange(value: any) {
    if(value && value !=''){
        this.selectedProductForm.get(value).markAsTouched();
    }
  }

  onDropdownBlur() {
    //To update drodowns in child forms (if any listening)
    this.oragnizationUpdateEmitter.emit(this.selectedOrganizations);
    this.orgDropdownInput.markAsTouched();
    this.orgDropdownInput.updateValueAndValidity();
  }

  private oragnizationUpdateEmitter : EventEmitter<any> = new EventEmitter();
}
