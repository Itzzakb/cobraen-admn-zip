import { Routes } from "@angular/router";
import { ChristmasfairComponent } from "./christmasfair.component";

export default [
    {
        path: '',
        component: ChristmasfairComponent
    }
] as Routes