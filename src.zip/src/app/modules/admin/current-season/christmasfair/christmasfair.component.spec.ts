import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChristmasfairComponent } from './christmasfair.component';

describe('ChristmasfairComponent', () => {
  let component: ChristmasfairComponent;
  let fixture: ComponentFixture<ChristmasfairComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ChristmasfairComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChristmasfairComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
