import {
  AsyncPipe,
  CommonModule,
  CurrencyPipe,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormControl,
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatCheckboxChange,
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { InventoryService } from 'app/shared/services/inventory.service';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDatepickerModule } from '@angular/material/datepicker';

import {
  InventoryBrand,
  InventoryCategory,
  InventoryPagination,
  InventoryProduct,
  InventoryTag,
  InventoryVendor,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  map,
  merge,
  switchMap,
  takeUntil,
} from 'rxjs';
import { products } from 'app/mock-api/apps/ecommerce/inventory/data';
import { budgetGroupList, StandardGift } from 'app/shared/types/interfaces';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { SearchableDropdownComponent } from 'app/shared/components/searchable-dropdown/searchable-dropdown.component';
import { DeleteConfirmationService } from 'app/shared/services/delete-confirmation.service';

@Component({
  selector: 'app-standard-gifts',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 1fr 136px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 1fr 136px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 1fr 136px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 1fr 136px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    MatTooltipModule,
    MatDatepickerModule,
    CommonModule,
    SearchableDropdownComponent
  ],
  templateUrl: './standard-gifts.component.html',
  styleUrl: './standard-gifts.component.scss',
})
export class StandardGiftsComponent
  implements OnInit, AfterViewInit, OnDestroy
{
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  products$: Observable<InventoryProduct[]>;

  categories: InventoryCategory[];
  filteredTags: InventoryTag[];
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: InventoryPagination;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: StandardGift | null = null;
  selectedProductForm: UntypedFormGroup;
  tags: InventoryTag[];
  tagsEditMode: boolean = false;
  vendors: InventoryVendor[];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  standardGiftsArray: StandardGift[] = [];
    selectedStandardGifts: Map<number, boolean> = new Map(); // Tracks selected standard gifts
    allSelected: boolean = false;
  
    searchQuery: string = '';
    searchSubject = new Subject<string>();
    searchSubscription: any;
  
    // Pagination properties
    pageIndex: number = 0;
    pageSize: number = 10;
    totalCount: number = 0;
    sortOrder: number = 1;
    sortColumn: string = 'id';
  
    createStandardGift = false;
  
    errorMessage = '';
    isDataLoaded: boolean = false;

    
    budgetGroupsList: budgetGroupList[] = [];
    selectedBudgetGroupIds: number[] = [];
    
  
    
  
    @ViewChild('headerPaginator') headerPaginator!: MatPaginator;
    @ViewChild('footerPaginator') footerPaginator!: MatPaginator;

  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _formBuilder: UntypedFormBuilder,
    private _deleteConfirmationService: DeleteConfirmationService,
    private apiService: ApiService,
    private toastr: ToastrService
  ) {}

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.selectedProductForm = this._formBuilder.group({
      id: [''],
      title: ['', [Validators.required, Validators.pattern(/^(?!\s*$).+/)]],
      active: [''],
    });

    

  // Debounce search input to optimize API calls
      this.searchSubscription = this.searchSubject
        .pipe(debounceTime(300), distinctUntilChanged())
        .subscribe(query => {
          this.searchQuery = query;
          this.pageIndex = 0; // Reset to first page on new search
          this.footerPaginator.firstPage();
          this.getAllStandardGifts();
        });

        //get dropdown data
        this.getBudgetGroupList();
  
  
  }

  budgetGroupInput = new FormControl('', [Validators.required]);

  getBudgetGroupList() {
    this.apiService.getAllBudgetGroupsForDropdown().subscribe((data) => {
      this.budgetGroupsList = data.result;
    },
      (error) => {
        this.errorMessage = 'Unable to fetch budget groups for dropdown';
        this.showError();
      })
  }

  
  // Toggle selection for a single FreeGift
  toggleSelection(id: number) {
    if (this.selectedStandardGifts.has(id)) {
      this.selectedStandardGifts.delete(id); // Unselect
    } else {
      this.selectedStandardGifts.set(id, true); // Select
    }
    this.updateSelectAllState();
  }

  // Toggle Select All
  toggleSelectAll() {
    if (this.allSelected) {
      this.selectedStandardGifts.clear(); // Unselect all
    } else {
      this.standardGiftsArray.forEach(brand => this.selectedStandardGifts.set(brand.id, true)); // Select all
    }
    this.allSelected = !this.allSelected;
  }

  // Update the "Select All" checkbox state
  updateSelectAllState() {
    this.allSelected = this.selectedStandardGifts.size === this.standardGiftsArray.length;
  }

  //get selectedStandardGifts' Ids
  getSelectedStandardGiftIds(): number[] {
    return Array.from(this.selectedStandardGifts.entries()) // Convert Map to an array of key-value pairs
      .filter(([id, isSelected]) => isSelected) // Filter selected brands
      .map(([id]) => id); // Extract only the IDs
  }
  //Deletes the selected Brand entries by calling the API service. If the deletion is successful, it clears the selected Brands map.
  deleteStandardGifts() {
    this.apiService.deleteStandardGift(this.getSelectedStandardGiftIds()).subscribe((response) => {
      if (response.requestResult == 1) {
        this.selectedStandardGifts = new Map();
        this.getAllStandardGifts();
        this.showSuccess('delete');
      } else {
        this.errorMessage = response.responseTip;
        this.showError();
      }
    }, (error) => {
      this.errorMessage = error.error.responseTip;
      this.showError();
    })
  }

  // get all Free Gifts
  getAllStandardGifts() {
    const params = {
      sortColumn: this.sortColumn,
      pageIndex: this.pageIndex,
      pageSize: this.pageSize,
      sortOrder: this.sortOrder,
      searchQuery: this.searchQuery
    }
    this.apiService.getStandardGifts(params).subscribe((data) => {
      this.standardGiftsArray = data.result.data;
      this.pageIndex = data.result.pageIndex;
      this.pageSize = data.result.pageSize;
      this.totalCount = data.result.count;
      this.isDataLoaded = true;
    });
  }

  getBudgetGroupName(budgetGroups: budgetGroupList[]): string {
    let budgetGroupNames: string = '';
    budgetGroups.forEach((budgetGroup) => {
        budgetGroupNames += budgetGroup.name + ', ';
    });
    return budgetGroupNames.slice(0, -2); // Remove the last comma and space
  }

  showSuccess(type: string) {
    const message = this.getSuccessMessage(type);
    this.toastr.success(message, 'Success!');
  }
    //get success message based on type
    getSuccessMessage(type: string) {
      switch (type) {
        case 'create':
          return 'Standard gift created successfully.';
          break;
        case 'update':
          return 'Standard gift updated successfully.';
          break;
        case 'delete':
          return 'Standard gift deleted successfully.';
          break;
        case 'statusUpdate':
          return 'Standard gift status updated successfully.'
          break;
      }
    }
  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }

  // Triggers a search operation with the provided query string.
  onSearch(query: string): void {
    this.createStandardGift = false;
    this.closeDetails();
    this.searchSubject.next(query);
  }

  // Handle pagination changes
  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.getAllStandardGifts();
  }

  toggleCreateStandardGiftForm() {
    //close the edit form if open
    this.closeDetails();

    this.createStandardGift = !this.createStandardGift;
    if (this.createStandardGift) {

      const newProduct = {
        id: 0,
        title: '',
        active: false,
        budgetGroups: [],
      }
      // Go to new product
      this.selectedProduct = newProduct;

      // Fill the form
      this.selectedProductForm.patchValue(newProduct);

      // Mark for check
      this._changeDetectorRef.markForCheck();
    } else {
      this.selectedProductForm.reset();
    }
  }

  updateStatus(id: number) {
    const formData = new FormData();
    let body = {
      "id": id
    }

    this.apiService.updateStandardGiftStatus(body).subscribe((data) => {
      if (data.requestResult == 1) {
        this.showSuccess('statusUpdate');
        this.getAllStandardGifts();
      } else {
        this.errorMessage = data.responseTip;
        this.showError();
      }
    },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      })
  }

  addStandardGifts() {
    if (this.selectedProductForm.valid && this.selectedBudgetGroupIds.length > 0) {
      
      const standardGift = this.selectedProductForm.getRawValue();
      const body = {
        "title": standardGift.title,
        "active": standardGift.active,
        "BudgetGroupIds": this.selectedBudgetGroupIds,
      }

      this.apiService.createStandardGift(body).subscribe((data) => {
        if (data.requestResult == 1) {
          this.getAllStandardGifts();
          this.resetForm();
          this.closeDetails();
          this.createStandardGift = false;
          this.showSuccess('create');
        } else {
          this.errorMessage = data.responseTip;
          this.showError();
        }
      },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        });
    } else {
      this.selectedProductForm.markAllAsTouched();    
      this.budgetGroupInput.markAsTouched();       
      this.errorMessage = 'Please fill all the required fields.';
      this.showError();
    }
  }


  updateStandardGifts() {
    if (this.selectedProductForm.valid && this.selectedBudgetGroupIds.length > 0) {
      
      const standardGift = this.selectedProductForm.getRawValue();
      const body = {
        "id": standardGift.id,
        "title": standardGift.title,
        "active": standardGift.active,
        "BudgetGroupIds": this.selectedBudgetGroupIds,
      }
      this.apiService.updateStandardGift(body).subscribe((data) => {
        if (data.requestResult == 1) {
          this.getAllStandardGifts();
          this.resetForm();
          this.closeDetails();
          this.showSuccess('update');
        } else {
          this.errorMessage = data.responseTip;
          this.showError();
        }
      },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        });
    } else {
      this.selectedProductForm.markAllAsTouched();     
      this.budgetGroupInput.markAsTouched();        
      this.errorMessage = 'Please fill all the required fields.';
      this.showError();
    }
  }


  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * After view init
   */
  ngAfterViewInit(): void {
    if (this._sort && this._paginator) {
      setTimeout(()=>{
        // Set the initial sort
      this._sort.sort({
        id: 'id',
        start: 'desc',
        disableClear: true,
      });
      });

      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;
          this.pageIndex = 0;

          //reset and close the form if it is open
          this.resetForm();
          this.closeDetails();

          // set the sort column and sort order
          this.sortColumn = this._sort.active;
          this.sortOrder = this._sort.direction === 'asc' ? 2 : 1;

          // Get the Free gifts
          this.getAllStandardGifts();
        });      
    }
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggle product details
   *
   * @param id
   */
  toggleDetails(id: number): void {
    this.createStandardGift = false;
    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct.id === id) {
      // Close the details
      this.closeDetails();
      return;
    }

    const myMap = new Map(this.standardGiftsArray.map(obj => [obj.id, obj]));

    this.selectedProduct = myMap.get(id);
    this.selectedProductForm.patchValue(this.selectedProduct);
    this.selectedBudgetGroupIds = this.selectedProduct.budgetGroups.map(sgb => sgb.id);
  }

  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
    this.budgetGroupInput.reset();
    this.selectedBudgetGroupIds = [];
  }

  //Reset Form
  resetForm(){
    let property = this.selectedProductForm.getRawValue();
    this.selectedProductForm.reset({
      id : property.id,
      active : property.active,
    });
    if (property.id != 0) {
      this.selectedProductForm.markAllAsTouched();
    }
    this.budgetGroupInput.reset();
    this.selectedBudgetGroupIds = [];
  }

  /**
   * Delete the selected product using the form data
   */
  async deleteSelectedProduct(id: number | null, isFromDeleteBtn = false): Promise<void> {

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Standard Gift');

    if (!confirmed) {
      return;
    }

    if (!isFromDeleteBtn) {
      this.selectedStandardGifts.clear();
      this.selectedStandardGifts.set(id, true);
    }

    this.deleteStandardGifts();
    this.closeDetails();

  }

  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }

  onSelectionChange(value: any) {
    if(value && value !=''){
        this.selectedProductForm.get(value).markAsTouched();      
    }
  }

  onDropdownBlur(){
    this.budgetGroupInput.markAsTouched(); // Mark the dropdown as touched
  }
}
