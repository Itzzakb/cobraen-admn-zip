import { Routes } from "@angular/router";
import { StandardGiftsComponent } from "./standard-gifts.component";

export default [
    {
        path: '',
        component: StandardGiftsComponent
    }
] as Routes