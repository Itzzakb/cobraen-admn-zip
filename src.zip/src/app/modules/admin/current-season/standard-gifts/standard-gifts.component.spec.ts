import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StandardGiftsComponent } from './standard-gifts.component';

describe('StandardGiftsComponent', () => {
  let component: StandardGiftsComponent;
  let fixture: ComponentFixture<StandardGiftsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StandardGiftsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StandardGiftsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
