import { TextFieldModule } from '@angular/cdk/text-field';
import { NgClass } from '@angular/common';
import {
  Component,
  ElementRef,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  Validators,
} from '@angular/forms';
('@angular/material/checkbox');
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatChipsModule } from '@angular/material/chips';
import { MatOptionModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { ColorPickerModule } from 'ngx-color-picker';
import { MatRadioModule } from '@angular/material/radio';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';
import { ImageLibraryComponent } from 'app/modules/image-library/image-library.component';
import { RouterOutlet } from '@angular/router';
import { ApiService } from '@fuse/services/api-service.service';

@Component({
  selector: 'app-users',
  encapsulation: ViewEncapsulation.None,
  standalone: true,
  imports: [
    MatIconModule,
    FormsModule,
    MatFormFieldModule,
    NgClass,
    MatInputModule,
    TextFieldModule,
    ReactiveFormsModule,
    MatButtonToggleModule,
    MatButtonModule,
    MatSelectModule,
    MatOptionModule,
    MatChipsModule,
    MatDatepickerModule,
    ColorPickerModule,
    MatRadioModule,
    MatTooltipModule,
    RouterOutlet,
  ],
  templateUrl: './users.component.html',
  styleUrl: './users.component.scss',
})
export class UsersComponent implements OnInit {
    constructor(
    private _formBuilder: UntypedFormBuilder,
    private toastr: ToastrService,
    private _matDialog: MatDialog,
    private formBuilder: FormBuilder,
    private apiService: ApiService
  ) {}

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    this.importForm = this.formBuilder.group({
      file: [null, Validators.required]
    });
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Get the form field helpers as string
   */
  // getFormFieldHelpersAsString(): string {
  //   return this.formFieldHelpers.join(' ');
  // }

  @ViewChild('background_image', { static: false })
  background_image!: ElementRef;
  @ViewChild('default_logo', { static: false }) default_logo!: ElementRef;
  @ViewChild('app_logo', { static: false }) app_logo!: ElementRef;
  @ViewChild('banner_image', { static: false }) banner_image!: ElementRef;
  
  importForm: FormGroup;
  uploadedFile: File | null = null;
  isUploading: boolean = false;
  errorMessage: string = '';

  sloganTextColor = '#ed2727';
  filtersTextColor = '#329f32';
  headingColor = '#3838d0';
  backgroundColor = '#456aeb';
  bodyColor = '#edc786';
  moduleColor = '#acbdef';
  textColor = '#343434';
  menuTextColor = '#121234';
  logoBackgroundColor = '#900089';
  appMainColor = '#c5c5c5';
  appSubColor = '#e4f6a3';

  defaultStyling = this.formBuilder.group({
    slogan_text: [''],
    slogan_text_color: [this.sloganTextColor],
    filters_text_color: [this.filtersTextColor],
    heading_color: [this.headingColor],
    heading_transparancy: [''],
    background_color: [this.backgroundColor],
    body_color: [this.bodyColor],
    body_transparancy: [''],
    module_color: [this.moduleColor],
    module_transparancy: [''],
    text_color: [this.textColor],
    menu_text_color: [this.menuTextColor],
    logo_background_color: [this.logoBackgroundColor],
    app_main_color: [this.appMainColor, Validators.required],
    app_sub_color: [this.appSubColor, Validators.required],
  });
  uploadImage(fileList: FileList): void {
    // Return if canceled
    if (!fileList.length) {
      return;
    }

    const allowedTypes = ['image/jpeg', 'image/png'];
    const file = fileList[0];

    // Return if the file is not allowed
    if (!allowedTypes.includes(file.type)) {
      return;
    }
  }

  public GetFileOnLoad(event: any, name: string) {
    if (event.target.files && event.target.files[0]) {
      var file = event.target.files[0] as File;
      
      // Check if the selected file is a CSV
      if (file.type !== 'text/csv' && !file.name.endsWith('.csv')) {
        this.errorMessage = 'Please select a valid CSV file';
        this.showError();
        return;
      }
      
      this.uploadedFile = file;
      this.getImageFilePreview(name, URL.createObjectURL(file));
    }
  }

  defaultLogo = '';
  bannerImage = '';
  backgroundImage = '';
  appLogo = '';
  appQrCodeImage = '';

  getImageFilePreview(name: string, imageURL: string) {
    switch (name) {
      case 'default logo':
        this.defaultLogo = imageURL;
        break;
      case 'banner image':
        this.bannerImage = imageURL;
        break;
      case 'background image':
        this.backgroundImage = imageURL;
        break;
      case 'app logo':
        this.appLogo = imageURL;
        break;
      case 'app QR code image':
        this.appQrCodeImage = imageURL;
        break;
    }
  }

  removeImageFile(name: string, inputBox: string) {
    switch (name) {
      case 'banner image':
        this.bannerImage = '';
        var element = document.getElementById(
          inputBox
        ) as HTMLInputElement | null;
        if (element != null) {
          element.value = '';
          element.blur();
        }
        break;
      case 'background image':
        this.backgroundImage = '';
        var element = document.getElementById(
          inputBox
        ) as HTMLInputElement | null;
        if (element != null) {
          element.value = '';
          element.blur();
        }
        break;
    }
  }

  changeColor(color: string, name: string) {
    switch (name) {
      case 'slogan text color':
        this.sloganTextColor = color;
        break;
      case 'filters text color':
        this.filtersTextColor = color;
        break;
      case 'heading color':
        this.headingColor = color;
        break;
      case 'background color':
        this.backgroundColor = color;
        break;
      case 'body color':
        this.bodyColor = color;
        break;
      case 'module color':
        this.moduleColor = color;
        break;
      case 'text color':
        this.textColor = color;
        break;
      case 'menu text color':
        this.menuTextColor = color;
        break;
      case 'logo background color':
        this.logoBackgroundColor = color;
        break;
      case 'app main color':
        this.appMainColor = color;
        break;
      case 'app sub color':
        this.appSubColor = color;
        break;
    }
  }

  showSuccess(message: string = 'Users imported successfully.') {
    this.toastr.success(message, 'Success!');
  }
  
  showError() {
    this.toastr.error(this.errorMessage || 'Please fill all the mandatory fields.', 'Error!');
  }

  openImageLibrary(): void {
    this._matDialog.open(ImageLibraryComponent, { autoFocus: false });
  }

  resetDeafultStyling() {
    this.defaultStyling.reset();
    this.uploadedFile = null;
    this.defaultLogo = '';
    this.bannerImage = '';
    this.backgroundImage = '';
    this.appLogo = '';
    this.appQrCodeImage = '';

    this.sloganTextColor = '';
    this.filtersTextColor = '';
    this.headingColor = '';
    this.backgroundColor = '';
    this.bodyColor = '';
    this.moduleColor = '';
    this.textColor = '';
    this.menuTextColor = '';
    this.logoBackgroundColor = '';
    this.appMainColor = '';
    this.appSubColor = '';
    
    // Clear the file input
    const element = document.getElementById('banner_image_input') as HTMLInputElement | null;
    if (element) {
      element.value = '';
    }
  }
  defaultStylingSave() {
    if (!this.uploadedFile) {
      this.errorMessage = 'Please select a CSV file to import';
      this.showError();
      return;
    }
    
    this.isUploading = true;
    const formData = new FormData();
    formData.append('file', this.uploadedFile);
    
    this.apiService.importUsers(formData).subscribe(
      (response) => {
        this.isUploading = false;
        if (response.requestResult === 1) { // Success 
          this.showSuccess(`Users imported successfully. Total imported: ${response.result.importedCount}`);
          this.resetDeafultStyling();
        } else {
          this.errorMessage = response.responseTip || 'Failed to import users';
          this.showError();
        }
      },
      (error) => {
        this.isUploading = false;
        this.errorMessage = error.error?.responseTip || 'Failed to import users. Please try again.';
        this.showError();
      }
    );
  }
}
