import { Routes } from "@angular/router";
import { OrgProductsComponent } from "./org-products.component";

export default [
    {
        path: '',
        component: OrgProductsComponent
    }
] as Routes