import { Routes } from "@angular/router";
import { AdditionalProductImagesComponent } from "./additional-product-images.component";

export default [
    {
        path: '',
        component: AdditionalProductImagesComponent
    }
] as Routes