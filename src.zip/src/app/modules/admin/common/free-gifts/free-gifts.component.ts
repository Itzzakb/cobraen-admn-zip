import {
  AsyncPipe,
  CommonModule,
  CurrencyPipe,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormControl,
  FormsModule,
  NgModel,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatTooltipModule } from '@angular/material/tooltip';

import {
  InventoryBrand,
  InventoryCategory,
  InventoryPagination,
  InventoryProduct,
  InventoryTag,
  InventoryVendor,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  takeUntil,
} from 'rxjs';
import {
  BudgetGroupDetails,
  budgetGroupList,
  CommonDropdownItem,
  FreeGift,
  FreeGiftQuestion,
  FreeGiftQuestionOption,
} from 'app/shared/types/interfaces';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { SearchableDropdownComponent } from 'app/shared/components/searchable-dropdown/searchable-dropdown.component';
import { DeleteConfirmationService, DeleteTypes } from 'app/shared/services/delete-confirmation.service';
import { CommonHelperService } from 'app/shared/services/common-helper.service';
@Component({
  selector: 'app-free-gifts',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 80px 1fr 100px 1fr 88px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 80px 1fr 100px 1fr 88px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 80px 1fr 100px 1fr 88px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 80px 1fr 100px 1fr 88px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    MatTooltipModule,
    CommonModule,
    SearchableDropdownComponent
  ],
  templateUrl: './free-gifts.component.html',
  styleUrl: './free-gifts.component.scss',
})
export class FreeGiftsComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  products$: Observable<InventoryProduct[]>;

  brands: InventoryBrand[];
  categories: InventoryCategory[];
  filteredTags: InventoryTag[];
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: InventoryPagination;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: FreeGift | null = null;
  selectedProductForm: UntypedFormGroup;
  tags: InventoryTag[];
  tagsEditMode: boolean = false;
  vendors: InventoryVendor[];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  freeGiftsArray: FreeGift[] = [];
  selectedFreeGifts: Map<number, boolean> = new Map(); // Tracks selected brands
  allSelected: boolean = false;

  searchQuery: string = '';
  searchSubject = new Subject<string>();
  searchSubscription: any;

  // Pagination properties
  pageIndex: number = 0;
  pageSize: number = 10;
  totalCount: number = 0;
  sortOrder: number = 1;
  sortColumn: number = 0;

  createFreeGift = false;

  errorMessage = '';

  questions: FreeGiftQuestion;

  partnersList: CommonDropdownItem[] = [];
  budgetGroupsList: budgetGroupList[] = [];
  selectedBudgetGroups: BudgetGroupDetails[] = [];
  questionOptions: FreeGiftQuestionOption[] = [];
  selectedBudgetGroupIds: number[] = [];

  dutchQuestion: string = '';
  englishQuestion: string = '';
  dutchOption: string = '';
  englishOption: string = '';
  suffix: string = '';
  isDataLoaded: boolean = false;

  @ViewChild('headerPaginator') headerPaginator!: MatPaginator;
  @ViewChild('footerPaginator') footerPaginator!: MatPaginator;

  @ViewChild('dutchQuestionInput') dutchQuestionInput!: NgModel;
  @ViewChild('englishQuestionInput') englishQuestionInput!: NgModel;
  @ViewChild('dutchOptionInput') dutchOptionInput!: NgModel;
  @ViewChild('englishOptionInput') englishOptionInput!: NgModel;
  @ViewChild('suffixInput') suffixInput!: NgModel;

  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _deleteConfirmationService: DeleteConfirmationService,
    private _formBuilder: UntypedFormBuilder,
    private apiService: ApiService,
    private toastr: ToastrService
  ) {}

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.selectedProductForm = this._formBuilder.group({
      id: ['', [Validators.required]],
      title: ['', [Validators.required, Validators.pattern(/^(?!\s*$).+/)]],
      importId: ['', [Validators.required, Validators.pattern(/^(?![\W_]+$)[^\s]+$/)]],
      partnerId: ['', [Validators.required]],
    });

    // Debounce search input to optimize API calls
    this.searchSubscription = this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe((query) => {
        this.searchQuery = query;
        this.pageIndex = 0; // Reset to first page on new search
        this.footerPaginator.firstPage();
        this.getAllFreeGifts();
      });

    //get dropdown data
    this.getPartnersList();
    this.getBudgetGroupList();
  }

  getBudgetGroupList() {
    this.apiService.getAllBudgetGroupsForDropdown().subscribe(
      (data) => {
        this.budgetGroupsList = data.result;
      },
      (error) => {
        this.errorMessage = 'Unable to fetch budget groups for dropdown';
        this.showError();
      }
    );
  }

  getPartnersList() {
    this.apiService.getFreeGiftPartners().subscribe(
      (data) => {
        this.partnersList = data.result;
      },
      (error) => {
        this.errorMessage = 'Unable to fetch partners for dropdown';
        this.showError();
      }
    );
  }

  getSelectedBudgetGroupIds() {
    this.selectedBudgetGroupIds =
      this.selectedBudgetGroups.length > 0
        ? this.selectedBudgetGroups.map((sbg) => sbg.budgetGroupId)
        : [];
  }

  /**
   * Updates the selected budget groups based on the provided IDs.
   * Adds new budget groups if they are not already selected and removes those that are no longer in the provided IDs.
   *
   * @param ids - Array of budget group IDs to update the selection with.
   */
  updateSelectedBudgetGroups(ids: number[]): void {
    // Filter out budget groups that are no longer in the provided IDs
    this.selectedBudgetGroups = this.selectedBudgetGroups.filter(
      (budgetGroup) => ids.includes(budgetGroup.budgetGroupId)
    );

    // Extract currently selected budget group IDs
    this.getSelectedBudgetGroupIds();

    // Add new budget groups that are in the provided IDs but not already selected
    ids.forEach((id) => {
      if (!this.selectedBudgetGroupIds.includes(id)) {
        this.selectedBudgetGroups.push({
          budgetGroupId: id,
          amount: 0,
        });
      }
    });

    this.getSelectedBudgetGroupIds();
  }

  getBudgetGroupNamesFromBudgetGroups(budgetGroups: BudgetGroupDetails[]) {
    let ids: number[] =
      budgetGroups.length > 0
        ? budgetGroups.map((sbg) => sbg.budgetGroupId)
        : [];
    if (ids.length > 0) {
      return this.getBudgetGroupName(ids); // Return the result of getBudgetGroupName
    }
    return ''; // Return an empty string if no IDs are present
  }

  getBudgetGroupName(ids: number[]): string {
    let budgetGroupNames: string = '';
    ids.forEach((id) => {
      const budgetGroup = this.budgetGroupsList.find(
        (budgetGroup) => budgetGroup.id === id
      );
      if (budgetGroup) {
        budgetGroupNames += budgetGroup.name + ', ';
      }
    });
    return budgetGroupNames.slice(0, -2); // Remove the last comma and space
  }

  // Toggle selection for a single FreeGift
  toggleSelection(id: number) {
    if (this.selectedFreeGifts.has(id)) {
      this.selectedFreeGifts.delete(id); // Unselect
    } else {
      this.selectedFreeGifts.set(id, true); // Select
    }
    this.updateSelectAllState();
  }

  // Toggle Select All
  toggleSelectAll() {
    if (this.allSelected) {
      this.selectedFreeGifts.clear(); // Unselect all
    } else {
      this.freeGiftsArray.forEach((brand) =>
        this.selectedFreeGifts.set(brand.id, true)
      ); // Select all
    }
    this.allSelected = !this.allSelected;
  }

  // Update the "Select All" checkbox state
  updateSelectAllState() {
    this.allSelected =
      this.selectedFreeGifts.size === this.freeGiftsArray.length;
  }

  //get selectedFreeGifts' Ids
  getSelectedFreeGiftIds(): number[] {
    return Array.from(this.selectedFreeGifts.entries()) // Convert Map to an array of key-value pairs
      .filter(([id, isSelected]) => isSelected) // Filter selected brands
      .map(([id]) => id); // Extract only the IDs
  }
  //Deletes the selected Brand entries by calling the API service. If the deletion is successful, it clears the selected Brands map.
  deleteFreeGifts() {
    this.apiService.deleteFreeGift(this.getSelectedFreeGiftIds()).subscribe(
      (response) => {
        if (response.requestResult == 1) {
          this.selectedFreeGifts = new Map();
          this.getAllFreeGifts();
          this.showSuccess('delete');
        } else {
          this.errorMessage = response.responseTip;
          this.showError();
        }
      },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      }
    );
  }

  // get all Free Gifts
  getAllFreeGifts() {
    const params = {
      sortColumn: this.sortColumn,
      pageIndex: this.pageIndex,
      pageSize: this.pageSize,
      sortOrder: this.sortOrder,
      searchQuery: this.searchQuery,
    };
    this.apiService.getFreeGifts(params).subscribe((data) => {
      this.freeGiftsArray = data.result.data;
      this.pageIndex = data.result.pageIndex;
      this.pageSize = data.result.pageSize;
      this.totalCount = data.result.count;
      this.isDataLoaded = true;
    });
  }

  showSuccess(type: string) {
    const message =
      type === 'create'
        ? 'Free Gift created successfully.'
        : type == 'update'
        ? 'Free Gift updated successfully.'
        : 'Free Gift deleted successfully.';
    this.toastr.success(message, 'Success!');
  }
  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }

  // Triggers a search operation with the provided query string.
  onSearch(query: string): void {
    this.createFreeGift = false;
    this.closeDetails();
    this.searchSubject.next(query);
  }

  // Handle pagination changes
  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.getAllFreeGifts();
  }

  newProduct = {
    id: 0,
    title: '',
    importId: '',
    partnerId: null,
    budgetGroups: [],
    question: null,
  };

  toggleCreateFreeGiftForm() {
    //close the edit form if open
    this.closeDetails();
    this.getSelectedBudgetGroupIds();

    this.createFreeGift = !this.createFreeGift;
    if (this.createFreeGift) {
      // Go to new product
      this.selectedProduct = this.newProduct;

      // Fill the form
      this.selectedProductForm.patchValue(this.newProduct);

      // Mark for check
      this._changeDetectorRef.markForCheck();
    } else {
      this.selectedProductForm.reset();
    }
  }

  resetOptionForm() {
    this.suffix = '';
    this.englishOption = '';
    this.dutchOption = '';
    this.dutchQuestionControl.markAsUntouched();
    this.englishQuestionControl.markAsUntouched();
    this.dutchOptionControl.markAsUntouched();
    this.englishOptionControl.markAsUntouched();
    this.suffixControl.markAsUntouched();
  }
  budgetGroupInput = new FormControl('', [Validators.required]);

  dutchQuestionControl = new FormControl('');
  englishQuestionControl = new FormControl('');
  dutchOptionControl = new FormControl('');
  englishOptionControl = new FormControl('');
  suffixControl = new FormControl('');

  addOption() {
    if (
      this.dutchQuestion != '' &&
      this.englishQuestion != '' &&
      this.dutchOptionControl.value != '' &&
      this.englishOptionControl.value != '' &&
      this.suffixControl.value != ''
    ) {
      this.questionOptions.push({
        optionDutch: this.dutchOptionControl.value,
        optionEnglish: this.englishOptionControl.value,
        suffix: this.suffixControl.value,
      });
      this.dutchQuestionControl.markAsUntouched();
      this.englishQuestionControl.markAsUntouched();
      this.dutchOptionControl.markAsUntouched();
      this.englishOptionControl.markAsUntouched();
      this.suffixControl.markAsUntouched();
      this.resetOptionForm();
    } else {
      this.dutchQuestionControl.markAsTouched();
      this.englishQuestionControl.markAsTouched();
      this.dutchOptionControl.markAsTouched();
      this.englishOptionControl.markAsTouched();
      this.suffixControl.markAsTouched();
    }
  }

  checkoptionValidation() {
    if (this.dutchQuestion != '' && this.englishQuestion != '') {
      this.dutchOptionControl.markAsTouched();
      this.englishOptionControl.markAsTouched();
      this.suffixControl.markAsTouched();
    }
  }

  addFreeGifts() {
    if (
      this.selectedProductForm.valid &&
      this.selectedBudgetGroupIds.length > 0
    ) {
      let question = null;
      if (this.dutchQuestion != '' && this.englishQuestion != '') {
        if (this.questionOptions.length == 0) {
          this.dutchOptionControl.markAsTouched();
          this.englishOptionControl.markAsTouched();
          this.suffixControl.markAsTouched();
          return;
        } else {
          question = {
            questionDutch: this.dutchQuestion,
            questionEnglish: this.englishQuestion,
            freeGiftQuestionOptions: this.questionOptions,
          };
        }
      }

      const freeGift = this.selectedProductForm.getRawValue();
      const body = {
        title: freeGift.title,
        importId: freeGift.importId,
        partnerId: freeGift.partnerId,
        budgetGroups: this.selectedBudgetGroups,
        question: question,
      };

      this.apiService.createFreeGift(body).subscribe(
        (data) => {
          if (data.requestResult == 1) {
            this.getAllFreeGifts();
            this.resetForm();
            this.closeDetails();
            this.createFreeGift = false;
            this.showSuccess('create');
          } else {
            this.errorMessage = data.responseTip;
            this.showError();
          }
        },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        }
      );
    } else {
      this.selectedProductForm.markAllAsTouched();
      this.budgetGroupInput.markAsTouched();
      this.errorMessage = 'Please fill all the required fields.';
      this.showError();
    }
  }

  updateFreeGifts() {
    if (
      this.selectedProductForm.valid &&
      this.selectedBudgetGroupIds.length > 0
    ) {
      let question = null;
      if (this.dutchQuestion && this.englishQuestion) {
        if (this.questionOptions.length === 0) {
          this.dutchOptionControl.markAsTouched();
          this.englishOptionControl.markAsTouched();
          this.suffixControl.markAsTouched();
          return;
        } else {
          question = {
            questionDutch: this.dutchQuestion,
            questionEnglish: this.englishQuestion,
            freeGiftQuestionOptions: this.questionOptions,
          };
        }
      }
      const freeGift = this.selectedProductForm.getRawValue();
      const body = {
        title: freeGift.title,
        importId: freeGift.importId,
        partnerId: freeGift.partnerId,
        budgetGroups: this.selectedBudgetGroups,
        question: question,
      };
      this.apiService.updateFreeGift(body, freeGift.id).subscribe(
        (data) => {
          if (data.requestResult == 1) {
            this.getAllFreeGifts();
            this.resetForm();
            this.closeDetails();
            this.showSuccess('update');
          } else {
            this.errorMessage = data.responseTip;
            this.showError();
          }
        },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        }
      );
    } else {
      this.selectedProductForm.markAllAsTouched();
      this.budgetGroupInput.markAsTouched();

      this.errorMessage = 'Please fill all the required fields.';
      this.showError();
    }
  }

  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * After view init
   */
  ngAfterViewInit(): void {
    if (this._sort && this._paginator) {
      setTimeout(() => {
        // Set the initial sort
        this._sort.sort({
          id: 'id',
          start: 'desc',
          disableClear: true,
        });
      });

      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;
          this.pageIndex = 0;

          //reset and close the form if it is open
          this.resetForm();
          this.closeDetails();

          // set the sort column and sort order
          this.sortColumn = this.getSortColumn(this._sort.active);
          this.sortOrder = this._sort.direction === 'asc' ? 2 : 1;

          // Get the Free gifts
          this.getAllFreeGifts();
        });
    }
  }

  getSortColumn(name: string) {
    switch (name) {
      case 'title':
        return 1;
        break;
      case 'importId':
        return 2;
        break;
      default:
        return 0;
    }
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggle product details
   *
   * @param id
   */
  toggleDetails(id: number): void {
    this.createFreeGift = false; // Close create brand form if open

    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct.id === id) {
      // Close the details
      this.closeDetails();
      return;
    }

    const myMap = new Map(this.freeGiftsArray.map((obj) => [obj.id, obj]));

    this.selectedProduct = myMap.get(id);
    this.selectedProductForm.patchValue(this.selectedProduct);
    this.questions = this.selectedProduct.question;
    this.questionOptions = this.questions.freeGiftQuestionOptions;
    this.selectedBudgetGroups = this.selectedProduct.budgetGroups;
    this.dutchQuestion = this.questions.questionDutch;
    this.englishQuestion = this.questions.questionEnglish;
    this.getSelectedBudgetGroupIds();
  }

  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
    this.resetOptionForm();
    this.budgetGroupInput.markAsUntouched();
    this.resetForm();
  }

  //reset form
  resetForm() {
    CommonHelperService.preserveId(this.selectedProductForm);
    this.budgetGroupInput.reset();
    this.selectedBudgetGroupIds = [];
    this.selectedBudgetGroups = [];
    this.dutchOption = '';
    this.englishOption = '';
    this.dutchQuestion = '';
    this.englishQuestion = '';
    this.suffix = '';
    this.questionOptions = [];
    this.resetOptionForm();
  }

  /**
   * Delete the selected product using the form data
   */
  async deleteSelectedProduct(id: number | null, isFromDeleteBtn = false): Promise<void> {

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Free Gift');

    if (!confirmed) {
      return;
    }

    if (!isFromDeleteBtn) {
      this.selectedFreeGifts.clear();
      this.selectedFreeGifts.set(id, true);
    }

    this.deleteFreeGifts();
    this.closeDetails();
  }

  async deleteSelectedBudgetGroup(id: number): Promise<void> {

    // Open the confirmation dialog
    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Budget group', DeleteTypes.Custom, 'Are you sure you want to remove this Budget group?');

    if (!confirmed) {
      return;
    }
    
    this.selectedBudgetGroups = this.selectedBudgetGroups.filter((budgetGroup) => budgetGroup.budgetGroupId != id);

    this.getSelectedBudgetGroupIds();
  }

  async deleteSelectedOption(option: FreeGiftQuestionOption): Promise<void> {

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('option', DeleteTypes.Custom, 'Are you sure you want to remove this option?');

    if (!confirmed) {
      return;
    }
    
    this.questionOptions = this.questionOptions.filter((questionOption) => questionOption != option);
  }

  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }

  onSelectionChange(value: any) {
    if (value && value != '') {
      if (value == 'budgetGroupId') {
        console.log(this.budgetGroupInput.value);
        this.updateSelectedBudgetGroups(this.selectedBudgetGroupIds);
      }
      this.selectedProductForm.get(value).markAsTouched();
    }
  }

  onDropdownBlur(type: string) {
    if (type == 'budgetGroupId' && !this.selectedBudgetGroupIds || this.selectedBudgetGroupIds?.length == 0) {
      this.budgetGroupInput.markAsTouched();
      console.log(this.budgetGroupInput.touched, this.selectedBudgetGroupIds);
    }else {
      this.selectedProductForm.get('partnerId').markAsTouched();
    }
  }
}
