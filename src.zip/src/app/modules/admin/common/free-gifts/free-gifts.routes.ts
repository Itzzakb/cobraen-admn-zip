import { Routes } from "@angular/router";
import { FreeGiftsComponent } from "./free-gifts.component";

export default [
    {
        path: '',
        component: FreeGiftsComponent
    }
] as Routes