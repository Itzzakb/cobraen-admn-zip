import {
  AsyncPipe,
  CommonModule,
  CurrencyPipe,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormControl,
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatTooltipModule } from '@angular/material/tooltip';

import {
  InventoryBrand,
  InventoryCategory,
  InventoryPagination,
  InventoryProduct,
  InventoryTag,
  InventoryVendor,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  takeUntil,
} from 'rxjs';
import {
  CdkDrag,
  CdkDragDrop,
  CdkDragPlaceholder,
  CdkDropList,
  moveItemInArray,
} from '@angular/cdk/drag-drop';
import { ColumnForFulfillment, Fulfillment, FulfillmentLayout, Partner } from 'app/shared/types/interfaces';
import { ToastrService } from 'ngx-toastr';
import { ApiService } from '@fuse/services/api-service.service';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { NgxMatTimepickerModule } from 'ngx-mat-timepicker';
import { SearchableDropdownComponent } from 'app/shared/components/searchable-dropdown/searchable-dropdown.component';
import { DeleteConfirmationService, DeleteTypes } from 'app/shared/services/delete-confirmation.service';
import { CommonHelperService } from 'app/shared/services/common-helper.service';

interface PartnerColumns {
  columnName: string,
  columnId: string,
  formulaColumnName: string
}

@Component({
  selector: 'app-partners',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 80px 1fr 1fr 88px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 80px 1fr 1fr 88px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 80px 1fr 1fr 88px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 80px 1fr 1fr 88px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    CdkDropList,
    CdkDrag,
    CdkDragPlaceholder,
    MatTooltipModule,
    CommonModule,
    MatDatepickerModule,
    NgxMatTimepickerModule,
    CommonModule,
    SearchableDropdownComponent
  ],
  templateUrl: './partners.component.html',
  styleUrl: './partners.component.scss',
})
export class PartnersComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  products$: Observable<InventoryProduct[]>;

  brands: InventoryBrand[];
  categories: InventoryCategory[];
  filteredTags: InventoryTag[];
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: InventoryPagination;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: Partner | null = null;
  selectedProductForm: UntypedFormGroup;
  tags: InventoryTag[];
  tagsEditMode: boolean = false;
  vendors: InventoryVendor[];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  partnersArray: Partner[] = [];
  selectedPartners: Map<number, boolean> = new Map(); // Tracks selected Partners
  allSelected: boolean = false;

  searchQuery: string = '';
  searchSubject = new Subject<string>();
  searchSubscription: any;

  // Pagination properties
  pageIndex: number = 0;
  pageSize: number = 10;
  totalCount: number = 0;
  sortOrder: number = 1;
  sortColumn: number = 0;

  createPartner = false;
  createFulfillmentLayout = false;

  columnList: ColumnForFulfillment[] = [];
  fulfillmentList: Fulfillment[] = [];

  fulfillmentId: number = null;
  fulfillmentName: string = '';

  fulfillmentLayouts: FulfillmentLayout[] = [];

  fulfillmentLayoutForm: UntypedFormGroup;
  selectedFulfillmentLayout: FulfillmentLayout | null = null;



  errorMessage = '';
  isFulfillmentLayoutAdded = false;
  isDataLoaded: boolean = false;

  passwordPatternErrorMessage = 'Use a combo of uppercase letters, lowercase letters, numbers, some special characters ( !, @, $, %, ^, &, *, +,#) and minimum length should be 12.';


  @ViewChild('headerPaginator') headerPaginator!: MatPaginator;
  @ViewChild('footerPaginator') footerPaginator!: MatPaginator;

  indexImageErrorMessage: string = '';
  indexImage: string = '';
  indexImageFile: File | null = null;

  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _deleteConfirmationService: DeleteConfirmationService,
    private _formBuilder: UntypedFormBuilder,
    private apiService: ApiService,
    private toastr: ToastrService
  ) { }

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.selectedProductForm = this._formBuilder.group({
      id: [''],
      name: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      host: [''],
      port: [[]],
      path: [''],
      userName: [''],
      password: ['', Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?!.*[,)(={}\\]\\[;'_:><?/ `~]).{12,}$")],
      fulfillmentId: [''],
      checkHeaderNames: [false],
      fileName: ['', [Validators.required]],
      frequency: ['', [Validators.required]],
      lastDateTimeSendToFulfillment: [''],
      lastDateTimeSendToFulfillmentTime: [''],
      productType: [''],
      description: ['', [Validators.required]],
      shopName: ['', [Validators.required]],
      descriptionInEnglish: ['', [Validators.required]]
    });


    this.fulfillmentLayoutForm = this._formBuilder.group({
      id: [''],
      sequenceNumber: [''],
      columnName: ['', Validators.required],
      columnId: [''],
      rowName: [''],
      formulaColumnName: ['']
    });

    //get all columns for fulfillment
    this.getColumnList()
    //this.get all fulfillments
    this.getFulfillmentList()
    // Debounce search input to optimize API calls
    this.searchSubscription = this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe(query => {
        this.searchQuery = query;
        this.pageIndex = 0; // Reset to first page on new search
        this.footerPaginator.firstPage();
        this.getAllPartners();
      });
  }

  fulfillmentIdInput = new FormControl('', [Validators.required]);
  
  getFulfilmentName() {
    this.fulfillmentName = this.fulfillmentList.find(fulfillment => fulfillment.id === this.fulfillmentId).name;

    if ((this.fulfillmentName == 'csv' || this.fulfillmentName == 'xlsx') && this.fulfillmentLayouts.length == 0) {
      this.toggleCreateFulfillmentLayoutForm(true);
    }

    this.fulfillmentIdInput.markAsTouched();
  }

  // Toggle selection for a single brand
  toggleSelection(brandId: number) {
    if (this.selectedPartners.has(brandId)) {
      this.selectedPartners.delete(brandId); // Unselect
    } else {
      this.selectedPartners.set(brandId, true); // Select
    }
    this.updateSelectAllState();
  }

  // Toggle Select All
  toggleSelectAll() {
    if (this.allSelected) {
      this.selectedPartners.clear(); // Unselect all
    } else {
      this.partnersArray.forEach(brand => this.selectedPartners.set(brand.id, true)); // Select all
    }
    this.allSelected = !this.allSelected;
  }

  // Update the "Select All" checkbox state
  updateSelectAllState() {
    this.allSelected = this.selectedPartners.size === this.partnersArray.length;
  }

  //get selectedBrands' Ids
  getSelectedPartnerIds(): number[] {
    return Array.from(this.selectedPartners.entries()) // Convert Map to an array of key-value pairs
      .filter(([id, isSelected]) => isSelected) // Filter selected brands
      .map(([id]) => id); // Extract only the IDs
  }
  //Deletes the selected Brand entries by calling the API service. If the deletion is successful, it clears the selected Brands map.
  deletePartners() {
    this.apiService.deletePartner(this.getSelectedPartnerIds()).subscribe((response) => {
      if (response.requestResult == 1) {
        this.selectedPartners = new Map();
        this.getAllPartners();
        this.showSuccess('delete');
      } else {
        this.errorMessage = response.responseTip;
        this.showError();
      }
    }, (error) => {
      this.errorMessage = error.error.responseTip;
      this.showError();
    })
  }

  //get all fulfillments
  getFulfillmentList() {
    this.apiService.getAllFulfillments().subscribe((data) => {
      this.fulfillmentList = data.result;
    },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      })
  }

  //get all columns for fulfillment
  getColumnList() {
    this.apiService.getAllCoumnsForFulfillment().subscribe((data) => {
      this.columnList = data.result;
    },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      })
  }

  // get all partners
  getAllPartners() {
    const params = {
      sortColumn: this.sortColumn,
      pageIndex: this.pageIndex,
      pageSize: this.pageSize,
      sortOrder: this.sortOrder,
      searchQuery: this.searchQuery
    }
    this.apiService.getPartners(params).subscribe((data) => {
      this.partnersArray = data.result.data;
      this.pageIndex = data.result.pageIndex;
      this.pageSize = data.result.pageSize;
      this.totalCount = data.result.count;
      this.isDataLoaded = true;
    });
  }

  showSuccess(type: string) {
    const message = type === 'create' ? 'Partner created successfully.' : (type == 'update' ? 'Partner updated successfully.' : 'Partner deleted successfully.');
    this.toastr.success(message, 'Success!');
  }
  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }

  // Triggers a search operation with the provided query string.
  onSearch(query: string): void {
    this.createPartner = false;
    this.closeDetails();
    this.searchSubject.next(query);
  }

  // Handle pagination changes
  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.getAllPartners();
  }

  toggleCreatePartnerForm() {
    //close the edit form if open
    this.closeDetails();

    this.createPartner = !this.createPartner;
    if (this.createPartner) {
      const newProduct = {
        id: 0,
        name: '',
        email: '',
        host: '',
        port: '',
        path: '',
        userName: '',
        fulfillmentId: null,
        checkHeaderNames: false,
        fileName: '',
        frequency: null,
        lastDateTimeSendToFulfillment: null,
        lastDateTimeSendToFulfillmentTime: null,
        productType: null,
        fulfillmentLayouts: [],
        description: '',
        image: '',
        shopName: '',
        descriptionInEnglish: ''
      }
      // Go to new product
      this.selectedProduct = newProduct;

      // Fill the form
      this.selectedProductForm.patchValue(newProduct);


      // Mark for check
      this._changeDetectorRef.markForCheck();
    } else {
      this.selectedProductForm.reset();
    }
  }



  toggleCreateFulfillmentLayoutForm(isFromGetFulfillmentName: boolean = false) {
    //close the edit form if open
    this.closeFulfillmentLayoutDetails();

    this.createFulfillmentLayout = isFromGetFulfillmentName ? true : !this.createFulfillmentLayout;
    if (this.createFulfillmentLayout) {
      const newProduct = {
        id: 0,
        sequenceNumber: 0,
        columnName: '',
        columnId: null,
        rowName: '',
        formulaColumnName: ''
      }
      // Go to new product
      this.selectedFulfillmentLayout = newProduct;

      // Fill the form
      this.fulfillmentLayoutForm.patchValue(newProduct);

      // Mark for check
      this._changeDetectorRef.markForCheck();
    } else {
      this.fulfillmentLayoutForm.reset();
    }
  }

  checkFulfillmentId(){
    if(this.fulfillmentName == 'csv' || this.fulfillmentName == 'xlsx'){
      if(this.fulfillmentLayouts.length > 0){
        return true;
      }else{
        return false;
      }
    }else{
      return true;
    }
  }

  addPartner() {
    if (this.selectedProductForm.valid  && this.indexImageErrorMessage == '') {
      if (this.checkFulfillmentId()){
        //append the form field if the value is not null
        const appendIfNotNull = (key: string, value: any) => {
          if (value !== null && value !== undefined && value !== '') {
            formData.append(key, value);
          }
        };
        const partnerForm = this.selectedProductForm.value;
        const formData = new FormData();
        formData.append('Name', partnerForm.name);
        formData.append('Email', partnerForm.email);
        appendIfNotNull('Host', partnerForm.host);
        appendIfNotNull('Port', partnerForm.port);
        appendIfNotNull('Path', partnerForm.path);
        appendIfNotNull('UserName', partnerForm.userName);
        appendIfNotNull('Password', partnerForm.password);
        formData.append('FulfillmentId', this.fulfillmentId.toString());
        formData.append('FileName', partnerForm.fileName);
        formData.append('Frequency', partnerForm.frequency);
        formData.append('Description', partnerForm.description );
        formData.append('DescriptionInEnglish', partnerForm.description );
        formData.append('ShopName', partnerForm.shopName );

        if (partnerForm.lastDateTimeSendToFulfillment) {
          partnerForm.lastDateTimeSendToFulfillment = CommonHelperService.GenerateISODateTimeString(partnerForm.lastDateTimeSendToFulfillment, partnerForm.lastDateTimeSendToFulfillmentTime);
        }

        formData.append('LastDateTimeSendToFulfillment', partnerForm.lastDateTimeSendToFulfillment ? partnerForm.lastDateTimeSendToFulfillment : '');
        formData.append('ProductType', partnerForm.productType);

        if(this.fulfillmentLayouts.length > 0){
          this.addCheckHeaderNamesKey(partnerForm.checkHeaderNames).forEach((fulfillment, index)=>{
            appendIfNotNull(`FulfillmentLayouts[${index}].columnName`,  fulfillment.columnName);
            if(fulfillment.columnId){
              appendIfNotNull(`FulfillmentLayouts[${index}].dropDownColumnId`,  fulfillment.columnId.toString());            
              appendIfNotNull(`FulfillmentLayouts[${index}].dropDownColumnName`, fulfillment.rowName);
            }else{
              
              appendIfNotNull(`FulfillmentLayouts[${index}].rowName`, fulfillment.rowName);
            }
            appendIfNotNull(`FulfillmentLayouts[${index}].sequenceNumber`,  fulfillment.sequenceNumber.toString());
            appendIfNotNull(`FulfillmentLayouts[${index}].checkHeaderNames`,  fulfillment.checkHeaderNames.toString());
            if(fulfillment.formulaColumnName){
              appendIfNotNull(`FulfillmentLayouts[${index}].formulaColumnName`,  fulfillment.formulaColumnName);
            }

          })

        }


        if (this.indexImageFile != null) {
          formData.append('Image', this.indexImageFile);
        }
        this.apiService.createPartner(formData).subscribe((data) => {
          if (data.requestResult == 1) {
            this.getAllPartners();
            this.resetForm();
            this.closeDetails();
            this.createPartner = false;
            this.showSuccess('create');
          } else {
            this.errorMessage = data.responseTip;
            this.showError();
          }
        },
          (error) => {
            this.errorMessage = error.error.responseTip;
            this.showError();
          });        
      }else{
        this.errorMessage = 'Please Add Fulfillment Layout.';
        this.showError();
      }
    } else {
      this.selectedProductForm.markAllAsTouched();
      this.fulfillmentIdInput.markAsTouched();
      this.errorMessage = 'Please fill all the required fields';
      this.showError();
    }
  }

  addCheckHeaderNamesKey(checkHeaderName: boolean = false) {
    return this.fulfillmentLayouts.map(layout => ({
      ...layout,
      checkHeaderNames: checkHeaderName
    }));
  }

  getFulfillmentName(id: number){
    return this.fulfillmentList.filter( fulfillment => fulfillment.id == id)[0].name;
  }


  updatePartner() {
    if (this.selectedProductForm.valid  && this.indexImageErrorMessage == '') {
      if (this.checkFulfillmentId()){
        const partnerForm = this.selectedProductForm.value;
        const formData = new FormData();

        //append the form field if the value is not null
        const appendIfNotNull = (key: string, value: any) => {
          if (value !== null && value !== undefined && value !== '') {
            formData.append(key, value);
          }
        };

        formData.append('Id', this.selectedProduct.id.toString());
        formData.append('Name', partnerForm.name);
        formData.append('Email', partnerForm.email);
        appendIfNotNull('Host', partnerForm.host);
        appendIfNotNull('Port', partnerForm.port);
        appendIfNotNull('Path', partnerForm.path);
        appendIfNotNull('UserName', partnerForm.userName);
        appendIfNotNull('Password', partnerForm.password);
        formData.append('FulfillmentId', this.fulfillmentId.toString());
        formData.append('FileName', partnerForm.fileName);
        formData.append('Frequency', partnerForm.frequency);
        formData.append('Description', partnerForm.description );
        formData.append('DescriptionInEnglish', partnerForm.description );
        formData.append('ShopName', partnerForm.shopName );

        if (partnerForm.lastDateTimeSendToFulfillment) {
          partnerForm.lastDateTimeSendToFulfillment = CommonHelperService.GenerateISODateTimeString(partnerForm.lastDateTimeSendToFulfillment, partnerForm.lastDateTimeSendToFulfillmentTime);
        }

        formData.append('LastDateTimeSendToFulfillment', partnerForm.lastDateTimeSendToFulfillment ? partnerForm.lastDateTimeSendToFulfillment : '');
        formData.append('ProductType', partnerForm.productType);

        if (this.indexImageFile != null) {
          formData.append('Image', this.indexImageFile);
        }
        if(this.fulfillmentLayouts.length > 0){
          this.addCheckHeaderNamesKey(partnerForm.checkHeaderNames).forEach((fulfillment, index) => {
            appendIfNotNull(`FulfillmentLayouts[${index}].columnName`, fulfillment.columnName);
            if (fulfillment.columnId) {
              appendIfNotNull(`FulfillmentLayouts[${index}].dropDownColumnId`, fulfillment.columnId.toString());
              appendIfNotNull(`FulfillmentLayouts[${index}].dropDownColumnName`, fulfillment.rowName);
            } else {
              appendIfNotNull(`FulfillmentLayouts[${index}].rowName`, fulfillment.rowName);
            }
            appendIfNotNull(`FulfillmentLayouts[${index}].sequenceNumber`, fulfillment.sequenceNumber.toString());
            appendIfNotNull(`FulfillmentLayouts[${index}].checkHeaderNames`, fulfillment.checkHeaderNames.toString());

            if (fulfillment.formulaColumnName) {
              appendIfNotNull(`FulfillmentLayouts[${index}].formulaColumnName`, fulfillment.formulaColumnName);
            }

          })

        }


        this.apiService.updatePartner(formData).subscribe((data) => {
          if (data.requestResult == 1) {
            this.getAllPartners();
            this.resetForm();
            this.closeDetails();
            this.showSuccess('update');
          } else {
            this.errorMessage = data.responseTip;
            this.showError();
          }
        },
          (error) => {
            this.errorMessage = error.error.responseTip;
            this.showError();
          });
      }else{
        this.errorMessage = 'Please Add Fulfillment Layout.';
        this.showError();
      }
    } else {
      this.selectedProductForm.markAllAsTouched();
      this.fulfillmentIdInput.markAsTouched();
      this.errorMessage = 'Please fill all the required fields';
      this.showError();
    }
  }

  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * After view init
   */
  ngAfterViewInit(): void {    
    if (this._sort && this._paginator) {
      setTimeout(() => {
        // Set the initial sort
        this._sort.sort({
          id: 'id',
          start: 'desc',
          disableClear: true,
        });
      });

      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;
          this.pageIndex = 0;

          //reset and close the form if it is open
          this.resetForm();
          this.closeDetails();

          // set the sort column and sort order
          this.sortColumn = this.getSortColumn(this._sort.active);
          this.sortOrder = this._sort.direction === 'asc' ? 2 : 1;

          // Get the Brands
          this.getAllPartners();
        });

    }
  }

  getSortColumn(name: string) {
    switch (name) {
      case 'name':
        return 1;
        break;
      case 'email':
        return 2;
        break;
      default:
        return 0;
    }
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggle product details
   *
   * @param id
   */
  toggleDetails(id: number): void {
    this.createPartner = false;
    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct.id === id) {
      // Close the details
      this.closeDetails();
      return;
    }

    const myMap = new Map(this.partnersArray.map(obj => [obj.id, obj]));

    this.selectedProduct = myMap.get(id);
    this.fulfillmentId = this.selectedProduct.fulfillmentId;
    this.getFulfilmentName();
    
    this.selectedProduct.lastDateTimeSendToFulfillmentTime = CommonHelperService.GetTimeStampFromDateTime(this.selectedProduct.lastDateTimeSendToFulfillment);
    
    this.fulfillmentLayouts = this.selectedProduct.fulfillmentLayouts;
    this.selectedProductForm.patchValue(this.selectedProduct);
    this.indexImage = this.selectedProduct.image;
  }


  toggleFulfillmentLayoutDetails(fulfillmentLayout): void {
    this.createFulfillmentLayout = false;
    // If the product is already selected...
    if (this.selectedFulfillmentLayout && (fulfillmentLayout.id !== 0 ? this.selectedFulfillmentLayout.id === fulfillmentLayout.id : this.selectedFulfillmentLayout === fulfillmentLayout)) {
      // Close the details
      this.closeFulfillmentLayoutDetails();
      this.resetFulfillmentLayoutForm();
      return;
    }

    const myMap = fulfillmentLayout.id !== 0 ? new Map(this.fulfillmentLayouts.map(obj => [obj.id, obj])) : new Map(this.fulfillmentLayouts.map(obj => [obj.columnName, obj]));

    let key = fulfillmentLayout.id !== 0 ? fulfillmentLayout.id : fulfillmentLayout.columnName;

    this.selectedFulfillmentLayout = myMap.get(key as never);
    this.fulfillmentLayoutForm.patchValue(this.selectedFulfillmentLayout);
    // if (this.selectedFulfillmentLayout.columnId != 0) {
    //   this.fulfillmentLayoutForm.get('rowName').setValue(''); // Set rowName to empty string
    // }
  }

  onlyOneRequiredvalidator(): boolean {
    const columnId = this.fulfillmentLayoutForm.get('columnId')?.value == 0 ? null : this.fulfillmentLayoutForm.get('columnId')?.value;
    const rowName = this.fulfillmentLayoutForm.get('rowName')?.value;
    const formulaColumnName = this.fulfillmentLayoutForm.get('formulaColumnName')?.value;

    //console.log((rowName);

    const filledFields = [columnId, rowName, formulaColumnName].filter(value => {
      return value !== null && value !== undefined && value !== '';
    });

    //console.log((filledFields);

    if (filledFields.length === 1) {
      return true; // valid
    }

    this.errorMessage = 'Please Check StaticText and FormulaText Filling.';
    this.showError();

    return false; // invalid
  }

  getRowName() {
    if (this.fulfillmentLayoutForm.get('columnId').value != 0) {
      const selectedColumn = this.columnList.find(column => column.id === this.fulfillmentLayoutForm.get('columnId').value);
      if (selectedColumn) {
        this.fulfillmentLayoutForm.get('rowName').setValue(selectedColumn.name); // Set rowName to columnName
      }
    }
  }



  /**
   * Handles the saving of a fulfillment layout form. 
   * Validates the form, processes the data, and updates the fulfillment layouts list.
   * 
   * - If the form is valid:
   *   - Ensures only one required validator is applied.
   *   - Retrieves the row name.
   *   - Assigns a sequence number if the layout is new.
   *   - Updates the fulfillment layouts list and sorts it by sequence number.
   *   - Resets the form and closes the layout details view.
   *   - Disables the creation mode for the fulfillment layout.
   *   - If the form is invalid:
   *   - Marks all form fields as touched.
   *   - Displays an error message prompting the user to fill all required fields.
   * 
   * @remarks
   * This function assumes that `fulfillmentLayoutForm`, `fulfillmentLayouts`, 
   * `selectedFulfillmentLayout`, and other related properties are properly initialized.
   */
  saveFulfillmentLayout() {
    //console.log(("save");
    if (this.fulfillmentLayoutForm.valid) {
      if(this.onlyOneRequiredvalidator()){
        this.getRowName();
      this.fulfillmentLayoutForm.get('sequenceNumber').setValue(this.fulfillmentLayouts.length + 1);

      this.fulfillmentLayouts.push(this.fulfillmentLayoutForm.value);
      this.fulfillmentLayouts.sort((a, b) => a.sequenceNumber - b.sequenceNumber);
      this.resetFulfillmentLayoutForm();
      this.closeFulfillmentLayoutDetails();
      this.createFulfillmentLayout = false;
      }
    } else {
      this.fulfillmentLayoutForm.markAllAsTouched();
      this.errorMessage = 'Please fill all the required fields';
      this.showError();
    }
  }

  updateFulfillmentLayout() {
    if (this.fulfillmentLayoutForm.valid) {
      if (this.onlyOneRequiredvalidator()) {
      this.getRowName();

      const isNewLayout = this.fulfillmentLayoutForm.get('id').value === 0;
      const filterCondition = isNewLayout
        ? (layout: any) => layout.sequenceNumber !== this.selectedFulfillmentLayout.sequenceNumber
        : (layout: any) => layout.id !== this.selectedFulfillmentLayout.id;

      this.fulfillmentLayouts = this.fulfillmentLayouts.filter(filterCondition);

      this.fulfillmentLayouts.push(this.fulfillmentLayoutForm.value);
      this.fulfillmentLayouts.sort((a, b) => a.sequenceNumber - b.sequenceNumber);

      this.resetFulfillmentLayoutForm();
      this.closeFulfillmentLayoutDetails();
      this.createFulfillmentLayout = false;
      }
    } else {
      this.fulfillmentLayoutForm.markAllAsTouched();
      this.errorMessage = 'Please fill all the required fields';
      this.showError();
    }
  }



  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
    this.fulfillmentLayouts = [];
    this.fulfillmentIdInput.reset();
    this.fulfillmentId = null;
    this.indexImage = '';
    this.indexImageFile = null; 
  }

  closeFulfillmentLayoutDetails(): void {
    this.selectedFulfillmentLayout = null;
  }

  //reset form
  resetForm() {
    this.selectedProductForm.reset();
    this.indexImage = '';
    this.indexImageFile = null;
    this.fulfillmentIdInput.reset();
  }

  resetFulfillmentLayoutForm() {
    this.fulfillmentLayoutForm.reset();
  }

  /**
   * Delete the selected product using the form data
   */
  async deleteSelectedProduct(id: number | null, isFromDeleteBtn = false): Promise<void> {

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Partner');

    if (!confirmed) {
      return;
    }

    if (!isFromDeleteBtn) {
      this.selectedPartners.clear();
      this.selectedPartners.set(id, true)
    }

    this.deletePartners();
    this.closeDetails();

  }

  async removeSelectedFulfillmentLayout(fulfillmentLayout): Promise<void> {

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Fulfillment Layout', DeleteTypes.Custom, 'Are you sure you want to remove this Fulfillment Layout?', 'Remove');

    if (confirmed) {

      this.fulfillmentLayouts = this.fulfillmentLayouts.filter((layout) => layout != fulfillmentLayout);
      this.fulfillmentLayouts.sort((a, b) => a.sequenceNumber - b.sequenceNumber);

      this.closeFulfillmentLayoutDetails();
    }
  }

  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }



  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.fulfillmentLayouts, event.previousIndex, event.currentIndex);
    this.updateSequenceNumbers();
  }

  updateSequenceNumbers() {
    this.fulfillmentLayouts.forEach((layout, index) => {
      layout.sequenceNumber = index + 1;
    });
  }

  checkindexImageFile(){
    if(!this.indexImageFile && this.indexImage == ''){
      this.indexImageErrorMessage = 'Index image is required';
    }else{
      this.indexImageErrorMessage = '';
    }
  }

  public GetFileOnLoad(event: any) {
    if (event.target.files && event.target.files[0]) {
      var file = event.target.files[0] as File;
      this.indexImageFile = file;
      this.indexImage = URL.createObjectURL(file);
    }
    //console.log((this.indexImage);
    this.checkindexImageFile();
  }

  removeindexImageFile(inputBox: string) {
    this.indexImage = '';
    this.indexImageFile = null;
    var element = document.getElementById(inputBox) as HTMLInputElement | null;
    if (element != null) {
      element.value = '';
    }
    this.checkindexImageFile();
  }

  onSelectionChange(value: any) {
    if(value && value !=''){
        this.fulfillmentLayoutForm.get(value).markAsTouched();      
    }
  }

  onDropdownBlur() {
    this.fulfillmentIdInput.markAsTouched();
  }
}

