import { Routes } from "@angular/router";
import { PartnersComponent } from "./partners.component";

export default [
    {
        path: '',
        component: PartnersComponent
    }
] as Routes