import { Routes } from "@angular/router";
import { VatComponent } from "./vat.component";

export default [
    {
        path: '',
        component: VatComponent
    }
] as Routes