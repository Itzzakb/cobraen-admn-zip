import { ChangeDetectionStrategy, Component, inject, OnInit } from '@angular/core';
import {
    FormsModule,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormControl,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule, MatLabel } from '@angular/material/form-field';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { ApiService } from '@fuse/services/api-service.service';
import { ErrorMesageService } from 'app/shared/services/error-message.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'change-password-dialog',
  templateUrl: './change-password-dialog.component.html',
  standalone: true,
  imports: [
    MatDialogModule,
    MatButtonModule,
    MatLabel,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatIcon,
    MatIconModule
    
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChangePasswordDialog implements OnInit {
  constructor(
    private _formBuilder: UntypedFormBuilder,
    private dialogRef: MatDialogRef<ChangePasswordDialog>,
    private apiService: ApiService,
    private toastr: ToastrService,
    private errorMessageService: ErrorMesageService
  ) {}

  changePasswordForm: UntypedFormGroup;

  errorMessage : string = '';
  isNewAndConfirmPasswordSame: boolean =  false;

  showOldPassword: boolean = false;
  showNewPassword: boolean = false;
  showConfirmPassword: boolean = false;

  passwordPatternErrorMessage = 'Use a combo of uppercase letters, lowercase letters, numbers, some special characters ( !, @, $, %, ^, &, *, +,#) and minimum length should be 12.';

  ngOnInit(): void {
    this.changePasswordForm = this._formBuilder.group({
      oldPassword: ['', [Validators.required]],
      newPassword: ['', [Validators.required, Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?!.*[,)(={}\\]\\[;'_:><?/ `~]).{12,}$")]],
      confirmPassword: ['', [Validators.required]]
    });
  }


  /**
   * Handles the submission of the change password form.
   * 
   * This method validates the form and ensures that the new password
   * and confirm password fields match. If the form is valid, it sends
   * a request to change the password using the provided API service.
   * 
   * - On success, it displays a success message and closes the dialog.
   * - On failure, it captures and displays the error message.
   * 
   * If the form is invalid, it marks all form fields as touched to
   * trigger validation messages.
   */
  onSubmit(): void {
    if (this.changePasswordForm.valid && this.isNewAndConfirmPasswordSame) {
      const requestBody = {
        "password" : this.changePasswordForm.get('oldPassword').value,
        "newPassword": this.changePasswordForm.get('newPassword').value,
        "confirmPassword": this.changePasswordForm.get('confirmPassword').value
      }
      this.apiService.changePassword(requestBody).subscribe((data)=>{
        this.showSuccess('Password changed, successfully.');
        this.dialogRef.close(); 
      },
    (error)=>{
      this.errorMessage = error.error.responseTip == 'InvalidCredentails' ? 'Incorrect old password' : this.errorMessageService.getErrorMessage(error.error.responseTip);
      this.showError();
    })
    } else {
      this.changePasswordForm.markAllAsTouched();
    }
  }



  /**
   * Validates if the confirmation password matches the new password.
   * Updates the `isNewAndConfirmPasswordSame` property based on the comparison.
   *
   * @param event - The DOM event triggered by the input field for the confirmation password.
   */
  checkconfirmPsw(event: any) {
      const newPassword = this.changePasswordForm.get('newPassword').value;
      this.isNewAndConfirmPasswordSame =   newPassword == event.target.value ;
  }

  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }

  showSuccess(data: string) {
    const message = data;
    this.toastr.success(message, 'Success!');
  }

  onCancel(): void {
    this.dialogRef.close(null);
  }

  toggleIsPassword(data:number){
    switch(data){
      case 0:
        this.showOldPassword = !this.showOldPassword;
        break;
      case 1:
        this.showNewPassword = !this.showNewPassword;
        break;
      case 2:
        this.showConfirmPassword = !this.showConfirmPassword;
    }
  }
}