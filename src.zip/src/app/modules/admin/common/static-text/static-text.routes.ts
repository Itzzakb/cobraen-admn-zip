import { Routes } from '@angular/router';

import { StaticTextComponent } from './static-text.component';

export default [
    {
        path: '',
        component: StaticTextComponent,
    },
] as Routes;