import {
    AsyncPipe,
    CurrencyPipe,
    NgClass,
    NgTemplateOutlet,
} from '@angular/common';
import {
    AfterViewInit,
    ChangeDetectorRef,
    Component,
    OnDestroy,
    OnInit,
    ViewChild,
    ViewEncapsulation,
} from '@angular/core';
import {
    FormsModule,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormControl,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
    MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { InventoryService } from 'app/shared/services/inventory.service';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatTooltipModule } from '@angular/material/tooltip';

import {
    InventoryBrand,
    InventoryCategory,
    InventoryPagination,
    InventoryProduct,
    InventoryTag,
    InventoryVendor,
} from 'app/shared/types/inventory.types';
import {
    Observable,
    Subject,
    debounceTime,
    distinctUntilChanged,
    takeUntil,
} from 'rxjs';
import { products } from 'app/mock-api/apps/ecommerce/inventory/data';
import { cmsContent } from 'app/shared/types/interfaces';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { DeleteConfirmationService } from 'app/shared/services/delete-confirmation.service';
import { CommonHelperService } from 'app/shared/services/common-helper.service';






@Component({
  selector: 'app-static-text',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 1fr 50px;
        width: 100%;
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    MatTooltipModule,
  ],
  templateUrl: './static-text.component.html',
  styleUrl: './static-text.component.scss',
})
export class StaticTextComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  products$: Observable<InventoryProduct[]>;

  brands: InventoryBrand[];
  categories: InventoryCategory[];
  filteredTags: InventoryTag[];
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: InventoryPagination;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: cmsContent | null = null;
  selectedProductForm: UntypedFormGroup;
  tags: InventoryTag[];
  tagsEditMode: boolean = false;
  vendors: InventoryVendor[];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  contentsArray: cmsContent[] = [];
  selectedContents: Map<number, boolean> = new Map(); // Tracks selected brands
  allSelected: boolean = false;

  searchQuery: string = '';
  searchSubject = new Subject<string>();
  searchSubscription: any;

  // Pagination properties
  pageIndex: number = 0;
  pageSize: number = 10;
  totalCount: number = 0;
  sortOrder: number = 1;
  sortColumn: number = 0;

  createContent = false;

  errorMessage: string = '';
  isDataLoaded: boolean = false;


  @ViewChild('headerPaginator') headerPaginator!: MatPaginator;
  @ViewChild('footerPaginator') footerPaginator!: MatPaginator;


  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _deleteConfirmationService: DeleteConfirmationService,
    private _formBuilder: UntypedFormBuilder,
    private _inventoryService: InventoryService,
    private apiService: ApiService,
    private toastr: ToastrService
  ) {}

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.selectedProductForm = this._formBuilder.group({
      id: [''],
      name: ['', [Validators.required]],
      title: [''],
      titleEng: [''],
      text: [''],
      textEng: ['']      
    });

    

    // Debounce search input to optimize API calls
    this.searchSubscription = this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe(query => {
        this.searchQuery = query;
        this.pageIndex = 0; // Reset to first page on new search
        this.footerPaginator.firstPage();
        this.getAllContents();
      });

  }



  // Toggle selection for a single brand
  toggleSelection(id: number) {
    if (this.selectedContents.has(id)) {
      this.selectedContents.delete(id); // Unselect
    } else {
      this.selectedContents.set(id, true); // Select
    }
    this.updateSelectAllState();
  }

  // Toggle Select All
  toggleSelectAll() {
    if (this.allSelected) {
      this.selectedContents.clear(); // Unselect all
    } else {
      this.contentsArray.forEach(brand => this.selectedContents.set(brand.id, true)); // Select all
    }
    this.allSelected = !this.allSelected;
  }

  // Update the "Select All" checkbox state
  updateSelectAllState() {
    this.allSelected = this.selectedContents.size === this.contentsArray.length;
  }

  //get selectedContents' Ids
  getSelectedContentIds(): number[] {
    return Array.from(this.selectedContents.entries()) // Convert Map to an array of key-value pairs
      .filter(([id, isSelected]) => isSelected) // Filter selected brands
      .map(([id]) => id); // Extract only the IDs
  }
  //Deletes the selected Brand entries by calling the API service. If the deletion is successful, it clears the selected Brands map.
  deleteContents(){
    this.apiService.deleteCMSContent(this.getSelectedContentIds()).subscribe((response)=>{
      if(response.requestResult == 1 ){
        this.selectedContents = new Map();
        this.getAllContents();
        this.showSuccess('delete');
      }else{
        this.errorMessage = response.responseTip;
        this.showError();
        this.selectedContents = new Map();
      }
    }, (error)=>{
      this.errorMessage = error.error.responseTip;
      this.showError();
      this.selectedContents = new Map();
    })
  }

  // get all brands
  getAllContents() {
    const params = {
      sortColumn: this.sortColumn,
      pageIndex: this.pageIndex,
      pageSize: this.pageSize,
      sortOrder: this.sortOrder,
      searchQuery: this.searchQuery
    }
    this.apiService.getCMSContent(params).subscribe((data) => {
      this.contentsArray = data.result.data;
      this.pageIndex = data.result.pageIndex;
      this.pageSize = data.result.pageSize;
      this.totalCount = data.result.count;
      this.isDataLoaded = true;
    });
  }

  // Triggers a search operation with the provided query string.
  onSearch(query: string): void {
    this.searchSubject.next(query);
  }

  // Handle pagination changes
  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.getAllContents();
  }

  toggleCreateContentForm() {
    this.createContent = !this.createContent;
    if (this.createContent) {
      const newProduct = {
        id: 0,
        name: '',
        title: '',
        titleEng: '',
        text: '',
        textEng: '',
      }
      // Go to new product
      this.selectedProduct = newProduct;

      // Fill the form
      this.selectedProductForm.patchValue(newProduct);

      // Mark for check
      this._changeDetectorRef.markForCheck();
    } else {
      this.selectedProductForm.reset();
    }
  }

  updateContent() {
    if(this.selectedProductForm.valid){
      const brand = this.selectedProductForm.getRawValue();
    const body = {
      "id": brand.id,
      "name": brand.name,
      "title": brand.title,
      "titleEng": brand.titleEng,
      "text": brand.text,
      "textEng": brand.textEng
    }
    this.apiService.updateCMSContent(body).subscribe((data) => {
      if(data.requestResult == 1){
        this.getAllContents();
        this.showSuccess('update');
        this.resetForm();
        this.closeDetails();
      }else{
        this.errorMessage = data.responseTip;
        this.showError();
    }},
  (error)=>{
    this.errorMessage = error.error.responseTip;
    this.showError();
  });
    }else{
      this.errorMessage = 'Please fill all the required fields.';
      this.selectedProductForm.markAllAsTouched();
      this.showError();
    }
  }

  showSuccess(type: string) {
    const message = type === 'update' ? 'Content updated successfully.': 'Content deleted successfully.';
    this.toastr.success(message, 'Success!');
  }
  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }


  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * After view init
   */
  ngAfterViewInit(): void {
    if (this._sort && this._paginator) {
      setTimeout(() => {
        // Set the initial sort
        this._sort.sort({
          id: 'id',
          start: 'asc',
          disableClear: true,
        });
      });


      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;
          this.pageIndex = 0;

          //reset and close the form if it is open
          this.resetForm();
          this.closeDetails();

          // set the sort column and sort order
          this.sortColumn = this._sort.active === 'name' ? 1 : 0;
          this.sortOrder = this._sort.direction === 'asc' ? 2 : 1;

          // Close the details
          this.closeDetails();
          //Get all the Contents
          this.getAllContents();
        });
    }
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
    if (this.searchSubscription) {
      this.searchSubscription.unsubscribe();
    }
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggle content details
   *
   * @param Id
   */
  toggleDetails(Id: number): void {
    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct.id === Id) {
      // Close the details
      this.closeDetails();
      return;
    }

    const myMap = new Map(this.contentsArray.map(obj => [obj.id, obj]));

    this.selectedProduct = myMap.get(Id);
    this.selectedProductForm.patchValue(this.selectedProduct);
  }

  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
    this.resetForm();
  }

   //reset the form
   resetForm() {
    CommonHelperService.preserveId(this.selectedProductForm);
  }

  /**
   * Cycle through images of selected product
   */
  cycleImages(forward: boolean = true): void {
    // Get the image count and current image index
    const count = this.selectedProductForm.get('images').value.length;
    const currentIndex =
      this.selectedProductForm.get('currentImageIndex').value;

    // Calculate the next and previous index
    const nextIndex = currentIndex + 1 === count ? 0 : currentIndex + 1;
    const prevIndex = currentIndex - 1 < 0 ? count - 1 : currentIndex - 1;

    // If cycling forward...
    if (forward) {
      this.selectedProductForm.get('currentImageIndex').setValue(nextIndex);
    }
    // If cycling backwards...
    else {
      this.selectedProductForm.get('currentImageIndex').setValue(prevIndex);
    }
  }

  /**
   * Toggle the tags edit mode
   */
  toggleTagsEditMode(): void {
    this.tagsEditMode = !this.tagsEditMode;
  }

  /**
   * Filter tags
   *
   * @param event
   */
  filterTags(event): void {
    // Get the value
    const value = event.target.value.toLowerCase();

    // Filter the tags
    this.filteredTags = this.tags.filter((tag) =>
      tag.title.toLowerCase().includes(value)
    );
  }

  /**
   * Filter tags input key down event
   *
   * @param event
   */
  // filterTagsInputKeyDown(event): void {
  //   // Return if the pressed key is not 'Enter'
  //   if (event.key !== 'Enter') {
  //     return;
  //   }

  //   // If there is no tag available...
  //   if (this.filteredTags.length === 0) {
  //     // Create the tag
  //     this.createTag(event.target.value);

  //     // Clear the input
  //     event.target.value = '';

  //     // Return
  //     return;
  //   }

  //   // If there is a tag...
  //   const tag = this.filteredTags[0];
  //   const isTagApplied = this.selectedProduct.tags.find((id) => id === tag.id);

  //   // If the found tag is already applied to the product...
  //   if (isTagApplied) {
  //     // Remove the tag from the product
  //     this.removeTagFromProduct(tag);
  //   } else {
  //     // Otherwise add the tag to the product
  //     this.addTagToProduct(tag);
  //   }
  // }

  /**
   * Create a new tag
   *
   * @param title
   */
  // createTag(title: string): void {
  //   const tag = {
  //     title,
  //   };

  //   // Create tag on the server
  //   this._inventoryService.createTag(tag).subscribe((response) => {
  //     // Add the tag to the product
  //     this.addTagToProduct(response);
  //   });
  // }

  /**
   * Update the tag title
   *
   * @param tag
   * @param event
   */
  // updateTagTitle(tag: InventoryTag, event): void {
  //   // Update the title on the tag
  //   tag.title = event.target.value;

  //   // Update the tag on the server
  //   this._inventoryService
  //     .updateTag(tag.id, tag)
  //     .pipe(debounceTime(300))
  //     .subscribe();

  //   // Mark for check
  //   this._changeDetectorRef.markForCheck();
  // }

  /**
   * Delete the tag
   *
   * @param tag
   */
  // deleteTag(tag: InventoryTag): void {
  //   // Delete the tag from the server
  //   this._inventoryService.deleteTag(tag.id).subscribe();

  //   // Mark for check
  //   this._changeDetectorRef.markForCheck();
  // }

  /**
   * Add tag to the product
   *
   * @param tag
   */
  // addTagToProduct(tag: InventoryTag): void {
  //   // Add the tag
  //   this.selectedProduct.tags.unshift(tag.id);

  //   // Update the selected product form
  //   this.selectedProductForm.get('tags').patchValue(this.selectedProduct.tags);

  //   // Mark for check
  //   this._changeDetectorRef.markForCheck();
  // }

  /**
   * Remove tag from the product
   *
   * @param tag
   */
  // removeTagFromProduct(tag: InventoryTag): void {
  //   // Remove the tag
  //   this.selectedProduct.tags.splice(
  //     this.selectedProduct.tags.findIndex((item) => item === tag.id),
  //     1
  //   );

  //   // Update the selected product form
  //   this.selectedProductForm.get('tags').patchValue(this.selectedProduct.tags);

  //   // Mark for check
  //   this._changeDetectorRef.markForCheck();
  // }

  /**
   * Toggle product tag
   *
   * @param tag
   * @param change
   */
  // toggleProductTag(tag: InventoryTag, change: MatCheckboxChange): void {
  //   if (change.checked) {
  //     this.addTagToProduct(tag);
  //   } else {
  //     this.removeTagFromProduct(tag);
  //   }
  // }

  /**
   * Should the create tag button be visible
   *
   * @param inputValue
   */
  shouldShowCreateTagButton(inputValue: string): boolean {
    return !!!(
      inputValue === '' ||
      this.tags.findIndex(
        (tag) => tag.title.toLowerCase() === inputValue.toLowerCase()
      ) > -1
    );
  }

  /**
   * Create product
   */
  // createProduct(): void {
  //   // Create the product
  //   this._inventoryService.createProduct().subscribe((newProduct) => {
  //     // Go to new product
  //     this.selectedProduct = newProduct;

  //     // Fill the form
  //     this.selectedProductForm.patchValue(newProduct);

  //     // Mark for check
  //     this._changeDetectorRef.markForCheck();
  //   });
  // }

  /**
   * Update the selected product using the form data
   */
  updateSelectedProduct(): void {
    // Get the product object
    const product = this.selectedProductForm.getRawValue();

    // Remove the currentImageIndex field
    delete product.currentImageIndex;

    // Update the product on the server
    this._inventoryService.updateProduct(product.id, product).subscribe(() => {
      // Show a success message
      this.showFlashMessage('success');
    });
  }

  /**
   * Delete the selected product using the form data
   */
  async deleteSelectedProduct(id: number | null, isFromDeleteBtn = false) {

    //Open the confirmation dialog
    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('CMS Content');

    //If the confirm button pressed...
    if (!confirmed) {
      return;
    }
    if (!isFromDeleteBtn) {

      this.selectedContents.clear();
      this.selectedContents.set(id, true)
    }

    this.deleteContents();

    this.closeDetails();

  }


  /**
   * Show flash message
   */
  showFlashMessage(type: 'success' | 'error'): void {
    // Show the message
    this.flashMessage = type;

    // Mark for check
    this._changeDetectorRef.markForCheck();

    // Hide it after 3 seconds
    setTimeout(() => {
      this.flashMessage = null;

      // Mark for check
      this._changeDetectorRef.markForCheck();
    }, 3000);
  }

  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }

  multiDeleteDisable = true;
  checkAll: boolean;
  toggleCheckAll() {
    this.multiDeleteDisable = !this.multiDeleteDisable;
    if (this.checkAll) {
      products.forEach((item) => {
        this.checkedItems.push(item.barcode);
      });
    } else {
      this.checkedItems = [];
    }
  }

  checkedItems = [];

  checked(barcode: string) {
    if (this.checkedItems.includes(barcode)) {
      let newArray = this.checkedItems.filter((item) => {
        item != barcode;
      });
      this.checkedItems = newArray;
    } else {
      this.checkedItems.push(barcode);
    }
    this._paginator.pageSize == this.checkedItems.length
      ? (this.checkAll = true)
      : (this.checkAll = false);
  }
}
