import { Routes } from "@angular/router";
import { TemplatesComponent } from "./templates.component";

export default[
    {
        path: '',
        component: TemplatesComponent
    }
] as Routes