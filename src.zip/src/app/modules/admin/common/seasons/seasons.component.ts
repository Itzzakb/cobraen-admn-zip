import { TextFieldModule } from '@angular/cdk/text-field';
import { NgClass } from '@angular/common';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {
    FormsModule,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatCheckboxModule, } from '@angular/material/checkbox';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatChipsModule } from '@angular/material/chips';
import { MatOptionModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { ColorPickerModule } from 'ngx-color-picker';
import { provideNativeDateAdapter } from '@angular/material/core';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { Season, SeasonOrganization } from 'app/shared/types/interfaces';
import { ErrorMesageService } from 'app/shared/services/error-message.service';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { CommonHelperService } from 'app/shared/services/common-helper.service';
@Component({
    selector: 'app-seasons',
    encapsulation: ViewEncapsulation.None,
    standalone: true,
    imports: [
        MatIconModule,
        FormsModule,
        MatFormFieldModule,
        NgClass,
        MatInputModule,
        TextFieldModule,
        ReactiveFormsModule,
        MatButtonToggleModule,
        MatButtonModule,
        MatSelectModule,
        MatOptionModule,
        MatChipsModule,
        MatDatepickerModule,
        ColorPickerModule,
        MatCheckboxModule,
    ],
    templateUrl: './seasons.component.html',
    styleUrl: './seasons.component.scss',
    providers: [provideNativeDateAdapter()],
})
export class SeasonsComponent implements OnInit {
    seasonForm: UntypedFormGroup;

    errorMessage: string = '';
    seasonOrganizations: SeasonOrganization[] = [];
    seasonDetails: Season = null;
    status: boolean = false;
    selectAll: boolean = false;
    activeOrganizationIds: number[] = [];
    inactiveOrganizationIds: number[] = [];

    /**
     * Constructor
     */
    constructor(
        private _formBuilder: UntypedFormBuilder,
        private apiService: ApiService,
        private toastr: ToastrService,
        private errorMessageService: ErrorMesageService,
        private _fuseConfirmationService: FuseConfirmationService
        
    ) { }

    ngOnInit() {
        // Create the selected product form
        this.seasonForm = this._formBuilder.group({
            id: [0],
            name: ['', [Validators.required]],
            euroConversion: ['', [Validators.required, Validators.pattern('^[0-9,.]+$')]],
            adminCostTill: ['', [Validators.required, Validators.pattern('^[0-9,.]+$')]],
            adminCost: ['', [Validators.required, Validators.pattern('^[0-9,.]+$')]],
            active: ['', [Validators.required]],
            lastDelayedDeliveryDate: ['', [Validators.required]],
        });



        //get current season and season details
        this.getCurrentSeason();
    }

    getCurrentSeason() {
        this.apiService.getCurrentSeason().subscribe((data) => {
            if (data.season) {
                this.getSeasonDetails(data.season.id);
            } else {
                this.errorMessage = 'Unable to fetch the current season data.';
                this.showError();
            }
        })
    }

    getSeasonDetails(seasonId: number) {
        this.apiService.getSeasonDetails(seasonId).subscribe((data) => {
            if (data.season) {
                this.seasonDetails = data.season;
                this.seasonOrganizations = this.seasonDetails.organizations;
                this.seasonForm.patchValue(this.seasonDetails);
                this.status = this.seasonDetails.active;
            } else {
                this.errorMessage = 'Unable to fetch season details.';
                this.showError();
            }
        })
    }

    showSuccess(type: string) {
        const message = type == 'update' ? 'Season updated successfully.' : 'Season reseted successfully.';
        this.toastr.success(message, 'Success!');
    }
    showError() {
        this.toastr.error(this.errorMessage, 'Error!');
    }

    toggleSelectAll() {
        this.seasonOrganizations.forEach(org => {
            org.active = this.selectAll
        });
    }

    separateActiveAndInactiveOrgIds() {
        this.seasonOrganizations.forEach(org => {
            org.active ?
                this.activeOrganizationIds.push(org.id) :
                this.inactiveOrganizationIds.push(org.id);
        })
    }

    updateSeason() {
        if (this.seasonForm.valid) {
            this.separateActiveAndInactiveOrgIds();
            if(this.activeOrganizationIds.length == 0){
                this.errorMessage = 'Atleast 1 organization should be selected.';
                this.showError();
                return;
            }
            const season = this.seasonForm.getRawValue();

            const body = {
                "name": season.name,
                "euroConversion": season.euroConversion,
                "adminCostTill": season.adminCostTill,
                "adminCost": season.adminCost,
                "lastDelayedDeliveryDate": CommonHelperService.GenerateDate(season.lastDelayedDeliveryDate),
                "activeOrganizationIds": this.activeOrganizationIds,
                "inactiveOrganizationIds": this.inactiveOrganizationIds,
                "id": season.id
            }

            this.apiService.updateSeason(body).subscribe((data) => {
                this.showSuccess('update');
            },
                (error) => {
                    this.errorMessage = 'Something went wrong!!! try again.';
                    this.showError();
                })
        } else {
            this.seasonForm.markAllAsTouched();
            this.errorMessage = 'Fill all the required fields.';
            this.showError();
        }
    }

    reseteSeason() {
        this.separateActiveAndInactiveOrgIds();
        const body = {
            "id": this.seasonDetails.id,
            "inactiveOrganizationIds": this.inactiveOrganizationIds
        }

        this.apiService.resetSeason(body).subscribe((data) => {
            this.showSuccess('reset');
        },
            (error) => {
                this.errorMessage = 'Something went wrong!!! try again.';
                this.showError();
            })
    }

    openResetConfirmDialog() {
        // Open the confirmation dialog
        const confirmation = this._fuseConfirmationService.open({
          title: 'Reset Season',
          message:
            'Are you sure you want to reset the season?',
          actions: {
            confirm: {
              label: 'Reset',
            },
          },
        });
    
        // Subscribe to the confirmation dialog closed action
        confirmation.afterClosed().subscribe((result) => {
          // If the confirm button pressed...
          if (result === 'confirmed') {
            this.reseteSeason();    
          }
        });
      }

}
