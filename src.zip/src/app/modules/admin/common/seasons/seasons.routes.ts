import { Routes } from '@angular/router';
import { SeasonsComponent } from './seasons.component';

export default [
    {
        path: '',
        component: SeasonsComponent,
    },
] as Routes;