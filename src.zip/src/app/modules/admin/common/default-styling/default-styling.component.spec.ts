import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DefaultStylingComponent } from './default-styling.component';

describe('DefaultStylingComponent', () => {
  let component: DefaultStylingComponent;
  let fixture: ComponentFixture<DefaultStylingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DefaultStylingComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DefaultStylingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
