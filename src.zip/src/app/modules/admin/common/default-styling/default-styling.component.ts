import { TextFieldModule } from '@angular/cdk/text-field';
import { NgClass } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  Validators,
} from '@angular/forms'; '@angular/material/checkbox';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatChipsModule } from '@angular/material/chips';
import { MatOptionModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { ColorPickerModule } from 'ngx-color-picker';
import { MatRadioModule } from '@angular/material/radio';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';
import { ImageLibraryComponent } from 'app/modules/image-library/image-library.component';
import { RouterOutlet } from '@angular/router';
import { ApiService } from '@fuse/services/api-service.service';
import { ImageLibraryDialog } from 'app/shared/components/image-library/image-library.component';
import { ImageLibraryContent } from 'app/shared/types/interfaces';

@Component({
  selector: 'app-default-styling',
  encapsulation: ViewEncapsulation.None,
  standalone: true,
  imports: [
    MatIconModule,
    FormsModule,
    MatFormFieldModule,
    NgClass,
    MatInputModule,
    TextFieldModule,
    ReactiveFormsModule,
    MatButtonToggleModule,
    MatButtonModule,
    MatSelectModule,
    MatOptionModule,
    MatChipsModule,
    MatDatepickerModule,
    ColorPickerModule,
    MatRadioModule,
    MatTooltipModule,
    RouterOutlet
  ],
  templateUrl: './default-styling.component.html',
  styleUrl: './default-styling.component.scss',
})
export class DefaultStylingComponent implements OnInit {

  @ViewChild('background_image', { static: false }) background_image!: ElementRef;
  @ViewChild('default_logo', { static: false }) default_logo!: ElementRef;
  @ViewChild('app_logo', { static: false }) app_logo!: ElementRef;
  @ViewChild('banner_image', { static: false }) banner_image!: ElementRef;



  id = '';
  sloganTextColor = '';
  filtersTextColor = '';
  headingColor = '';
  backgroundColor = '';
  bodyColor = '';
  moduleColor = '';
  textColor = '';
  menuTextColor = '';
  logoBackgroundColor = '';
  appMainColor = '';
  appSubColor = '';

  defaultLogo: string = '';
  defaultLogoFile: File | null = null;
  bannerImage: string = '';
  bannerImageFile: File | null = null;
  backgroundImage: string = '';
  backgroundImageFile: File | null = null;
  appLogo: string = '';
  appLogoFile: File | null = null;
  appQrCodeImage: string = '';
  appQrCodeImageFile: File | null = null;

  errorMessage: string = '';
  appQRCodeImageErrorMessage: string = '';
  appLogoErrorMessage: string = '';

  LibraryBackgroundImage: ImageLibraryContent = null;
  LibraryBannerImage: ImageLibraryContent = null;



  /**
   * Constructor
   */
  constructor(
    private _formBuilder: UntypedFormBuilder,
    private toastr: ToastrService,
    private _matDialog: MatDialog,
    private formBuilder: FormBuilder,
    private apiService: ApiService
  ) { }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Get the form field helpers as string
   */
  // getFormFieldHelpersAsString(): string {
  //   return this.formFieldHelpers.join(' ');
  // }

  ngOnInit(): void {
    this.getDefaultStyling();
  }


  defaultStyling = this.formBuilder.group(
    {
      id: [this.id],
      organizationId: [''],
      organizationName: [''],
      sloganText: [''],
      sloganTextColor: [this.sloganTextColor],
      filtersTextColor: [this.filtersTextColor],
      headingColor: [this.headingColor],
      headingTransparency: [''],
      backgroundColor: [this.backgroundColor],
      bodyColor: [this.bodyColor],
      bodyTransparency: [''],
      moduleColor: [this.moduleColor],
      moduleTransparency: [''],
      textColor: [this.textColor],
      menuTextColor: [this.menuTextColor],
      logoBackgroundColor: [this.logoBackgroundColor],
      appMainColor: [this.appMainColor, Validators.required],
      appSubColor: [this.appSubColor, Validators.required],
      shoppingCartIcon: ['']
    }
  )


  /**
   * Fetches the default styling configuration from the API and updates the component's state.
   * 
   * This method retrieves the default styling data, including various colors, images, and logos,
   * and applies them to the form and component properties. If the request is successful, the
   * styling data is patched to the form and assigned to corresponding variables. In case of an
   * error or unsuccessful request, an error message is displayed.
   * 
   * @remarks
   * - The method subscribes to the API service's `getDeafultStyling` method to fetch the data.
   * - Handles both success and error responses from the API.
   * 
   * @throws Will display an error message if the API request fails or returns an unsuccessful result.
   */
  getDefaultStyling() {
    this.apiService.getDeafultStyling().subscribe((data) => {
      if (data.requestResult == 1) {
        this.bindTheResponseData(data);
      } else {
        this.errorMessage = data.responseTip;
        this.showError();
      }
    }, (error) => {
      this.errorMessage = error.error.responseTip;
      this.showError();
    })
  }


  /**
   * Binds the response data to the component's properties and form controls.
   *
   * @param data - The response data object containing the result to be bound.
   */
  bindTheResponseData(data: any) {
    this.defaultStyling.patchValue(data.result);
    this.id = data.result.id;
    this.defaultLogo = data.result.defaultLogo;
    this.bannerImage = data.result.bannerImage;
    this.backgroundImage = data.result.backgroundImage;
    this.appLogo = data.result.appLogo;
    this.appQrCodeImage = data.result.appQrCodeImage;

    this.sloganTextColor = data.result.sloganTextColor;
    this.filtersTextColor = data.result.filtersTextColor;
    this.headingColor = data.result.headingColor;
    this.backgroundColor = data.result.backgroundColor;
    this.bodyColor = data.result.bodyColor;
    this.moduleColor = data.result.moduleColor;
    this.textColor = data.result.textColor;
    this.menuTextColor = data.result.menuTextColor;
    this.logoBackgroundColor = data.result.logoBackgroundColor;
    this.appMainColor = data.result.appMainColor;
    this.appSubColor = data.result.appSubColor;
  }


  /**
   * Validates the application logo input and sets an error message if the logo is missing.
   * 
   * This method checks whether the `appLogo` property is an empty string and whether 
   * the `appLogoFile` property is not provided. If both conditions are true, it sets 
   * the `appLogoErrorMessage` property to indicate that the app logo is required. 
   * Otherwise, it clears the error message.
   */
  checkAppLogo() {
    if (this.appLogo == '' && !this.appLogoFile) {
      this.appLogoErrorMessage = 'App logo is required';
    } else {
      this.appLogoErrorMessage = '';
    }
  }


  /**
   * Validates the presence of the app QR code image or its file.
   * 
   * - If both `appQrCodeImage` is an empty string and `appQrCodeImageFile` is falsy,
   *   sets an error message indicating that the app QR code image is required.
   * - Otherwise, clears the error message.
   * 
   * @returns {void} This method does not return a value.
   */
  checkAppQRCodeImage() {
    if (this.appQrCodeImage == '' && !this.appQrCodeImageFile) {
      this.appQRCodeImageErrorMessage = 'App QR code image is required';
    } else {
      this.appQRCodeImageErrorMessage = '';
    }
  }


  /**
   * Updates the default styling settings for the application.
   * 
   * This function validates the default styling form, checks for errors in the app logo 
   * and QR code image, and submits the styling data to the server if all validations pass.
   * It uses a `FormData` object to append the styling fields and files, ensuring that 
   * only non-null values are included. Upon successful submission, the response data is 
   * bound to the component, and a success message is displayed. If the submission fails, 
   * an error message is shown.
   * 
   * @remarks
   * - The function relies on several component properties such as `defaultStyling`, 
   *   `headingColor`, `backgroundColor`, and others to construct the form data.
   * - Error messages for the app logo and QR code image are checked before proceeding.
   * - If the form is invalid or errors are present, all form fields are marked as touched 
   *   to trigger validation messages.
   * 
   * @returns void
   */
  updateDefaultStyling() {
    this.checkAppLogo();
    this.checkAppQRCodeImage();
    this.defaultStyling.patchValue({ id: this.id });
    if ((this.defaultStyling.valid || this.checkRequiredFields()) && this.appLogoErrorMessage == '' && this.appQRCodeImageErrorMessage == '') {
      const defaultStylingForm = this.defaultStyling.getRawValue();
      var formData = new FormData();

      //append the form field if the value is not null
      const appendIfNotNull = (key: string, value: any) => {
        if (value !== null && value !== undefined) {
          formData.append(key, value);
        }
      };
      formData.append('Id', this.id);
      formData.append('OrganizationId', '');
      appendIfNotNull('OrganizationName', defaultStylingForm.organizationName);
      appendIfNotNull('HeadingColor', this.headingColor);
      appendIfNotNull('BackgroundColor', this.backgroundColor);
      appendIfNotNull('BodyColor', this.bodyColor);
      appendIfNotNull('ModuleColor', this.moduleColor);
      appendIfNotNull('TextColor', this.textColor);
      appendIfNotNull('MenuTextColor', this.menuTextColor);
      appendIfNotNull('HeadingTransparency', defaultStylingForm.headingTransparency);
      appendIfNotNull('BodyTransparency', defaultStylingForm.bodyTransparency);
      appendIfNotNull('ModuleTransparency', defaultStylingForm.moduleTransparency);
      appendIfNotNull('AppMainColor', this.appMainColor);
      appendIfNotNull('AppSubColor', this.appSubColor);
      appendIfNotNull('SloganText', defaultStylingForm.sloganText);
      appendIfNotNull('SloganTextColor', this.sloganTextColor);
      appendIfNotNull('FiltersTextColor', this.filtersTextColor);
      appendIfNotNull('ShoppingCartIcon', defaultStylingForm.shoppingCartIcon);
      appendIfNotNull('LogoBackgroundColor', this.logoBackgroundColor);
      formData.append('DefaultLogo', this.defaultLogoFile);
      formData.append('AppLogo', this.appLogoFile);
      formData.append('AppQrCodeImage', this.appQrCodeImageFile);
      if (!this.bannerImageFile && !this.LibraryBannerImage && this.bannerImage) {
        formData.append('ExistingBannerImage', this.bannerImage);
      }

      if (!this.backgroundImageFile && !this.LibraryBackgroundImage && this.backgroundImage) {
        formData.append('ExistingBackgroundImage', this.backgroundImage);
      }
      if(this.backgroundImageFile){
        formData.append('BackgroundImage', this.backgroundImageFile);
      }

      if(this.bannerImageFile){
        formData.append('BannerImage', this.bannerImageFile);  
      }

      if(!this.backgroundImageFile && this.LibraryBackgroundImage){
        formData.append('LibraryBackgroundImage.UrlPath', this.LibraryBackgroundImage.urlPath);
        formData.append('LibraryBackgroundImage.FileName', this.LibraryBackgroundImage.fileName);
      }

      if(!this.bannerImageFile && this.LibraryBannerImage){
        formData.append('LibraryBannerImage.UrlPath', this.LibraryBannerImage.urlPath);
        formData.append('LibraryBannerImage.FileName', this.LibraryBannerImage.fileName);
      }

      this.apiService.updateOrganizationBranding(formData).subscribe((data) => {
        if (data.requestResult == 1) {
          this.bindTheResponseData(data);
          this.showSuccess();
        } else {
          this.errorMessage = data.responseTip;
          this.showError();
        }
      },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        });
    } else {
      this.defaultStyling.markAllAsTouched();
      this.errorMessage = 'Please fill all the required fields';
      this.showError();
    }
  }

  checkRequiredFields() {
    return this.appMainColor !== null && this.appSubColor !== null && (this.defaultLogo !== null || this.defaultLogoFile !== null) &&
      (this.appLogo !== null || this.appLogoFile !== null) && (this.appQrCodeImage !== null || this.appQrCodeImageFile !== null);
  }

  showSuccess() {
    const message = 'Deafult styling updated successfully.';
    this.toastr.success(message, 'Success!');
  }


  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }
  uploadImage(fileList: FileList): void {
    // Return if canceled
    if (!fileList.length) {
      return;
    }

    const allowedTypes = ['image/jpeg', 'image/png'];
    const file = fileList[0];

    // Return if the file is not allowed
    if (!allowedTypes.includes(file.type)) {
      return;
    }
  }



  /**
   * Handles the file input change event, retrieves the selected file, and generates a preview URL.
   *
   * @param event - The event object triggered by the file input change.
   * @param name - A string representing the name associated with the file.
   */
  public GetFileOnLoad(event: any, name: string) {
    if (event.target.files && event.target.files[0]) {
      var file = event.target.files[0] as File;

      this.getImageFilePreview(name, URL.createObjectURL(file), file)

    }

  }



  /**
   * Updates the corresponding image property based on the provided name and image URL.
   * 
   * @param name - The name of the image type to update. Expected values are:
   *   - 'default logo'
   *   - 'banner image'
   *   - 'background image'
   *   - 'app logo'
   *   - 'app QR code image'
   * @param imageURL - The URL of the image to set for the specified image type.
   * 
   * Depending on the `name` parameter, this function assigns the `imageURL` to the 
   * appropriate property and may invoke additional checks for specific image types:
   * - For 'app logo', it calls `checkAppLogo()`.
   * - For 'app QR code image', it calls `checkAppQRCodeImage()`.
   */
  getImageFilePreview(name: string, imageURL: string, file: File) {
    switch (name) {
      case 'default logo':
        this.defaultLogo = imageURL;
        this.defaultLogoFile = file;
        break;
      case 'banner image':
        this.bannerImage = imageURL;
        this.bannerImageFile = file;
        break;
      case 'background image':
        this.backgroundImage = imageURL;
        this.backgroundImageFile = file;
        break;
      case 'app logo':
        this.appLogo = imageURL;
        this.appLogoFile = file;
        this.checkAppLogo();
        break;
      case 'app QR code image':
        this.appQrCodeImage = imageURL;
        this.appQrCodeImageFile = file;
        this.checkAppQRCodeImage();
        break;
    }
  }



  /**
   * Removes the specified image file and clears the associated input field.
   *
   * @param name - The name of the image file to remove. Expected values are 'banner image' or 'background image'.
   * @param inputBox - The ID of the input element associated with the image file.
   *
   * This function performs the following actions:
   * - Clears the corresponding image property (`bannerImage` or `backgroundImage`) based on the `name` parameter.
   * - Finds the input element by its ID (`inputBox`) and clears its value.
   * - Removes focus from the input element by calling `blur()` on it.
   *
   * If the input element is not found, no action is taken for that element.
   */
  removeImageFile(name: string, inputBox: string) {
    switch (name) {

      case 'banner image':
        this.bannerImage = '';
        this.bannerImageFile = null;
        var element = document.getElementById(inputBox) as HTMLInputElement | null;
        if (element != null) {
          element.value = '';
          element.blur();
        }
        this.LibraryBannerImage = null;
        break;
      case 'background image':
        this.backgroundImage = '';
        this.backgroundImageFile = null;
        var element = document.getElementById(inputBox) as HTMLInputElement | null;
        if (element != null) {
          element.value = '';
          element.blur();
        }
        this.LibraryBackgroundImage = null;
        break;
    }
  }



  /**
   * Updates the color property of the component based on the provided name.
   *
   * @param color - The new color value to be applied.
   * @param name - The name of the property to update. 
   *               Accepted values include:
   *               - 'slogan text color'
   *               - 'filters text color'
   *               - 'heading color'
   *               - 'background color'
   *               - 'body color'
   *               - 'module color'
   *               - 'text color'
   *               - 'menu text color'
   *               - 'logo background color'
   *               - 'app main color'
   *               - 'app sub color'
   */
  changeColor(color: string, name: string) {
    switch (name) {
      case 'slogan text color':
        this.sloganTextColor = color;
        break;
      case 'filters text color':
        this.filtersTextColor = color;
        break;
      case 'heading color':
        this.headingColor = color;
        break;
      case 'background color':
        this.backgroundColor = color;
        break;
      case 'body color':
        this.bodyColor = color;
        break;
      case 'module color':
        this.moduleColor = color;
        break;
      case 'text color':
        this.textColor = color;
        break;
      case 'menu text color':
        this.menuTextColor = color;
        break;
      case 'logo background color':
        this.logoBackgroundColor = color;
        break;
      case 'app main color':
        this.appMainColor = color;
        break;
      case 'app sub color':
        this.appSubColor = color;
        break;
    }
  }


  // openImageLibrary(): void {
  //   this._matDialog.open(ImageLibraryComponent, { autoFocus: false });
  // }


  //reset the default styling form
  resetDeafultStyling() {
    this.defaultStyling.reset({
      id: this.id,
      appMainColor: '',
      appSubColor: '',
    });
    this.sloganTextColor = '';
    this.filtersTextColor = '';
    this.headingColor = '';
    this.backgroundColor = '';
    this.bodyColor = '';
    this.moduleColor = '';
    this.textColor = '';
    this.menuTextColor = '';
    this.logoBackgroundColor = '';
    this.appMainColor = '';
    this.appSubColor = '';

    this.defaultLogo = '';
    this.defaultLogoFile = null;
    this.bannerImage = '';
    this.bannerImageFile = null;
    this.backgroundImage = '';
    this.backgroundImageFile = null;
    this.appLogo = '';
    this.appLogoFile = null;
    this.appQrCodeImage = '';
    this.appQrCodeImageFile = null;

    this.appQRCodeImageErrorMessage = '';
    this.appLogoErrorMessage = '';
  }

  openImageLibrary(type: string) {
    const dialogRef = this._matDialog.open(ImageLibraryDialog);

    dialogRef.afterClosed().subscribe(result => {
      if (type == 'bannerImage') {
        this.LibraryBannerImage = result;
        this.bannerImage = this.LibraryBannerImage.urlPath + this.LibraryBannerImage.fileName;
      } else if (type == 'backgroundImage') {
        this.LibraryBackgroundImage = result;
        this.backgroundImage = this.LibraryBackgroundImage.urlPath + this.LibraryBackgroundImage.fileName;
      }
    });
  }
}
