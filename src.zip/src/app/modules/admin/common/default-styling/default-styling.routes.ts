import { Routes } from '@angular/router';
import { DefaultStylingComponent } from './default-styling.component';

export default [
    {
        path: '',
        component: DefaultStylingComponent,
    },
] as Routes;