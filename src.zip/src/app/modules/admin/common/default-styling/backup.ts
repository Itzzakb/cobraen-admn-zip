import { TextFieldModule } from '@angular/cdk/text-field';
import { NgClass } from '@angular/common';
import { Component, ElementRef, ViewChild, ViewEncapsulation } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  Validators,
} from '@angular/forms'; '@angular/material/checkbox';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatChipsModule } from '@angular/material/chips';
import { MatOptionModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { ColorPickerModule } from 'ngx-color-picker';
import { MatRadioModule } from '@angular/material/radio';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';
import { ImageLibraryComponent } from 'app/modules/image-library/image-library.component';
import { HotToastService } from '@ngneat/hot-toast';
import Swal from 'sweetalert2';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-default-styling',
  encapsulation: ViewEncapsulation.None,
  standalone: true,
  imports: [
    MatIconModule,
    FormsModule,
    MatFormFieldModule,
    NgClass,
    MatInputModule,
    TextFieldModule,
    ReactiveFormsModule,
    MatButtonToggleModule,
    MatButtonModule,
    MatSelectModule,
    MatOptionModule,
    MatChipsModule,
    MatDatepickerModule,
    ColorPickerModule,
    MatRadioModule,
    MatTooltipModule,
    RouterOutlet
  ],
  templateUrl: './default-styling.component.html',
  styleUrl: './default-styling.component.scss',
})
export class DefaultStylingComponent {

  // defaultLogoImage = false;
  // defaultLogoImageFile: File;
  // formFieldHelpers: string[] = [''];
  // fixedSubscriptInput: FormControl = new FormControl('', [
  //   Validators.required,
  // ]);
  // dynamicSubscriptInput: FormControl = new FormControl('', [
  //   Validators.required,
  // ]);
  // fixedSubscriptInputWithHint: FormControl = new FormControl('', [
  //   Validators.required,
  // ]);
  // dynamicSubscriptInputWithHint: FormControl = new FormControl('', [
  //   Validators.required,
  // ]);

  // defaultStyling: FormGroup;

  /**
   * Constructor
   */
  constructor(
    private _formBuilder: UntypedFormBuilder,
    private toastr: ToastrService,
    private _matDialog: MatDialog,
    private formBuilder: FormBuilder,
    private toast: HotToastService
  ) { }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Get the form field helpers as string
   */
  // getFormFieldHelpersAsString(): string {
  //   return this.formFieldHelpers.join(' ');
  // }

  @ViewChild('background_image', { static: false }) background_image!: ElementRef;
  @ViewChild('default_logo', { static: false }) default_logo!: ElementRef;
  @ViewChild('app_logo', { static: false }) app_logo!: ElementRef;
  @ViewChild('banner_image', { static: false }) banner_image!: ElementRef;




  sloganTextColor = '#ed2727';
  filtersTextColor = '#329f32';
  headingColor = '#3838d0';
  backgroundColor = '#456aeb';
  bodyColor = '#edc786';
  moduleColor = '#acbdef';
  textColor = '#343434';
  menuTextColor = '#121234';
  logoBackgroundColor = '#900089';
  appMainColor = '#c5c5c5';
  appSubColor = '#e4f6a3';

  defaultStyling = this.formBuilder.group(
    {
      slogan_text: [''],
      slogan_text_color: [this.sloganTextColor],
      filters_text_color: [this.filtersTextColor],
      heading_color: [this.headingColor],
      heading_transparancy: [''],
      background_color: [this.backgroundColor],
      body_color: [this.bodyColor],
      body_transparancy: [''],
      module_color: [this.moduleColor],
      module_transparancy: [''],
      text_color: [this.textColor],
      menu_text_color: [this.menuTextColor],
      logo_background_color: [this.logoBackgroundColor],
      app_main_color: [this.appMainColor, Validators.required],
      app_sub_color: [this.appSubColor, Validators.required],
    }
  )
  uploadImage(fileList: FileList): void {
    // Return if canceled
    if (!fileList.length) {
      return;
    }

    const allowedTypes = ['image/jpeg', 'image/png'];
    const file = fileList[0];

    // Return if the file is not allowed
    if (!allowedTypes.includes(file.type)) {
      return;
    }
  }

  public GetFileOnLoad(event: any, name: string) {
    if (event.target.files && event.target.files[0]) {
      var file = event.target.files[0] as File;

        this.getImageFilePreview(name, URL.createObjectURL(file))

    }

  }

  defaultLogo = '';
  bannerImage = '';
  backgroundImage = '';
  appLogo = '';
  appQrCodeImage = '';

  getImageFilePreview(name: string, imageURL: string) {
    switch (name) {
      case 'default logo':
        this.defaultLogo = imageURL;
        break;
      case 'banner image':
        this.bannerImage = imageURL;
        break;
      case 'background image':
        this.backgroundImage = imageURL;
        break;
      case 'app logo':
        this.appLogo = imageURL;
        break;
      case 'app QR code image':
        this.appQrCodeImage = imageURL;
        break;
    }
  }

  removeImageFile(name: string, inputBox: string) {
    switch (name) {

      case 'banner image':
        this.bannerImage = '';
        var element = document.getElementById(inputBox) as HTMLInputElement | null;
        if (element != null) {
          element.value = '';
          element.blur();
        }
        break;
      case 'background image':
        this.backgroundImage = '';
        var element = document.getElementById(inputBox) as HTMLInputElement | null;
        if (element != null) {
          element.value = '';
          element.blur();
        }
        break;
    }
  }



  changeColor(color: string, name: string) {
    switch (name) {
      case 'slogan text color':
        this.sloganTextColor = color;
        break;
      case 'filters text color':
        this.filtersTextColor = color;
        break;
      case 'heading color':
        this.headingColor = color;
        break;
      case 'background color':
        this.backgroundColor = color;
        break;
      case 'body color':
        this.bodyColor = color;
        break;
      case 'module color':
        this.moduleColor = color;
        break;
      case 'text color':
        this.textColor = color;
        break;
      case 'menu text color':
        this.menuTextColor = color;
        break;
      case 'logo background color':
        this.logoBackgroundColor = color;
        break;
      case 'app main color':
        this.appMainColor = color;
        break;
      case 'app sub color':
        this.appSubColor = color;
        break;
    }
  }

  showSuccess() {
    // this.toastr.success('All your data saved successfully.', 'Error!');
    Swal.fire('Success!', 'All your data saved successfully.', 'success');
  }
  showError() {
    this.toastr.error('Plese fill all the mandatory fields.', 'Error!');
    // Swal.fire('Error!', 'Please fill all the required fields.', 'error');
  }

  openImageLibrary(): void {
    this._matDialog.open(ImageLibraryComponent, { autoFocus: false });
  }

  resetDeafultStyling() {
    this.defaultStyling.reset();
    this.defaultLogo = '';
    this.bannerImage = '';
    this.backgroundImage = '';
    this.appLogo = '';
    this.appQrCodeImage = '';

    this.sloganTextColor = '';
    this.filtersTextColor = '';
    this.headingColor = '';
    this.backgroundColor = '';
    this.bodyColor = '';
    this.moduleColor = '';
    this.textColor = '';
    this.menuTextColor = '';
    this.logoBackgroundColor = '';
    this.appMainColor = '';
    this.appSubColor = '';
  }
  defaultStylingSave() {
    // //console.log((this.defaultStyling.invalid);
    if(this.defaultStyling.invalid){
      this.showError();
    }else{
      this.showSuccess();
    }
  }



}
