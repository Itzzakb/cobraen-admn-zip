import { Routes } from "@angular/router";
import { GiftsetComponent } from "./giftset.component";

export default [
    {
        path: '',
        component: GiftsetComponent
    }
] as Routes