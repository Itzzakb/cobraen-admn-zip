import {
  AsyncPipe,
  CommonModule,
  CurrencyPipe,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormControl,
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelect, MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatRadioModule } from '@angular/material/radio';
import { MatTooltipModule } from '@angular/material/tooltip';

import {
  InventoryBrand,
  InventoryCategory,
  InventoryPagination,
  InventoryProduct,
  InventoryTag,
  InventoryVendor,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  takeUntil,
} from 'rxjs';
import { CommonDropdownItem, GiftSet, GiftsetImage, Image, ImageLibraryContent, MappedProduct, MappedProductList, Product, productImage, productList, ProductPageDropdownList, ProductsWithCategories } from 'app/shared/types/interfaces';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { SearchableDropdownComponent } from 'app/shared/components/searchable-dropdown/searchable-dropdown.component';
import { ImageLibraryDialog } from 'app/shared/components/image-library/image-library.component';
import { MatDialog } from '@angular/material/dialog';
import { DeleteConfirmationService, DeleteTypes } from 'app/shared/services/delete-confirmation.service';


@Component({
  selector: 'app-giftset',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 80px 120px 1fr 136px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 80px 120px 1fr 136px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 80px 120px 1fr 136px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 80px 120px 1fr 136px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    MatRadioModule,
    MatTooltipModule,
    CommonModule,
    SearchableDropdownComponent
  ],
  templateUrl: './giftset.component.html',
  styleUrl: './giftset.component.scss',
})
export class GiftsetComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  products$: Observable<InventoryProduct[]>;

  brands: InventoryBrand[];
  categories: InventoryCategory[];
  filteredTags: InventoryTag[];
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: InventoryPagination;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: GiftSet | null = null;
  selectedProductForm: UntypedFormGroup;
  tags: InventoryTag[];
  tagsEditMode: boolean = false;
  vendors: InventoryVendor[];
  private _unsubscribeAll: Subject<any> = new Subject<any>();


  giftsetsArray: GiftSet[] = [];
  selectedGiftsets: Map<number, boolean> = new Map(); // Tracks selected giftsets
  allSelected: boolean = false;

  searchQuery: string = '';
  searchSubject = new Subject<string>();
  searchSubscription: any;

  videoUrl: string = '';

  // Pagination properties
  pageIndex: number = 0;
  pageSize: number = 10;
  totalCount: number = 0;
  sortOrder: number = 1;
  sortColumn: number = 0;

  createGiftset = false;

  indexImg: string = '';
  detailImg: string = '';
  indexImgFile: File | null = null;
  detailImgFile: File | null = null;

  errorMessage = '';
  showMappedProductsError: boolean = false;

  categoriesList: CommonDropdownItem[] = [];

  productList: productList[] = [];

  partnersList: CommonDropdownItem[] = [];

  selectedCategory: number | null = null;
  selectedStatus: number | null = null;


  productImages: productImage[] = [];
  existingImages: Image[] = [];
  LibraryImages: GiftsetImage[] = null;
  selectedThumbnailIndex: number = -1;

  videos: string[] = [];
  images: GiftsetImage[] = [];
  mappedProducts: number[] = [];
  selectedMappedProducts: MappedProduct[] = [];
  mappedProductsWithError: MappedProduct[] = [];

  totalExcGiftsetPrice: number = 0;
  totalIncGiftsetPrice: number = 0;

  inlineEditData: string | number = '';
  isInlineEdit: boolean = false;
  editField: string = '';
  selectedProductId: number | null = null;
  isDataLoaded: boolean = false;
  productsWithCategories: ProductsWithCategories[] = [];

  isPartnersSelected: boolean = false;
  isCategoriesSelected: boolean = false;

  @ViewChild('headerPaginator') headerPaginator!: MatPaginator;
  @ViewChild('footerPaginator') footerPaginator!: MatPaginator;
  @ViewChild('mappedProductsSelect') mappedProductsSelect!: MatSelect;
  mappedProductInput = new FormControl('', [Validators.required]);

  mappedProductsInput = new FormControl([], [Validators.required]);
  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _deleteConfirmationService: DeleteConfirmationService,
    private _formBuilder: UntypedFormBuilder,
    private apiService: ApiService,
    private toastr: ToastrService,
    private dialog: MatDialog
  ) { }

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.selectedProductForm = this._formBuilder.group({
      id: [''],
      importId: ['', [Validators.required]],
      published: [false],
      title: ['', [Validators.required]],
      titleEng: ['', [Validators.required]],
      longDesc: [''],
      longDescEng: [''],
      addtionalText: [''],
      categories: [[], [Validators.required]],
      mappedProducts: [[]],
      giftSetExcPrice: [''],
      giftSetIncPrice: [''],
      videos: [[]],
      images: [[]],
      partnerId: ['', [Validators.required]]
    });


    // get all shop partners list
    this.getShopPartnerList();

    // Debounce search input to optimize API calls
    this.searchSubscription = this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe(query => {
        this.searchQuery = query;
        this.pageIndex = 0; // Reset to first page on new search
        this.footerPaginator.firstPage();
        this.getAllGiftsets();
      });
  }


  // Toggle selection for a single brand
  toggleSelection(brandId: number) {
    if (this.selectedGiftsets.has(brandId)) {
      this.selectedGiftsets.delete(brandId); // Unselect
    } else {
      this.selectedGiftsets.set(brandId, true); // Select
    }
    this.updateSelectAllState();
  }

  // Toggle Select All
  toggleSelectAll() {
    if (this.allSelected) {
      this.selectedGiftsets.clear(); // Unselect all
    } else {
      this.giftsetsArray.forEach(brand => this.selectedGiftsets.set(brand.id, true)); // Select all
    }
    this.allSelected = !this.allSelected;
  }

  // Update the "Select All" checkbox state
  updateSelectAllState() {
    this.allSelected = this.selectedGiftsets.size === this.giftsetsArray.length;
  }

  toggleInlineEdit(id: number, field: string) {

    this.editField = field;
    this.selectedProductId = id;
    this.isInlineEdit = true;
    this.toggleDetails(id);
    this.inlineEditData = this.selectedProduct[field];
  }

  resetInlineEdit() {
    this.editField = '';
    this.selectedProductId = null;
    this.inlineEditData = '';
    this.isInlineEdit = false;
  }



  editInlineData(field: string) {
    this.selectedProductForm.patchValue({
      [field]: this.inlineEditData,
    });
    this.updateGiftset();
  }

  //get selected Giftsets' Ids
  getSelectedGiftsetIds(): number[] {
    return Array.from(this.selectedGiftsets.entries()) // Convert Map to an array of key-value pairs
      .filter(([id, isSelected]) => isSelected) // Filter selected brands
      .map(([id]) => id); // Extract only the IDs
  }
  //Deletes the selected Brand entries by calling the API service. If the deletion is successful, it clears the selected Brands map.
  deleteGiftset() {
    this.apiService.deleteGiftSet(this.getSelectedGiftsetIds()).subscribe((response) => {
      if (response.requestResult == 1) {
        this.selectedGiftsets = new Map();
        this.getAllGiftsets();
        this.showSuccess('delete');
      } else {
        this.errorMessage = response.responseTip;
        this.showError();
      }
    }, (error) => {
      this.errorMessage = error.error.responseTip;
      this.showError();
    })
  }

  // getDropdownList() {
  //   this.apiService.getAllCategories().subscribe((data) => {
  //     this.categoriesList = data.result;
  //   },
  //     (error) => {
  //       this.errorMessage = 'Unable to fetch dropdown data';
  //       this.showError();
  //     })
  // }

  getShopPartnerList() {
    this.apiService.getAllDropdownData(this.apiService.dropdownType.PARTNER).subscribe(
      (data) => {
        //To bind partner shopname for partners instead of name
        this.partnersList = data.result.partners?.data.map((x) => { return { id: x.id, name: x.shopName ?? x.name } }) || [];
      },
      (error) => {
        this.errorMessage = 'Unable to fetch dropdown data';
        this.showError();
      }
    );
  }

  getPartnerProductsAndCategories(id: number) {
    this.selectedProductForm.get('categories').patchValue(null);
    this.isPartnersSelected = false;
    this.isCategoriesSelected = false;
    this.mappedProducts = null;
    this.selectedMappedProducts = null;
    this.productsWithCategories = [];
    if (id) {

      this.apiService.getPartnerProductsAndCategories(id).subscribe((data) => {
        this.categoriesList = data.result.allCategories;
        this.productsWithCategories = data.result.productsWithCategories;

        this.isPartnersSelected = this.categoriesList?.length > 0;

      },
        (error) => {
          this.errorMessage = 'Unable to fetch products data';
          this.showError();
        })
    } else {
      this.isPartnersSelected = false;
    }
  }


  getProductsAccordingToCategoriesSelection(categoryIds: number[]) {
    this.isCategoriesSelected = false;
    this.productList = [];
    if (categoryIds && categoryIds.length > 0) {
      let products = this.productsWithCategories
        .filter(product =>
          product.categories.some(category => categoryIds.includes(category.id))
        );

      products.forEach((product) => {
        this.productList.push({
          id: product.productId,
          name: product.productName,
          dukatenExclusive: product.dukatenExclusive,
          dukatenInclusive: product.dukatenInclusive
        })
      });
      setTimeout(()=>{
        this.isCategoriesSelected = this.productList?.length > 0;
      }, 1000)
    } else {
      this.isCategoriesSelected = false;
    }
  }

  // get all brands
  getAllGiftsets() {
    const params = {
      sortColumn: this.sortColumn,
      pageIndex: this.pageIndex,
      pageSize: this.pageSize,
      sortOrder: this.sortOrder,
      searchQuery: this.searchQuery,
      categoryId: this.selectedCategory,
      status: this.selectedStatus,
    }
    this.apiService.getGiftsets(params).subscribe((data) => {
      this.giftsetsArray = data.result.data;
      this.pageIndex = data.result.pageIndex;
      this.pageSize = data.result.pageSize;
      this.totalCount = data.result.count;
      this.isDataLoaded = true;
    });
  }


  //Update Product Status
  updateStatus(id: number) {
    const formData = new FormData();
    formData.append('giftSetId', id.toString());

    this.apiService.updateGiftSetStatus(formData).subscribe((data) => {
      if (data.requestResult == 1) {
        this.showSuccess('statusUpdate');
        this.getAllGiftsets();
      } else {
        this.errorMessage = data.responseTip;
        this.showError();
      }
    },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      })
  }


  getImageFileName(filePath: string | File): string {

    if (filePath instanceof File) {
      return filePath.name; // Return the file name directly if it's a File object
    } else {
      return filePath;
    }
  }

  getMappedProducts(ids: number[]) {
    // Clear the current selectedMappedProducts array
    this.selectedMappedProducts = [];
    // Clear the mappedProducts array
    this.mappedProducts = [...ids];
    
    // Add only the newly selected products
    this.productList.forEach(product => {
      if (ids.includes(product.id)) {
        this.selectedMappedProducts.push({
          productId: product.id,
          productName: product.name,
          inclusivePrice: product.dukatenInclusive,
          exclusivePrice: product.dukatenExclusive,
          inclusiveGiftSetPrice: product.dukatenInclusive,
          exclusiveGiftSetPrice: product.dukatenExclusive,
          quantity: 1
        });
      }
    });

    this.updateTotalGiftPrice();
    this.checkMappedProductsValidation();
  }

  removeFromMappedProductLIst(id: number) {
    this.selectedMappedProducts = this.selectedMappedProducts.filter(product => product.productId != id);
    this.mappedProducts = this.mappedProducts.filter(product => product != id);
    this.updateTotalGiftPrice();
    this.checkMappedProductsValidation();
  }

  removeAllMappedProducts() {
    this.selectedMappedProducts = [];
    this.mappedProducts = [];

    //make total giftset prices 0
    this.totalExcGiftsetPrice = 0;
    this.totalIncGiftsetPrice = 0;

    this.checkMappedProductsValidation();
  }

  updateTotalGiftPrice() {
    this.totalExcGiftsetPrice = 0;
    this.totalIncGiftsetPrice = 0;

    this.selectedMappedProducts.forEach(product => {
      this.totalExcGiftsetPrice += product.exclusiveGiftSetPrice*product.quantity;
      this.totalIncGiftsetPrice += product.inclusiveGiftSetPrice*product.quantity
    })
  }


  showSuccess(type: string) {
    const message = this.getSuccessMessage(type);
    this.toastr.success(message, 'Success!');
  }
  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }

  //get success message based on type
  getSuccessMessage(type: string) {
    switch (type) {
      case 'create':
        return 'Product created successfully.';
        break;
      case 'update':
        return 'Product updated successfully.';
        break;
      case 'delete':
        return 'Product deleted successfully.';
        break;
      case 'statusUpdate':
        return 'Product status updated successfully.'
        break;
    }
  }

  // Triggers a search operation with the provided query string.
  onSearch(query: string): void {
    this.createGiftset = false;
    this.closeDetails();
    this.searchSubject.next(query);
  }

  // Handle pagination changes
  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.getAllGiftsets();
  }

  toggleCreateGiftsetForm() {
    //close the edit form if open
    this.closeDetails();

    this.createGiftset = !this.createGiftset;
    if (this.createGiftset) {
      // Reset mapped products arrays
      this.mappedProducts = [];
      this.selectedMappedProducts = [];

      // Reset images and videos arrays
      this.images = [];
      this.videos = [];

      // Reset validation error flags
      this.showMappedProductsError = false;

      const newProduct = {
        id: null,
        importId: '',
        published: false,
        title: '',
        titleEng: '',
        longDesc: '',
        longDescEng: '',
        addtionalText: '',
        categories: null,
        mappedProducts: null,
        giftSetIncPrice: null,
        giftSetExcPrice: null,
        videos: null,
        images: null,
        partnerId: null
      }
      // Go to new product
      this.selectedProduct = newProduct;

      // Fill the form with empty values
      this.selectedProductForm.reset();
      this.selectedProductForm.patchValue(newProduct);

      // Reset prices
      this.totalExcGiftsetPrice = 0;
      this.totalIncGiftsetPrice = 0;

      // Mark for check
      this._changeDetectorRef.markForCheck();
    } else {
      this.selectedProductForm.reset();
    }
  }

  checkMappedProductsValidation() {
    debugger;
    if (this.selectedMappedProducts?.length == 0) {
      this.showMappedProductsError = true;
    } else {
      this.showMappedProductsError = false;
    }
  }

  checkTheMappedProductsError(){
    this.selectedMappedProducts?.forEach((mp) => {
      if (!mp.quantity || mp.quantity <= 0) {
      if (!this.mappedProductsWithError.includes(mp)) {
        this.mappedProductsWithError.push(mp);
      }
      }
    });
  }

  addGiftset() {
    this.checkMappedProductsValidation();
    this.checkTheMappedProductsError();

    if (this.mappedProductsWithError.length > 0) {
      this.errorMessage = 'Please check the quantities for the Selected mapped products.';
      this.showError();
      return;
    }

    if (this.selectedProductForm.valid && !this.showMappedProductsError) {
      this.separateImagesAccordingToTypes();
      const product = this.selectedProductForm.getRawValue();
      var formData = new FormData();
      formData.append('Published', product.published);
      formData.append('Title', product.title);
      formData.append('TitleEng', product.titleEng);
      formData.append('LongDesc', product.longDesc);
      formData.append('LongDescEng', product.longDescEng);
      formData.append('AdditionalText', product.addtionalText);
      formData.append('ProductVideos', JSON.stringify(this.videos));
      formData.append('PartnerId', product.partnerId);

      if (this.productImages.length > 0) {
        this.productImages.forEach((image: productImage, i: number) => {
          formData.append(`ProductImages[${i}].Image`, image.Image, image.Image.name);
          formData.append(`ProductImages[${i}].Thumbnail`, image.Thumbnail.toString());
        });
      }

      if (this.LibraryImages.length > 0) {
        this.LibraryImages.forEach((image: GiftsetImage, i: number) => {
          formData.append(`LibraryImages[${i}].UrlPath`, image.imageUrl);
          formData.append(`LibraryImages[${i}].FileName`, image.fileName);
          formData.append(`LibraryImages[${i}].Thumbnail`, image.thumbnail.toString());
        });
      }

      if (this.selectedMappedProducts && this.selectedMappedProducts.length > 0) {
        this.selectedMappedProducts.forEach((mp: MappedProduct, i: number) => {
          formData.append(`MappedProducts[${i}].ProductId`, mp.productId.toString());
          formData.append(`MappedProducts[${i}].ExclusiveGiftSetPrice`, mp.exclusiveGiftSetPrice.toString());
          formData.append(`MappedProducts[${i}].InclusiveGiftSetPrice`, mp.inclusiveGiftSetPrice.toString());
          formData.append(`MappedProducts[${i}].Quantity`, mp.quantity.toString());
        });
      }

      if (product.categories && product.categories.length > 0) {
        product.categories.forEach((category: number) => {
          formData.append('Categories', category.toString());
        });
      }

      this.apiService.createGiftset(formData).subscribe(
        (data) => {
          if (data.requestResult == 1) {
            this.getAllGiftsets();
            this.resetForm();
            this.closeDetails();
            this.createGiftset = false;
            this.showSuccess('create');
          } else {
            this.errorMessage = data.responseTip;
            this.showError();
          }
        },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        }
      );
    } else {
      this.selectedProductForm.markAllAsTouched();
      this.errorMessage = 'Please fill all required fields.';
      this.showError();
    }
  }


  updateGiftset() {
    this.checkMappedProductsValidation();
    this.checkTheMappedProductsError();

    if (this.mappedProductsWithError.length > 0) {
      this.errorMessage = 'Please check the quantities for the Selected mapped products.';
      this.showError();
      return;
    }
    if (this.selectedProductForm.valid && !this.showMappedProductsError) {
      this.separateImagesAccordingToTypes();
      const product = this.selectedProductForm.getRawValue();
      var formData = new FormData();
      formData.append('Id', product.id);
      formData.append('Published', product.published);
      formData.append('Title', product.title);
      formData.append('TitleEng', product.titleEng);
      formData.append('LongDesc', product.longDesc);
      formData.append('LongDescEng', product.longDescEng);
      formData.append('AddtionalText', product.addtionalText);
      formData.append('ProductVideos', JSON.stringify(this.videos));
      formData.append('PartnerId', product.partnerId);


      if (this.selectedMappedProducts && this.selectedMappedProducts.length > 0) {
        this.selectedMappedProducts.forEach((mp: MappedProduct, i: number) => {
          formData.append(`MappedProducts[${i}].ProductId`, mp.productId.toString());
          formData.append(`MappedProducts[${i}].ExclusiveGiftSetPrice`, mp.exclusiveGiftSetPrice.toString());
          formData.append(`MappedProducts[${i}].InclusiveGiftSetPrice`, mp.inclusiveGiftSetPrice.toString());
          formData.append(`MappedProducts[${i}].Quantity`, mp.quantity.toString());
        });
      }

      if (this.productImages.length > 0) {
        this.productImages.forEach((image: productImage, i: number) => {
          formData.append(`ProductImages[${i}].Image`, image.Image);
          formData.append(`ProductImages[${i}].Thumbnail`, image.Thumbnail.toString());
        }
        );
      }
      if (this.existingImages.length > 0) {
        this.existingImages.forEach((image: Image, i: number) => {
          formData.append(`ExistingImages[${i}].FileName`, image.fileName.toString());
          formData.append(`ExistingImages[${i}].Thumbnail`, image.thumbnail.toString());
          formData.append(`ExistingImages[${i}].ImageUrl`, image.imageUrl.toString());
        }
        );
      }

      if (this.LibraryImages.length > 0) {
        this.LibraryImages.forEach((image: GiftsetImage, i: number) => {
          formData.append(`LibraryImages[${i}].UrlPath`, image.imageUrl);
          formData.append(`LibraryImages[${i}].FileName`, image.fileName);
          formData.append(`LibraryImages[${i}].Thumbnail`, image.thumbnail.toString());
        }
        );
      }

      if (product.categories && product.categories.length > 0) {
        product.categories.forEach((category: number) => {
          formData.append('Categories', category.toString());
        });
      }

      this.apiService.updateGiftset(formData).subscribe((data) => {
        if (data.requestResult == 1) {
          this.getAllGiftsets();
          this.resetForm();
          this.closeDetails();
          this.showSuccess('update');
          this.resetInlineEdit();
        } else {
          this.errorMessage = data.responseTip;
          this.showError();
        }
      },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        });
    } else {
      this.selectedProductForm.markAllAsTouched();
      this.errorMessage = 'Please fill all required fields.';
      this.showError();
    }
  }


  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * After view init
   */
  ngAfterViewInit(): void {
    if (this._sort && this._paginator) {
      setTimeout(() => {
        // Set the initial sort
        this._sort.sort({
          id: 'id',
          start: 'desc',
          disableClear: true,
        });

      })


      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;
          this.pageIndex = 0;

          //reset and close the form if it is open
          this.resetForm();
          this.closeDetails();

          // set the sort column and sort order
          this.sortColumn = this.getSortColumn(this._sort.active);
          this.sortOrder = this._sort.direction === 'asc' ? 2 : 1;


          // Close the details
          this.closeDetails();

          // Get the Brands
          this.getAllGiftsets();

        });


    }
  }

  getSortColumn(name: string) {
    switch (name) {
      case 'importId':
        return 1;
        break;
      case 'title':
        return 2;
        break;
      default:
        return 0;
    }
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggle product details
   *
   * @param productId
   */
  toggleDetails(productId: number): void {
    this.createGiftset = false;
    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct.id === productId) {
      // Close the details
      this.closeDetails();
      return;
    }

    const myMap = new Map(this.giftsetsArray.map(obj => [obj.id, obj]));

    // Reset mapped products arrays
    this.mappedProducts = [];
    this.selectedMappedProducts = [];

    this.selectedProduct = myMap.get(productId);
    let modifiedImages = this.selectedProduct.images.map(image => ({
      ...image,
      isLibraryImage: false
    }));
    this.selectedProductForm.patchValue(this.selectedProduct);
    this.images = modifiedImages;
    this.videos = this.selectedProduct.videos;
    this.initializeImages(this.images);

    // Set mappedProducts IDs from the selected product's mapped products
    if (this.selectedProduct.mappedProducts && this.selectedProduct.mappedProducts.length > 0) {
      this.mappedProducts = this.selectedProduct.mappedProducts.map(product => product.productId);
      this.selectedMappedProducts = [...this.selectedProduct.mappedProducts];
    }
    
    this.updateTotalGiftPrice();
  }



  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
    this.videos = [];
    this.images = [];
    this.showMappedProductsError = false;
  }

  resetForm() {
    this.mappedProductInput.markAsUntouched();
    let property = this.selectedProductForm.getRawValue();
    
    this.selectedProductForm.reset({
      id: property.id,
      published: false,
      videos: [],
      images: [],
      categories: [],
      mappedProducts: [],
    });

    // Optionally mark the form as touched to trigger validation messages
    if(property.id !== 0){
      this.selectedProductForm.markAllAsTouched();
    }
    this.selectedMappedProducts = [];
    this.mappedProducts = [];
    this.showMappedProductsError = false;
  }

  /**
   * Delete the selected product using the form data
   */
  async deleteSelectedProduct(id: number | null, isFromDeleteBtn: boolean = false): Promise<void> {

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Giftset');

    if (!confirmed) {
      return;
    }
  
    if (!isFromDeleteBtn) {
      this.selectedGiftsets.clear();
      this.selectedGiftsets.set(id, true)
    }

    this.deleteGiftset();
    this.closeDetails();

  }



  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }

  addVideos(video: string) {
    let urlPattern = /^https?:\/\/([\w-]+\.)+[\w-]+(\/[\w\-._~:/?#[\]@!$&'()*+,;=]*)?$/;
    if (urlPattern.test(video)) {

      this.videos.push(video);
      this.videoUrl = ''; // Clear the input field after adding the video
    } else {
      this.errorMessage = 'Invalid video URL';
      this.showError();
    }
  }

  async removeVideo(video: string) {

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('video', DeleteTypes.Video);

    if (confirmed) {
      this.videos = this.videos.filter(i => i !== video);
    }
  }

  // When user changes thumbnail
  onThumbnailSelect(index: number) {
    this.selectedThumbnailIndex = index;

    // Update all images
    this.images.forEach((image, i) => {
      image.thumbnail = i === index;
    });

  }

  // While initializing (example after fetching images)
  initializeImages(images: Image[]) {
    this.selectedThumbnailIndex = this.images.findIndex(img => img.thumbnail);
  }

  separateImagesAccordingToTypes() {
    this.productImages = [];
    this.existingImages = [];
    this.LibraryImages = [];

    for (const image of this.images) {
      if (image.fileName instanceof File) {
        this.productImages.push({
          Image: image.fileName,
          Thumbnail: image.thumbnail,
        });
      } else if (image.isLibraryImage) {
        this.LibraryImages.push(image);
      }
      else {
        this.existingImages.push(image);
      }

    }
  }




  public GetFileOnLoad(event: any, inputBox: string) {
    if (event.target.files && event.target.files.length > 0) {
      for (let i = 0; i < event.target.files.length; i++) {
        var file = event.target.files[i] as File;
        this.images.push({
          fileName: file,
          thumbnail: false,
          imageUrl: URL.createObjectURL(file),
          isLibraryImage: false
        });
      }

      setTimeout(() => {
        this.onThumbnailSelect(0);
      }, 1000);
    }
  }

  removeImageFile(url: string) {
    this.images = this.images.filter((pimage) => pimage.imageUrl !== url);
  }

  onSelectionChange(value: any) {
    if (value && value != '') {
      this.selectedProductForm.get(value).markAsTouched();

      if (value == 'partnerId') {
        this.getPartnerProductsAndCategories(this.selectedProductForm.get('partnerId').value)
      } else if (value == 'categories') {
        this.getProductsAccordingToCategoriesSelection(this.selectedProductForm.get('categories').value);
      }
    }
  }

  openImageLibrary() {
    const dialogRef = this.dialog.open(ImageLibraryDialog);

    dialogRef.afterClosed().subscribe((result: ImageLibraryContent) => {
      this.images.push({
        fileName: result.fileName,
        imageUrl: result.urlPath + result.fileName,
        thumbnail: false,
        isLibraryImage: true
      })
    });
  }

  onDropdownBlur(type: string) {
    switch (type) {
      case 'partnerId':
        this.selectedProductForm.get('partnerId').markAsTouched();
        break;
      case 'categories':
        this.selectedProductForm.get('categories').markAsTouched();
        break;
      case 'mappedProducts':
        this.mappedProductsInput.markAsTouched();
        break;     
      default:
        break;
    }
  }


  validateQuantity(mp: MappedProduct) {
    if (!mp.quantity || mp.quantity <= 0) {
      if (!this.mappedProductsWithError.includes(mp)) {
        this.mappedProductsWithError.push(mp);
        this.errorMessage = 'Quantity canot be zero, negative or empty';
        this.showError();
      }
    } else {
      const index = this.mappedProductsWithError.indexOf(mp);
      if (index !== -1) {
        this.mappedProductsWithError.splice(index, 1);
      }
      this.updateTotalGiftPrice();
    }
  }
}

