import { Routes } from '@angular/router';
import { FaqComponent } from './faq.component';

export default [
    {
        path: '',
        component: FaqComponent,
    },
] as Routes;