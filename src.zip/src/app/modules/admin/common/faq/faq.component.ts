import {
  AsyncPipe,
  CommonModule,
  CurrencyPipe,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { InventoryService } from 'app/shared/services/inventory.service';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatTooltipModule } from '@angular/material/tooltip';

import {
  InventoryBrand,
  InventoryCategory,
  InventoryPagination,
  InventoryProduct,
  InventoryTag,
  InventoryVendor,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  map,
  switchMap,
  takeUntil,
} from 'rxjs';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { faq, faqTypeName, ImageLibraryContent } from 'app/shared/types/interfaces';
import { SearchableDropdownComponent } from 'app/shared/components/searchable-dropdown/searchable-dropdown.component';
import { MatDialog } from '@angular/material/dialog';
import { ImageLibraryDialog } from 'app/shared/components/image-library/image-library.component';
import { DeleteConfirmationService } from 'app/shared/services/delete-confirmation.service';
import { CommonHelperService } from 'app/shared/services/common-helper.service';

@Component({
  selector: 'app-faq',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 1fr 1fr 1fr 88px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 1fr 1fr 1fr 88px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 1fr 1fr 1fr 88px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 1fr 1fr 1fr 88px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    MatTooltipModule,
    SearchableDropdownComponent,
    CommonModule
  ],
  templateUrl: './faq.component.html',
  styleUrl: './faq.component.scss',
})
export class FaqComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  products$: Observable<InventoryProduct[]>;

  brands: InventoryBrand[];
  categories: InventoryCategory[];
  filteredTags: InventoryTag[];
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: InventoryPagination;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: faq | null = null;
  selectedProductForm: UntypedFormGroup;
  tags: InventoryTag[];
  tagsEditMode: boolean = false;
  vendors: InventoryVendor[];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  faqsArray: faq[] = [];
  selectedFaqs: Map<number, boolean> = new Map(); // Tracks selected brands
  allSelected: boolean = false;
  faqTypesList: faqTypeName[] = [];

  searchQuery: string = '';
  searchSubject = new Subject<string>();
  searchSubscription: any;

  // Pagination properties
  pageIndex: number = 0;
  pageSize: number = 10;
  totalCount: number = 0;
  sortOrder: number = 1;
  sortColumn: number = 0;

  createFaq = false;
  selectedFaqTypeId: number | null = null;

  faqImg: string = '';
  faqImgFile: File | null = null;

  errorMessage = '';
  isDataLoaded: boolean = false;

  LibraryFaqImage: ImageLibraryContent = null;

  @ViewChild('headerPaginator') headerPaginator!: MatPaginator;
  @ViewChild('footerPaginator') footerPaginator!: MatPaginator;

  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _deleteConfirmationService: DeleteConfirmationService,    
    private _formBuilder: UntypedFormBuilder,
    private _inventoryService: InventoryService,
    private apiService: ApiService,
    private toastr: ToastrService,
    private dialog: MatDialog
  ) { }

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.selectedProductForm = this._formBuilder.group({
      id: [''],
      name: ['', [Validators.required]],
      faqTypeId: ['', [Validators.required]],
      title: ['', [Validators.required]],
      titleEng: ['', [Validators.required]],
      text: ['', [Validators.required]],
      textEng: ['', [Validators.required]],
    });

    // Get the brands
    this._inventoryService.brands$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((brands: InventoryBrand[]) => {
        // Update the brands
        this.brands = brands;

        // Mark for check
        this._changeDetectorRef.markForCheck();
      });

    // Get the categories
    this._inventoryService.categories$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((categories: InventoryCategory[]) => {
        // Update the categories
        this.categories = categories;

        // Mark for check
        this._changeDetectorRef.markForCheck();
      });

    // Get the pagination
    this._inventoryService.pagination$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((pagination: InventoryPagination) => {
        // Update the pagination
        this.pagination = pagination;

        // Mark for check
        this._changeDetectorRef.markForCheck();
      });

    // Get the products
    this.products$ = this._inventoryService.products$;

    // Get the tags
    this._inventoryService.tags$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((tags: InventoryTag[]) => {
        // Update the tags
        this.tags = tags;
        this.filteredTags = tags;

        // Mark for check
        this._changeDetectorRef.markForCheck();
      });

    // Get the vendors
    this._inventoryService.vendors$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((vendors: InventoryVendor[]) => {
        // Update the vendors
        this.vendors = vendors;

        // Mark for check
        this._changeDetectorRef.markForCheck();
      });

    // Subscribe to search input field value changes
    this.searchInputControl.valueChanges
      .pipe(
        takeUntil(this._unsubscribeAll),
        debounceTime(300),
        switchMap((query) => {
          this.closeDetails();
          this.isLoading = true;
          return this._inventoryService.getProducts(
            0,
            10,
            'name',
            'asc',
            query
          );
        }),
        map(() => {
          this.isLoading = false;
        })
      )
      .subscribe();

    //get all faq types
    this.getAllFaqTypes();

    // Debounce search input to optimize API calls
    this.searchSubscription = this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe(query => {
        this.searchQuery = query;
        this.pageIndex = 0; // Reset to first page on new search
        this.footerPaginator.firstPage();
        this.getAllFaqs();
      });

  }



  // Toggle selection for a single brand
  toggleSelection(brandId: number) {
    if (this.selectedFaqs.has(brandId)) {
      this.selectedFaqs.delete(brandId); // Unselect
    } else {
      this.selectedFaqs.set(brandId, true); // Select
    }
    this.updateSelectAllState();
  }

  // Toggle Select All
  toggleSelectAll() {
    if (this.allSelected) {
      this.selectedFaqs.clear(); // Unselect all
    } else {
      this.faqsArray.forEach(brand => this.selectedFaqs.set(brand.id, true)); // Select all
    }
    this.allSelected = !this.allSelected;
  }

  // Update the "Select All" checkbox state
  updateSelectAllState() {
    this.allSelected = this.selectedFaqs.size === this.faqsArray.length;
  }

  //get selectedFaqs' Ids
  getSelectedBrandIds(): number[] {
    return Array.from(this.selectedFaqs.entries()) // Convert Map to an array of key-value pairs
      .filter(([id, isSelected]) => isSelected) // Filter selected brands
      .map(([id]) => id); // Extract only the IDs
  }
  //Deletes the selected Brand entries by calling the API service. If the deletion is successful, it clears the selected Brands map.
  deleteFaqs() {
    this.apiService.deleteFAQ(this.getSelectedBrandIds()).subscribe((response) => {
      if (response.requestResult == 1) {
        this.selectedFaqs = new Map();
        this.getAllFaqs();
        this.showSuccess('delete');
      } else {
        this.errorMessage = response.responseTip;
        this.showError();
      }
    }, (error) => {
      this.errorMessage = error.error.responseTip;
      this.showError();
    })
  }

  // get all brands
  getAllFaqs() {
    const params = {
      sortColumn: this.sortColumn,
      pageIndex: this.pageIndex,
      pageSize: this.pageSize,
      sortOrder: this.sortOrder,
      searchQuery: this.searchQuery,
      faqTypeId: this.selectedFaqTypeId
    }
    this.apiService.getFAQs(params).subscribe((data) => {
      this.faqsArray = data.result.data;
      this.pageIndex = data.result.pageIndex;
      this.pageSize = data.result.pageSize;
      this.totalCount = data.result.count;
      this.isDataLoaded = true
    }, 
  (error)=>{
    this.errorMessage = error.error.responseTip;
    this.showError();
  });
  }

  getAllFaqTypes(){
    this.apiService.getFAQTypesList().subscribe((data)=>{
      this.faqTypesList = data.result;
    },
  (error)=>{
    this.errorMessage = error.error.responseTip;
    this.showError();
  })
  }

  showSuccess(type: string) {
    const message = type === 'create' ? 'FAQ created successfully.' : (type == 'update' ? 'FAQ updated successfully.' : 'FAQ deleted successfully.');
    this.toastr.success(message, 'Success!');
  }
  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }

  // Triggers a search operation with the provided query string.
  onSearch(query: string): void {
    this.createFaq = false;
    this.closeDetails();
    this.searchSubject.next(query);
  }

  // Handle pagination changes
  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.getAllFaqs();
  }

  toggleCreateFaqForm() {
    this.faqImgFile = null;
    this.faqImg = '';
    this.createFaq = !this.createFaq;
    if (this.createFaq) {
      const newProduct = {
        id: 0,
        name: '',
        faqTypeId: null,
        title: '',
        titleEng: '',
        text: '',
        textEng: '',
        image: ''
      }
      // Go to new product
      this.selectedProduct = newProduct;

      // Fill the form
      this.selectedProductForm.patchValue(newProduct);

      // Mark for check
      this._changeDetectorRef.markForCheck();
    } else {
      this.selectedProductForm.reset();
    }
  }

  addFaq() {
    if(this.selectedProductForm.valid){
    const faq = this.selectedProductForm.getRawValue();
    var formData = new FormData();
    formData.append('Name', faq.name);
    formData.append('Title', faq.title);
    formData.append('TitleEng', faq.titleEng);
    formData.append('Text', faq.text);
    formData.append('TextEng', faq.textEng);
    formData.append('FaqTypeId', faq.faqTypeId);
    if (this.faqImgFile != null) {
      formData.append('Image', this.faqImgFile);
    }

    if(!this.faqImgFile && this.LibraryFaqImage){
      formData.append('LibraryImage.UrlPath', this.LibraryFaqImage.urlPath);
      formData.append('LibraryImage.FileName', this.LibraryFaqImage.fileName);
    }

    this.apiService.createFAQ(formData).subscribe((data) => {
      if(data.requestResult == 1){
        this.getAllFaqs();
        this.resetForm();
        this.closeDetails();
        this.createFaq = false;
        this.showSuccess('create');
      }else{
        this.errorMessage = data.responseTip;
        this.showError();
      }
    },
  (error) => {
    this.errorMessage = error.error.responseTip;
    this.showError();
  });
    }else{
      this.selectedProductForm.markAllAsTouched();
      this.errorMessage = 'Please fill all the required fields';
      this.showError();
    }
  }

  updateFaq() {
    if(this.selectedProductForm.valid){
    const faq = this.selectedProductForm.getRawValue();
    var formData = new FormData();
    formData.append('Id', faq.id);
    formData.append('Name', faq.name);
    formData.append('Title', faq.title);
    formData.append('TitleEng', faq.titleEng);
    formData.append('Text', faq.text);
    formData.append('TextEng', faq.textEng);
    formData.append('FaqTypeId', faq.faqTypeId);

    if (this.faqImgFile != null) {
      formData.append('Image', this.faqImgFile);
    }
    
    if(!this.faqImgFile && this.LibraryFaqImage){
      formData.append('LibraryImage.UrlPath', this.LibraryFaqImage.urlPath);
      formData.append('LibraryImage.FileName', this.LibraryFaqImage.fileName);
    }

    this.apiService.updateFAQ(formData).subscribe((data) => {
      if(data.requestResult == 1){
        this.getAllFaqs();
        this.resetForm();
        this.closeDetails();
        this.showSuccess('update');
      }else{
        this.errorMessage = data.responseTip;
        this.showError();
      }
    },
  (error) => {
    this.errorMessage = error.error.responseTip;
    this.showError();
  });
  }else{
    this.selectedProductForm.markAllAsTouched();
    this.errorMessage = 'Please fill all the required fields';
    this.showError();
  }
}

  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * After view init
   */
  ngAfterViewInit(): void {
    if (this._sort && this._paginator) {
     setTimeout(()=>{
       // Set the initial sort
       this._sort.sort({
        id: 'id',
        start: 'desc',
        disableClear: true,
      });
     });      

      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;
          this.pageIndex = 0;

          //reset and close the form if it is open
          this.resetForm();
          this.closeDetails();

          // set the sort column and sort order
          this.sortColumn = this.getSortColumn(this._sort.active);
          this.sortOrder = this._sort.direction === 'asc' ? 2 : 1;
          

          // Close the details
          this.closeDetails();

          // Get the Brands
          this.getAllFaqs();
        });


    }
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
    if (this.searchSubscription) {
      this.searchSubscription.unsubscribe();
    }
  }

  getSortColumn(name: string){
    switch(name) {
      case 'name':
        return 1;
        break;
      case 'dutchText':
        return 2;
        break;
      case 'engText':
        return 3;
        break;
      default:
        return 0;
    }
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggle product details
   *
   * @param id
   */
  toggleDetails(id: number): void {
    this.createFaq = false; // Close create brand form if open
    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct.id === id) {
      // Close the details
      this.closeDetails();
      return;
    }

    const myMap = new Map(this.faqsArray.map(obj => [obj.id, obj]));

    this.selectedProduct = myMap.get(id);
    this.selectedProductForm.patchValue(this.selectedProduct);
    this.faqImg = this.selectedProduct.image;
  }

  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
  }

  //reset form
  resetForm(){
    CommonHelperService.preserveId(this.selectedProductForm);
    this.faqImg = '';
    this.faqImgFile = null;
  }



  /**
   * Update the selected product using the form data
   */
  updateSelectedProduct(): void {
    // Get the product object
    const product = this.selectedProductForm.getRawValue();

    // Remove the currentImageIndex field
    delete product.currentImageIndex;

    // Update the product on the server
    this._inventoryService.updateProduct(product.id, product).subscribe(() => {
      // Show a success message
      this.showFlashMessage('success');
    });
  }

  /**
   * Delete the selected product using the form data
   */
  async deleteSelectedProduct(id: number | null, isFromDeleteBtn = false): Promise<void> {

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('FAQ');

    if (!confirmed) {
      return;
    }

    if (!isFromDeleteBtn) {
      this.selectedFaqs.clear();
      this.selectedFaqs.set(id, true)
    }

    // delete the faq 
    this.deleteFaqs();

    // Close the details
    this.closeDetails();
  }


  /**
   * Show flash message
   */
  showFlashMessage(type: 'success' | 'error'): void {
    // Show the message
    this.flashMessage = type;

    // Mark for check
    this._changeDetectorRef.markForCheck();

    // Hide it after 3 seconds
    setTimeout(() => {
      this.flashMessage = null;

      // Mark for check
      this._changeDetectorRef.markForCheck();
    }, 3000);
  }

  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }


  public GetFileOnLoad(event: any, inputBox: string) {
    if (event.target.files && event.target.files[0]) {
      var file = event.target.files[0] as File;

      this.faqImgFile = file;
      this.faqImg = URL.createObjectURL(file);
    }
  }

  removeImageFile(inputBox: string) {
    this.faqImg = '';
    var element = document.getElementById(inputBox) as HTMLInputElement | null;
    if (element != null) {
      element.value = '';
    }
    this.LibraryFaqImage = null;
  }

  multiDeleteDisable = true;

  onSelectionChange(value: any) {
    if(value && value !=''){
      this.selectedProductForm.get(value).markAsTouched();
    }
  }

  openImageLibrary() {
    const dialogRef = this.dialog.open(ImageLibraryDialog);

    dialogRef.afterClosed().subscribe(result => {
      this.LibraryFaqImage = result;
      this.faqImg = this.LibraryFaqImage.urlPath + this.LibraryFaqImage.fileName;
    });
  }

  onDropdownBlur(){
    this.selectedProductForm.get('faqTypeId').markAsTouched();
    this.selectedProductForm.get('faqTypeId').updateValueAndValidity();
  }
}
