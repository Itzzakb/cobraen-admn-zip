import { Routes } from '@angular/router';
import { OrderMessagesComponent } from './order-messages.component';

export default [
    {
        path: '',
        component: OrderMessagesComponent,
    },
] as Routes;