import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { ExtraStockDetails, ExtraStockProductDetails } from 'app/shared/types/extra-stock.types';

@Component({
  selector: 'app-delivery-status-dialog',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule
  ],
  template: `
    <div class="-m-6">
      <div class="flex flex-col bg-card">
        <div class="flex flex-0 items-center justify-between h-16 pr-4 pl-6 sm:pr-6 border-b">
          <div class="text-lg font-medium">Update Delivery Status</div>
          <button mat-icon-button (click)="close()">
            <mat-icon [svgIcon]="'heroicons_outline:x-mark'"></mat-icon>
          </button>
        </div>


        <form [formGroup]="deliveryForm" class="p-6 sm:p-8 overflow-y-auto">
          <div class="space-y-6">
            <div class="bg-gray-50 rounded-lg p-4">
              <div class="text-lg font-medium mb-2">Order Details</div>
              <div class="text-secondary space-y-1">
                <div>Supplier: {{extraStockDetails?.supplier}}</div>
                <div>Order Number: {{extraStockDetails?.supplierNumber}}</div>
                <div>Order Date: {{extraStockDetails?.orderDate | date}}</div>
              </div>
            </div>

            <div class="bg-gray-50 rounded-lg p-4 mt-6">
              <div class="text-lg font-medium mb-2">Products</div>
              @for (product of extraStockDetails?.products ?? []; track product.id) {
                <div class="bg-white rounded-lg p-4 mb-3 border border-gray-200">
                  <div class="flex justify-between items-center mb-4">
                    <div class="font-medium">{{product.title}}</div>
                    <div class="text-secondary text-sm">Import ID: {{product.importId}}</div>
                  </div>
                  <div class="flex items-center gap-4">
                    <mat-form-field class="w-1/3 -my-3">
                      <mat-label>Amount Delivered</mat-label>
                      <input 
                        matInput 
                        type="number"
                        [min]="0"
                        [max]="product.amountOrdered"
                        [formControlName]="'product_' + product.id"
                        (input)="validateDeliveredAmount(product.id)"
                      />
                      <mat-hint>Ordered: {{product.amountOrdered}}</mat-hint>
                      @if (deliveryForm.get('product_' + product.id)?.errors?.['max']) {
                        <mat-error>Cannot exceed ordered amount</mat-error>
                      }
                    </mat-form-field>
                    <div class="text-secondary text-sm">
                      <div>Ordered by customers: {{product.amountOrderedByCustomers}}</div>
                    </div>
                  </div>
                </div>
              }
            </div>

          </div>
        </form>
        <div class="flex items-center justify-end gap-2 border-t px-6 py-4">
          <button mat-stroked-button (click)="close()">Cancel</button>
          <button 
            mat-flat-button 
            color="primary" 
            [disabled]="!deliveryForm.valid || isSubmitting"
            (click)="submit()"
          >
            Update Delivery Status
          </button>
        </div>
      </div>
    </div>
  `
})
export class DeliveryStatusDialogComponent {
  deliveryForm: UntypedFormGroup;
  isSubmitting = false;
  extraStockDetails: ExtraStockDetails;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _dialogRef: MatDialogRef<DeliveryStatusDialogComponent>,
    private _formBuilder: UntypedFormBuilder
  ) {
    this.extraStockDetails = data.result;
    this.deliveryForm = this._formBuilder.group({});
    
    // Create form controls for each product
    if (this.extraStockDetails?.products) {
      this.extraStockDetails.products.forEach(product => {
        this.deliveryForm.addControl(
          'product_' + product.id,
          this._formBuilder.control(
            product.amountDelivered || 0,
            [
              Validators.required,
              Validators.min(0),
              Validators.max(product.amountOrdered)
            ]
          )
        );
      });
    }
  }

  validateDeliveredAmount(productId: number): void {
    const control = this.deliveryForm.get('product_' + productId);
    if (control && this.extraStockDetails?.products) {
      const product = this.extraStockDetails.products.find(p => p.id === productId);
      if (product && control.value > product.amountOrdered) {
        control.setValue(product.amountOrdered);
      }
      if (control.value < 0) {
        control.setValue(0);
      }
    }
  }

  submit(): void {
    if (this.deliveryForm.valid && !this.isSubmitting && this.extraStockDetails?.products) {
      this.isSubmitting = true;
      
      const deliveredProducts = this.extraStockDetails.products.map(product => ({
        extraOrderProductId: product.id,
        amountDelivered: this.deliveryForm.get('product_' + product.id)?.value || 0
      }));

      this._dialogRef.close({
        extraStockId: this.extraStockDetails.id,
        deliveredProducts
      });
    }
  }

  close(): void {
    this._dialogRef.close();
  }
}
