import { Routes } from "@angular/router";
import { ExtraStockComponent } from "./extra-stock.component";

export default[
    {
        path: '',
        component: ExtraStockComponent
    }
] as Routes