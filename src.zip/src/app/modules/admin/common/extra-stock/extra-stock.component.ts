import {
  AsyncPipe,
  CurrencyPipe,
  DatePipe,
  NgClass,
  NgTemplateOutlet,
  NgIf,
  NgFor
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { DeliveryStatusDialogComponent } from './delivery-status-dialog/delivery-status-dialog.component';
import { MatSort, MatSortModule, Sort } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ExtraStockService } from 'app/shared/services/extra-stock.service';
import { 
  ExtraStock, 
  ExtraStockDetails, 
  ExtraStockProductDetails, 
  ProductSearchResult 
} from 'app/shared/types/extra-stock.types';

import {
  InventoryBrand,
  InventoryCategory,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  map,
  switchMap,
  takeUntil,
} from 'rxjs';
import { CommonHelperService } from 'app/shared/services/common-helper.service';

@Component({
  selector: 'app-extra-stock',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 80px 30% 1fr 100px 1fr 100px 1fr 50px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 80px 30% 1fr 100px 1fr 100px 1fr 50px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 80px 30% 1fr 100px 1fr 100px 1fr 50px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 80px 30% 1fr 100px 1fr 100px 1fr 50px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    NgIf,
    NgFor,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    DatePipe,
    MatTooltipModule,
    MatDatepickerModule,
    MatSnackBarModule,
    MatDialogModule
  ],
  templateUrl: './extra-stock.component.html',
  styleUrl: './extra-stock.component.scss',
})
export class ExtraStockComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  extraStocks$: Observable<ExtraStock[]>;
  selectedExtraStock: ExtraStockDetails | null = null;
  extraStockForm: UntypedFormGroup;
  selectedProducts: ExtraStockProductDetails[] = [];
  searchedProducts: ProductSearchResult[] = [];
  searchProductsForm: UntypedFormGroup;
  
  formFieldHelpers: string[] = [];
  minDate: Date = new Date();
  
  // For backward compatibility until we fully update the component
  brands: InventoryBrand[] = [];
  categories: InventoryCategory[] = [];
  
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: any;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  isEditMode: boolean = false;
  isCreateMode: boolean = false;
  showProductSearchResults: boolean = false;
  
  // Map to store selected extraStock IDs
  selectedExtraStocks: Set<number> = new Set<number>();
  allSelected: boolean = false;
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _formBuilder: UntypedFormBuilder,
    private _extraStockService: ExtraStockService,
    private _snackBar: MatSnackBar,
    private _dialog: MatDialog
  ) {}

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    const alphaNumericValidator = Validators.pattern(/^(?!\s*$)[a-zA-Z0-9\s]+$/);    
    
    // Create the extra stock form
    this.extraStockForm = this._formBuilder.group({
      id: [0],
      supplier: ['', [Validators.required, alphaNumericValidator]],
      supplierOrderNumber: ['', [Validators.required, alphaNumericValidator]],
      expectedDeliveryDate: [new Date(), [Validators.required]],
      status: [1],
      remarks: [''],
    });

    // Create search products form
    this.searchProductsForm = this._formBuilder.group({
      search: [''] 
    });

    // Ensure pagination always has a default value
    this.pagination = {
      length: 0,
      size: 10,
      page: 0
    };

    // Get the pagination
    this._extraStockService.pagination$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((pagination) => {
        // Update the pagination if value exists
        if (pagination) {
          this.pagination = pagination;
        }

        // Mark for check
        this._changeDetectorRef.markForCheck();
      });

    // Get the extra stocks
    this.extraStocks$ = this._extraStockService.extraStocks$;

    // Subscribe to search input field value changes
    this.searchInputControl.valueChanges
      .pipe(
        takeUntil(this._unsubscribeAll),
        debounceTime(300),
        switchMap((query) => {
          this.closeDetails();
          this.isLoading = true;
          return this._extraStockService.getExtraStocks(
            0,
            this.pagination?.size || 10,
            this._sort?.active || 'id',
            this._sort?.direction as 'asc' | 'desc' || 'desc',
            query
          );
        }),
        map(() => {
          this.isLoading = false;
        })
      )
      .subscribe();
      
    // Load initial data
    this.isLoading = true;
    this._extraStockService.getExtraStocks(0, 10, 'id', 'desc').subscribe({
      next: (response) => {
        //console.log(('Initial data loaded:', response);
        this.isLoading = false;
        this._changeDetectorRef.markForCheck();
      },
      error: (err) => {
        console.error('Failed to load extra stocks:', err);
        this.isLoading = false;
        this._changeDetectorRef.markForCheck();
      },
      complete: () => {
        //console.log(('Initial data loading completed');
      }
    });
  }

  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * After view init
   */
  ngAfterViewInit(): void {
    if (this._sort && this._paginator) {
      // Set the initial sort
      this._sort.sort({
        id: 'id',
        start: 'desc',
        disableClear: true,
      });

      // Mark for check
      this._changeDetectorRef.markForCheck();

      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;

          // Close the details
          this.closeDetails();
          
          // Load data with new sort
          this.loadExtraStocksWithCurrentSettings();
        });
    }
  }

  /**
   * Handle sort change event
   */
  openDeliveryStatusDialog(extraStockId: number): void {
    // First get the full details
    this._extraStockService.getExtraStockDetails(extraStockId).subscribe({
      next: (response) => {
        if (!response?.result) {
          this._snackBar.open('Error loading details: Invalid response', 'Close', {
            duration: 3000
          });
          return;
        }

        // Open dialog with the details
        const dialogRef = this._dialog.open(DeliveryStatusDialogComponent, {
          data: response,
          autoFocus: false,
          disableClose: true,
          width: '800px',
          maxWidth: '90vw',
          maxHeight: '90vh'
        });

        // Handle dialog close
        dialogRef.afterClosed().subscribe(result => {
          if (result) {
            this.isLoading = true;
            this._extraStockService.updateDeliveryStatus(result).subscribe({
              next: (response) => {
                this._snackBar.open('Delivery status updated successfully', 'Close', {
                  duration: 3000
                });
                this.loadExtraStocksWithCurrentSettings();
              },
              error: (error) => {
                console.error('Error updating delivery status:', error);
                this._snackBar.open('Error updating delivery status', 'Close', {
                  duration: 3000
                });
                this.isLoading = false;
                this._changeDetectorRef.markForCheck();
              }
            });
          }
        });
      },
      error: (error) => {
        console.error('Error loading extra stock details:', error);
        this._snackBar.open('Error loading details. Please try again.', 'Close', {
          duration: 3000
        });
      }
    });
  }

  onSortChange(event: Sort): void {
    // Update the sort
    this._sort.active = event.active;
    this._sort.direction = event.direction;

    // Close the details
    this.closeDetails();
    
    // Load data with new sort
    this.loadExtraStocksWithCurrentSettings();
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Handle page event from paginator
   */
  onPageChange(event: PageEvent): void {
    if (this._paginator) {
      this._paginator.pageIndex = event.pageIndex;
      this._paginator.pageSize = event.pageSize;
    }
    
    if (this.pagination) {
      this.pagination.page = event.pageIndex;
      this.pagination.size = event.pageSize;
    }
    this.loadExtraStocksWithCurrentSettings();
  }

  /**
   * Load extra stocks with current paginator, sort, and search settings
   */
  loadExtraStocksWithCurrentSettings(): void {
    if (!this._paginator || !this._sort) {
      console.warn('Paginator or sort is not initialized');
      return;
    }

    this.isLoading = true;
    // //console.log(('Loading data with settings:', {
    //   pageIndex: this._paginator.pageIndex,
    //   pageSize: this._paginator.pageSize,
    //   sortActive: this._sort.active,
    //   sortDirection: this._sort.direction,
    //   searchTerm: this.searchInputControl.value || ''
    // });
    
    this._extraStockService.getExtraStocks(
      this._paginator.pageIndex,
      this._paginator.pageSize,
      this._sort.active || 'id',
      this._sort.direction as 'asc' | 'desc' || 'desc',
      this.searchInputControl.value || ''
    ).subscribe({
      next: (response) => {
        //console.log(('Data loaded successfully:', response);
        this.isLoading = false;
        this._changeDetectorRef.markForCheck();
      },
      error: (err) => {
        console.error('Error loading extra stocks:', err);
        this.isLoading = false;
        this._snackBar.open('Error loading data. Please try again.', 'Close', {
          duration: 3000
        });
        this._changeDetectorRef.markForCheck();
      }
    });
  }

  /**
   * Toggle product details
   *
   * @param productId
   */
  toggleDetails(extraStockId: number): void {
    // First ensure we're not in create mode
    this.isCreateMode = false;
    
    // If the extra stock is already selected...
    if (this.selectedExtraStock && this.selectedExtraStock.id === extraStockId) {
      // Close the details
      this.closeDetails();
      return;
    }

    // Get the extra stock by id
    this._extraStockService.getExtraStockDetails(extraStockId).subscribe((response) => {
      // Set the selected extra stock
      this.selectedExtraStock = response.result;
      this.selectedProducts = [...this.selectedExtraStock.products];
      
      // Fill the form
      this.extraStockForm.patchValue({
        id: this.selectedExtraStock.id,
        supplier: this.selectedExtraStock.supplier,
        supplierOrderNumber: this.selectedExtraStock.supplierNumber,
        expectedDeliveryDate: new Date(this.selectedExtraStock.expectedDelivery),
        status: this.selectedExtraStock.status,
        remarks: this.selectedExtraStock.remarks
      });
      
      this.isEditMode = true;

      // Mark for check
      this._changeDetectorRef.markForCheck();
    });
  }

  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedExtraStock = null;
    this.isEditMode = false;
    this.isCreateMode = false;
    this.selectedProducts = [];
    this.resetForm();
  }

  /**
   * Reset the form
   */
  resetForm(): void {
    let property = this.extraStockForm.getRawValue();
    
    this.extraStockForm.reset({
      id: property.id ?? 0,
      supplier: '',
      supplierOrderNumber: '',
      expectedDeliveryDate: new Date(),
      status: 1,
      remarks: ''
    });

    // Optionally mark the form as touched to trigger validation messages
    if(property.id != 0){
      this.extraStockForm.markAllAsTouched();
    }
    
    // Clear the selected products array
    this.selectedProducts = [];
    
    // Trigger change detection to update the UI
    this._changeDetectorRef.markForCheck();
  }

  /**
   * Toggle create extra stock form
   */
  createNewExtraStock(): void {
    // If already in create mode, close it
    if (this.isCreateMode) {
      this.closeDetails();
      return;
    }
    
    // Otherwise, open the create form
    this.closeDetails(); // First close any open details
    this.isEditMode = false;
    this.isCreateMode = true;
    this.resetForm();
    this._changeDetectorRef.markForCheck();
  }

  /**
   * Toggle selection of all extra stocks
   */
  toggleSelectAll(): void {
    const extraStocks = this._extraStockService.extraStocks$;
    
    extraStocks.subscribe(stocks => {
      if (stocks && stocks.length > 0) {
        if (!this.allSelected) {
          // Select all
          this.selectedExtraStocks.clear();
          stocks.forEach(extraStock => {
            this.selectedExtraStocks.add(extraStock.id);
          });
          this.allSelected = true;
        } else {
          // Deselect all
          this.selectedExtraStocks.clear();
          this.allSelected = false;
        }
        this._changeDetectorRef.markForCheck();
      }
    }).unsubscribe(); // Immediately unsubscribe to prevent memory leaks
  }

  /**
   * Toggle selection of a single extra stock
   */
  toggleSelection(id: number): void {
    if (this.selectedExtraStocks.has(id)) {
      this.selectedExtraStocks.delete(id);
    } else {
      this.selectedExtraStocks.add(id);
    }

    // Check if all items are selected
    this._extraStockService.extraStocks$.subscribe(stocks => {
      if (stocks && stocks.length > 0) {
        this.allSelected = stocks.length === this.selectedExtraStocks.size;
      }
      this._changeDetectorRef.markForCheck();
    }).unsubscribe(); // Immediately unsubscribe to prevent memory leaks
  }

  /**
   * Handle product amount controls
   */
  productAmtCtrl(product: ExtraStockProductDetails, type: string): void {
    switch (type) {
      case 'add':
        product.amountOrdered += 1;
        break;
      case 'subtract':
        if (product.amountOrdered > 1) {
          product.amountOrdered -= 1;
        }
        break;
    }
    this._changeDetectorRef.markForCheck();
  }
  

  validateProductAmount(product: ExtraStockProductDetails): void {

    const amount = parseInt(product.amountOrdered.toString(), 10);
    

    if (isNaN(amount) || amount < 1) {
      product.amountOrdered = 1;
      this._snackBar.open('Product count must be at least 1', 'Close', {
        duration: 3000
      });
    } else {

      product.amountOrdered = amount;
    }
    
    this._changeDetectorRef.markForCheck();
  }

  /**
   * Remove product from list
   */
  removeProduct(productId: number): void {
    this.selectedProducts = this.selectedProducts.filter(p => p.id !== productId);
    this._changeDetectorRef.markForCheck();
  }

  /**
   * Search for products
   */
  searchProducts(): void {
    const searchTerm = this.searchProductsForm.get('search').value;
    if (searchTerm) {
      this.isLoading = true;
      this._extraStockService.searchProducts(0, 100000, searchTerm).subscribe((response) => {
        this.searchedProducts = response.result.data;
        this.isLoading = false;
        this._changeDetectorRef.markForCheck();
        
        // Open products dialog or show section
        this.showProductSearchResults = true;
      });
    }
  }
  
  /**
   * Add product to selected products
   */
  addProductToSelected(product: ProductSearchResult): void {
    // Check if product already exists
    const exists = this.selectedProducts.some(p => p.productId === product.id);
    if (!exists) {

      this.selectedProducts.push({
        id: 0, // New product has id 0, it will be assigned by the server
        productId: product.id,
        importId: product.importId,
        title: product.title,
        amountOrdered: 1,
        amountDelivered: 0,
        amountOrderedByCustomers: 0
      });
      this._changeDetectorRef.markForCheck();
    }
    
    // Close product search results
    this.showProductSearchResults = false;
    this.searchProductsForm.get('search').setValue('');
  }

  /**
   * Submit form to create/update extra stock
   */
  submitExtraStock(): void {
    // Check if form is valid
    if (this.extraStockForm.invalid) {
      // Mark form controls as touched to show validation errors
      this.extraStockForm.markAllAsTouched();
      
      // More specific error messages based on validation errors
      if (this.extraStockForm.get('supplier')?.hasError('pattern') || 
          this.extraStockForm.get('supplierOrderNumber')?.hasError('pattern')) {
      } else {
        this._snackBar.open('Please fill in all required fields', 'Close', {
          duration: 3000
        });
      }
      return;
    }

    // Check if there are products
    if (this.selectedProducts.length === 0) {
      this._snackBar.open('Please add at least one product', 'Close', {
        duration: 3000
      });
      return;
    }
    

    const invalidProducts = this.selectedProducts.filter(product => !product.amountOrdered || product.amountOrdered < 1);
    if (invalidProducts.length > 0) {

      invalidProducts.forEach(product => {
        product.amountOrdered = 1;
      });
      
      this._snackBar.open('All products must have a count of at least 1. Invalid amounts have been set to 1.', 'Close', {
        duration: 4000
      });
      this._changeDetectorRef.markForCheck();
      return;
    }

    // Show loading
    this.isLoading = true;

    const formValue = this.extraStockForm.value;
    if (this.isEditMode) {
      // Update existing extra stock
      const updateData = {
        id: formValue.id,
        supplier: formValue.supplier,
        supplierOrderNumber: formValue.supplierOrderNumber,        
        expectedDeliveryDate: CommonHelperService.GenerateDate(formValue.expectedDeliveryDate),
        remarks: formValue.remarks,
        status: formValue.status,
        products: this.selectedProducts.map(p => ({
          productId: p.productId,
          amount: p.amountOrdered,
          amountDelivered: p.amountDelivered,
          extraOrderProductId: p.id
        }))
      };

      this._extraStockService.updateExtraStock(updateData).subscribe({
        next: (response) => {
          this.isLoading = false;
          this._snackBar.open('Extra stock updated successfully', 'Close', {
            duration: 3000
          });
          this.closeDetails();
          // Refresh list
          this.loadExtraStocksWithCurrentSettings();
        },
        error: (error) => {
          console.error('Error updating extra stock:', error);
          this.isLoading = false;
          this._snackBar.open('Error updating extra stock', 'Close', {
            duration: 3000
          });
        }
      });
    } else {
      // Create new extra stock
      const createData = {
        supplier: formValue.supplier,
        supplierOrderNumber: formValue.supplierOrderNumber,
        expectedDeliveryDate: CommonHelperService.GenerateDate(formValue.expectedDeliveryDate),
        remarks: formValue.remarks,
        products: this.selectedProducts.map(p => ({
          productId: p.productId,
          amount: p.amountOrdered
        }))
      };

      this._extraStockService.createExtraStock(createData).subscribe({
        next: (response) => {
        this.isLoading = false;
        this._snackBar.open('Extra stock created successfully', 'Close', {
        duration: 3000
        });
        this.closeDetails(); // This will also set isCreateMode to false
        // Refresh list
        this.loadExtraStocksWithCurrentSettings();
        },
        error: (error) => {
          console.error('Error creating extra stock:', error);
          this.isLoading = false;
          this._snackBar.open('Error creating extra stock', 'Close', {
            duration: 3000
          });
        }
      });
    }
  }

  /**
   * Show flash message
   */
  showFlashMessage(type: 'success' | 'error'): void {
    // Show the message
    this.flashMessage = type;

    // Mark for check
    this._changeDetectorRef.markForCheck();

    // Hide it after 3 seconds
    setTimeout(() => {
      this.flashMessage = null;

      // Mark for check
      this._changeDetectorRef.markForCheck();
    }, 3000);
  }
  
  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }
}
