import { Routes } from "@angular/router";
import { CharacteristicsComponent } from "./characteristics.component";

export default [
    {
        path: '',
        component: CharacteristicsComponent
    }
] as Routes