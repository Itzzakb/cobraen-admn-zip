import { Routes } from "@angular/router";
import { CategoriesComponent } from "./categories.component";

export default[
    {
        path: '',
        component: CategoriesComponent
    }
] as Routes