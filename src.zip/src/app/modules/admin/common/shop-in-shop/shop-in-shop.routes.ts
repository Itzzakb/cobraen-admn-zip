import { Routes } from "@angular/router";
import { ShopInShopComponent } from "./shop-in-shop.component";

export default [
    {
        path: '',
        component: ShopInShopComponent
    }
] as Routes