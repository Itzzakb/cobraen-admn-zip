import {
  AsyncPipe,
  CommonModule,
  CurrencyPipe,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatCheckboxChange,
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { InventoryService } from 'app/shared/services/inventory.service';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatRadioModule } from '@angular/material/radio';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { NgxMatTimepickerModule } from 'ngx-mat-timepicker';
import { MatTooltipModule } from '@angular/material/tooltip';

import {
  InventoryBrand,
  InventoryCategory,
  InventoryPagination,
  InventoryProduct,
  InventoryTag,
  InventoryVendor,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  takeUntil,
} from 'rxjs';
import { BudgetGroup, country, CommonDropdownItem } from 'app/shared/types/interfaces';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { DialogWithForm } from 'app/shared/utils/dialog-with-form/dialog-with-form.component';
import { MatDialog } from '@angular/material/dialog';
import { SearchableDropdownComponent } from 'app/shared/components/searchable-dropdown/searchable-dropdown.component';
import { DeleteConfirmationService } from 'app/shared/services/delete-confirmation.service';
import { CommonHelperService } from 'app/shared/services/common-helper.service';

@Component({
  selector: 'app-budget-groups',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 60px 1fr 150px 120px 120px 80px 7% 7% 136px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 60px 1fr 150px 120px 120px 80px 7% 7% 136px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 60px 1fr 150px 120px 120px 80px 7% 7% 136px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 60px 1fr 150px 120px 120px 80px 7% 7% 136px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    MatRadioModule,
    MatDatepickerModule,
    NgxMatTimepickerModule,
    MatTooltipModule,
    CommonModule,
    SearchableDropdownComponent
  ],
  templateUrl: './budget-groups.component.html',
  styleUrl: './budget-groups.component.scss',
})
export class BudgetGroupsComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  products$: Observable<InventoryProduct[]>;

  brands: InventoryBrand[];
  categories: InventoryCategory[];
  filteredTags: InventoryTag[];
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: InventoryPagination;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: BudgetGroup | null = null;
  budgetGroupForm: UntypedFormGroup;
  tags: InventoryTag[];
  tagsEditMode: boolean = false;
  vendors: InventoryVendor[];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  budgetGroupArray: BudgetGroup[] = [];
  selectedBudgetGroups: Map<number, boolean> = new Map(); // Tracks selected BudgetGroups
  allSelected: boolean = false;

  searchQuery: string = '';
  searchSubject = new Subject<string>();
  searchSubscription: any;

  // Pagination properties
  pageIndex: number = 0;
  pageSize: number = 10;
  totalCount: number = 0;
  sortOrder: number = 1;
  sortColumn: number = 0;

  createBudgetGroup = false;
  selectedBudgetGroupId: number | null = null;

  countryList: country[] = [];
  houseOrCompany: boolean = false;

  categoryList: CommonDropdownItem[] = [];

  errorMessage = '';
  isPayExtra: boolean = false;
  isDataLoaded: boolean = false;

  @ViewChild('headerPaginator') headerPaginator!: MatPaginator;
  @ViewChild('footerPaginator') footerPaginator!: MatPaginator;

  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _deleteConfirmationService: DeleteConfirmationService,
    private _formBuilder: UntypedFormBuilder,
    private _inventoryService: InventoryService,
    private apiService: ApiService,
    private toastr: ToastrService,
    private dialog: MatDialog
  ) {}

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.budgetGroupForm = this._formBuilder.group({
      id: [''],
      name: ['', [Validators.required]],
      street: [''],
      houseNumber: [''],
      zipCode: [''],
      city: [''],
      isDeliveryToCompany: [this.houseOrCompany],
      budget: ['', [Validators.pattern('^[0-9,.]+$')]],
      payExtra: [false],
      mailConfirmationOrder: [false],
      orderOnHoldDate: [''],
      orderOnHoldTime: [''],
      companyDelivery: [''],
      personalDelivery: [''],
      countryId: [''],
      locationName: [''],
      budgetChristmasFair: ['', [Validators.pattern('^[0-9,.]+$')]],
      isFairTimeChecked: [false],
      isFairDateChecked: [false],
      isFairLocationChecked: [false],
      budgetCode: [''],
      shopLimit: ['', [Validators.required]],
      categoryIds: [[]],
      maxProductPrice: ['', [Validators.pattern('^[0-9,.]+$')]]
    });

    //get all countries
    this.getAllCountries();

    //get category list
    this.getCategoryList();

    // Debounce search input to optimize API calls
    this.searchSubscription = this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe((query) => {
        this.searchQuery = query;
        this.pageIndex = 0; // Reset to first page on new search
        this.footerPaginator.firstPage();
        this.getAllbudgetGroups();
      });
  }

  updateValidatorsForCompanyLocation() {
    if (this.houseOrCompany) {
      this.budgetGroupForm.get('locationName').setValidators([Validators.required]);
      this.budgetGroupForm.get('street').setValidators([Validators.required]);
      this.budgetGroupForm.get('houseNumber').setValidators([Validators.required]);
      this.budgetGroupForm.get('zipCode').setValidators([Validators.required]);
      this.budgetGroupForm.get('city').setValidators([Validators.required]);
      this.budgetGroupForm.get('countryId').setValidators([Validators.required]);
    } else {
      this.budgetGroupForm.get('locationName').removeValidators([Validators.required]);
      this.budgetGroupForm.get('street').removeValidators([Validators.required]);
      this.budgetGroupForm.get('houseNumber').removeValidators([Validators.required]);
      this.budgetGroupForm.get('zipCode').removeValidators([Validators.required]);
      this.budgetGroupForm.get('city').removeValidators([Validators.required]);
      this.budgetGroupForm.get('countryId').removeValidators([Validators.required]);
    }

    //Docs mentions that we need to call updateValueAndValidity to make sure the items validations are updated!
    this.budgetGroupForm.get('locationName').updateValueAndValidity();
    this.budgetGroupForm.get('street').updateValueAndValidity();
    this.budgetGroupForm.get('houseNumber').updateValueAndValidity();
    this.budgetGroupForm.get('zipCode').updateValueAndValidity();
    this.budgetGroupForm.get('city').updateValueAndValidity();
    this.budgetGroupForm.get('countryId').updateValueAndValidity();
  }

  getCategoryList(){
    this.apiService.getAllCategories().subscribe((data) => {
      this.categoryList = data.result;
    },
      (error) => {
        this.errorMessage = 'Unable to fetch dropdown data';
        this.showError();
      })
  }

  updatePayExtra(data: MatCheckboxChange){
    this.isPayExtra = data.checked;
  }

  // Toggle selection for a single faq group
  toggleSelection(id: number) {
    if (this.selectedBudgetGroups.has(id)) {
      this.selectedBudgetGroups.delete(id); // Unselect
    } else {
      this.selectedBudgetGroups.set(id, true); // Select
    }
    this.updateSelectAllState();
  }

  // Toggle Select All
  toggleSelectAll() {
    if (this.allSelected) {
      this.selectedBudgetGroups.clear(); // Unselect all
    } else {
      this.budgetGroupArray.forEach((brand) =>
        this.selectedBudgetGroups.set(brand.id, true)
      ); // Select all
    }
    this.allSelected = !this.allSelected;
  }

  // Update the "Select All" checkbox state
  updateSelectAllState() {
    this.allSelected =
      this.selectedBudgetGroups.size === this.budgetGroupArray.length;
  }

  //get selectedBudgetGroups' Ids
  getSelectedBudgetGroupIds(): number[] {
    return Array.from(this.selectedBudgetGroups.entries()) // Convert Map to an array of key-value pairs
      .filter(([id, isSelected]) => isSelected) // Filter selected BudgetGroup
      .map(([id]) => id); // Extract only the IDs
  }

  /**
   * Deletes the selected budget groups by sending their IDs to the API.
   *
   * This method retrieves the IDs of the selected budget groups, sends them to the API service to delete the budget groups,
   * and handles the response. On successful deletion, it clears the selected budget groups, refreshes the budget groups list,
   * and shows a success message. On failure, it sets an error message and shows an error message.
   */
  deleteBudgetGroups() {
    this.apiService
      .deleteBudgetGroup(this.getSelectedBudgetGroupIds())
      .subscribe(
        (response) => {
          if (response.requestResult == 1) {
            this.selectedBudgetGroups = new Map();
            this.getAllbudgetGroups();
            this.showSuccess('delete');
          } else {
            this.errorMessage = response.responseTip;
            this.showError();
          }
        },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        }
      );
  }

  /**
   * Fetches all budget groups based on the current pagination, sorting, and search query parameters.
   * Updates the budget group array, pagination properties, and handles any errors by displaying an error message.
   */
  getAllbudgetGroups() {
    const params = {
      sortColumn: this.sortColumn,
      pageIndex: this.pageIndex,
      pageSize: this.pageSize,
      sortOrder: this.sortOrder,
      searchQuery: this.searchQuery,
    };
    this.apiService.getBudgetGroups(params).subscribe(
      (data) => {
        this.isDataLoaded = true;
        this.budgetGroupArray = data.result.data;
        this.pageIndex = data.result.pageIndex;
        this.pageSize = data.result.pageSize;
        this.totalCount = data.result.count;
      },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      }
    );
  }

  showSuccess(type: string) {
    const message = this.getSuccessMessage(type);
    this.toastr.success(message, 'Success!');
  }

  //get success message based on type
  getSuccessMessage(type: string) {
    switch (type) {
      case 'create':
        return 'Budget Group created successfully.';
        break;
      case 'update':
        return 'Budget Group updated successfully.';
        break;
      case 'delete':
        return 'Budget Group deleted successfully.';
        break;
      case 'copy':
        return 'Budget Group copied successfully.';
        break;
    }
  }
  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }

  // Triggers a search operation with the provided query string.
  onSearch(query: string): void {
    this.createBudgetGroup = false;
    this.closeDetails();
    this.searchSubject.next(query);
  }

  // Handle pagination changes
  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.getAllbudgetGroups();
  }

  /**
   * Toggles the visibility of the create budget group form.
   *
   * When the form is toggled to be visible, it initializes a new product object with default values,
   * sets it as the selected product, fills the form with the new product's values, and marks the
   * change detector for check to update the view.
   *
   * When the form is toggled to be hidden, it resets the form.
   */
  togglecreateBudgetGroupForm() {
    this.houseOrCompany = false;
    this.createBudgetGroup = !this.createBudgetGroup;
    if (this.createBudgetGroup) {
      const newProduct = {
        id: 0,
        name: null,
        street: null,
        houseNumber: null,
        zipCode: null,
        city: null,
        isDeliveryToCompany: this.houseOrCompany,
        budget: null,
        payExtra: false,
        mailConfirmationOrder: false,
        orderOnHoldDate: null,
        orderOnHoldTime: '',
        companyDelivery: null,
        personalDelivery: null,
        countryId: null,
        locationName: null,
        budgetChristmasFair: null,
        isFairTimeChecked: false,
        isFairDateChecked: false,
        isFairLocationChecked: false,
        budgetCode: null,
        categoryIds: [],
        maxProductPrice: null,
        shopLimit: null
      };
      // Go to new product
      this.selectedProduct = newProduct;

      // Fill the form
      this.budgetGroupForm.patchValue(newProduct);

      // Mark for check
      this._changeDetectorRef.markForCheck();
    } else {
      this.budgetGroupForm.reset();
    }
  }

  /**
   * Adds a new budget group if the form is valid. The method collects form data,
   * appends it to a FormData object, and sends it to the API service to create a new budget group.
   * If the creation is successful, it refreshes the budget groups list, resets the form, closes the details view,
   * and shows a success message. If the creation fails, it shows an error message.
   * If the form is invalid, it marks all form fields as touched.
   */
  addBudgetGroup() {
    if (this.budgetGroupForm.valid) {
      const budgetGroup = this.budgetGroupForm.getRawValue();
      if(!budgetGroup.budget && !budgetGroup.budgetChristmasFair){
        this.errorMessage = "Both budget and christmas fair budget can't be empty";
        this.showError();
        return
      }
      var formData = new FormData();
      const appendIfNotNull = (key: string, value: any) => {
        if (value !== null && value !== undefined) {
          formData.append(key, value);
        }
      };
      formData.append('Name', budgetGroup.name);
      appendIfNotNull('Street', budgetGroup.street);
      appendIfNotNull('HouseNumber', budgetGroup.houseNumber);
      appendIfNotNull('ZipCode', budgetGroup.zipCode);
      appendIfNotNull('City', budgetGroup.city);
      appendIfNotNull('IsDeliveryToCompany', this.houseOrCompany);
      appendIfNotNull('Budget', budgetGroup.budget);
      appendIfNotNull('PayExtra', budgetGroup.payExtra);
      appendIfNotNull('MailConfirmationOrder', budgetGroup.mailConfirmationOrder);

      if (budgetGroup.orderOnHoldDate) {
        budgetGroup.orderOnHoldDate = CommonHelperService.GenerateISODateTimeString(budgetGroup.orderOnHoldDate, budgetGroup.orderOnHoldTime as string);
      }
      appendIfNotNull('OrderOnHoldDate', budgetGroup.orderOnHoldDate);
      this.houseOrCompany 
        ? appendIfNotNull('CompanyDelivery', budgetGroup.companyDelivery)
        : appendIfNotNull('PersonalDelivery', budgetGroup.personalDelivery);
      appendIfNotNull('CountryId', budgetGroup.countryId);
      appendIfNotNull('LocationName', budgetGroup.locationName);
      appendIfNotNull('BudgetChristmasFair', budgetGroup.budgetChristmasFair);
      appendIfNotNull('FairTimeChecked', budgetGroup.isFairTimeChecked);
      appendIfNotNull('FairDateChecked', budgetGroup.isFairDateChecked);
      appendIfNotNull('FairLocationChecked', budgetGroup.isFairLocationChecked);
      appendIfNotNull('BudgetCode', budgetGroup.budgetCode);
      appendIfNotNull('ShopLimit', budgetGroup.shopLimit);
      appendIfNotNull('MaxProductPrice', budgetGroup.maxProductPrice);
      // appendIfNotNull('CategoryIds', budgetGroup.categoryIds);

      if(budgetGroup.categoryIds && budgetGroup.categoryIds.length > 0){
       
        budgetGroup.categoryIds.forEach((category, index) => {
          formData.append(`CategoryIds[${index}]`, category.toString());
        });
      }

      this.apiService.createBudgetGroup(formData).subscribe(
        (data) => {
          if (data.requestResult == 1) {
            this.getAllbudgetGroups();
            this.resetForm();
            this.closeDetails();
            this.createBudgetGroup = false;
            this.showSuccess('create');
          } else {
            this.errorMessage = data.responseTip;
            this.showError();
          }
        },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        }
      );
    } else {
      this.budgetGroupForm.markAllAsTouched();
      this.errorMessage = 'Please fill all the required fields';
      this.showError();
      setTimeout(() => {
        this.budgetGroupForm.get('budget').reset();
        this.budgetGroupForm.get('budgetChristmasFair').reset();
      }, 1000);
    }
  }

  /**
   * Updates the budget group with the form data if the form is valid.
   *
   * This method collects the form data, appends it to a FormData object,
   * and sends it to the API service to update the budget group. If the
   * update is successful, it refreshes the budget groups list, resets the
   * form, closes the details view, and shows a success message. If the
   * update fails, it shows an error message.
   *
   * @remarks
   * - The form data is appended to the FormData object only if the values are not null or undefined.
   * - The API service method `updateBudgtGroup` is used to send the form data.
   * - The method handles both success and error responses from the API.
   * - If the form is invalid, all form fields are marked as touched to show validation errors.
   */
  updateBudgetGroup() {
    if (this.budgetGroupForm.valid) {
      const budgetGroup = this.budgetGroupForm.getRawValue();
      if(!budgetGroup.budget && !budgetGroup.budgetChristmasFair){
        this.errorMessage = "Both budget and christmas fair budget can't be empty";
        this.showError();
        return
      }
      var formData = new FormData();

      //append the form field if the value is not null
      const appendIfNotNull = (key: string, value: any) => {
        if (value !== null && value !== undefined) {
          formData.append(key, value);
        }
      };
      formData.append('Id', this.selectedProduct.id.toString());
      formData.append('Name', budgetGroup.name);
      appendIfNotNull('Street', budgetGroup.street);
      appendIfNotNull('HouseNumber', budgetGroup.houseNumber);
      appendIfNotNull('ZipCode', budgetGroup.zipCode);
      appendIfNotNull('City', budgetGroup.city);
      appendIfNotNull('IsDeliveryToCompany', this.houseOrCompany);
      appendIfNotNull('Budget', budgetGroup.budget);
      appendIfNotNull('PayExtra', budgetGroup.payExtra);
      appendIfNotNull(
        'MailConfirmationOrder',
        budgetGroup.mailConfirmationOrder
      );

      if (budgetGroup.orderOnHoldDate) {
        budgetGroup.orderOnHoldDate = CommonHelperService.GenerateISODateTimeString(budgetGroup.orderOnHoldDate, budgetGroup.orderOnHoldTime);
      }

      appendIfNotNull('OrderOnHoldDate', budgetGroup.orderOnHoldDate);
      this.houseOrCompany 
        ? appendIfNotNull('CompanyDelivery', budgetGroup.companyDelivery)
        : appendIfNotNull('PersonalDelivery', budgetGroup.personalDelivery);
      appendIfNotNull('CountryId', budgetGroup.countryId);
      appendIfNotNull('LocationName', budgetGroup.locationName);
      appendIfNotNull('BudgetChristmasFair', budgetGroup.budgetChristmasFair);
      appendIfNotNull('FairTimeChecked', budgetGroup.isFairTimeChecked);
      appendIfNotNull('FairDateChecked', budgetGroup.isFairDateChecked);
      appendIfNotNull('FairLocationChecked', budgetGroup.isFairLocationChecked);
      appendIfNotNull('BudgetCode', budgetGroup.budgetCode);
      appendIfNotNull('ShopLimit', budgetGroup.shopLimit);
      appendIfNotNull('MaxProductPrice', budgetGroup.maxProductPrice);

      if(budgetGroup.categoryIds && budgetGroup.categoryIds.length > 0){
        budgetGroup.categoryIds.forEach((category, index) => {
          formData.append(`CategoryIds[${index}]`, category.toString());
        });
      }

      this.apiService.updateBudgtGroup(formData).subscribe(
        (data) => {
          if (data.requestResult == 1) {
            this.getAllbudgetGroups();
            this.resetForm();
            this.closeDetails();
            this.showSuccess('update');
          } else {
            this.errorMessage = data.responseTip;
            this.showError();
          }
        },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        }
      );
    } else {
      this.budgetGroupForm.markAllAsTouched();
      this.errorMessage = 'Please fill all the required fields';
      this.showError();
      this.budgetGroupForm.get('budget').reset();
      this.budgetGroupForm.get('budgetChristmasFair').reset();

    }
  }

  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * Opens a dialog with a form and handles the result after the dialog is closed.
   *
   * @param id - The identifier of the budget group to be copied.
   *
   * The dialog allows the user to input a new name for the budget group.
   * If the dialog is closed with a result containing a name, the `copyBudgetGroup` method is called with the provided id and name.
   */
  openDialog(id: number) {
    const dialogRef = this.dialog.open(DialogWithForm,{
      data: { showKeepProduct: false },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result && result.name) {
        this.copyBudgetGroup(id, result.name);
      }
    });
  }

  /**
   * Copies a budget group by sending its ID and name to the API.
   *
   * @param id - The ID of the budget group to copy.
   * @param name - The name of the budget group to copy.
   *
   * This method creates a FormData object with the provided ID and name,
   * then calls the `copyBudgetGroup` method of the `apiService` to copy the budget group.
   *
   * On success, it refreshes the list of budget groups and shows a success message.
   * On failure, it sets an error message and shows an error message.
   */
  copyBudgetGroup(id: number, name: string) {
    const formData = new FormData();
    formData.append('Id', id.toString());
    formData.append('Name', name);

    this.apiService.copyBudgetGroup(formData).subscribe(
      (data) => {
        if (data.requestResult == 1) {
          this.getAllbudgetGroups();
          this.showSuccess('copy');
        } else {
          this.errorMessage = data.responseTip;
          this.showError();
        }
      },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      }
    );
  }

  /**
   * After view init
   */
  ngAfterViewInit(): void {
    if (this._sort && this._paginator) {
      setTimeout(() => {
        // Set the initial sort
        this._sort.sort({
          id: 'id',
          start: 'desc',
          disableClear: true,
        });
      });

      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;
          this.pageIndex = 0;
          //reset and close the form if it is open
          this.resetForm();
          this.closeDetails();

          // set the sort column and sort order
          this.sortColumn = this.getSortColumn(this._sort.active);
          this.sortOrder = this._sort.direction === 'asc' ? 2 : 1;

          // Close the details
          this.closeDetails();

          //get all the budget groups
          this.getAllbudgetGroups();
        });
    }
  }

  getAllCountries() {
    this.apiService.getAllCountries().subscribe(
      (data) => {
        this.countryList = data.result;
      },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      }
    );
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

  /**
   * Returns the sort column index based on the provided column name.
   *
   * @param {string} name - The name of the column to get the sort index for.
   * @returns {number} The index of the sort column. Returns 0 if the column name is not recognized.
   *
   * @example
   * ```typescript
   * const index = getSortColumn('name'); // returns 1
   * const unknownIndex = getSortColumn('unknown'); // returns 0 , 0 means id
   * ```
   */
  getSortColumn(name: string) {
    switch (name) {
      case 'name':
        return 1;
        break;
      case 'houseCompany':
        return 2;
        break;
      case 'fairBudget':
        return 3;
        break;
      case 'budget':
        return 4;
        break;
      case 'payExtra':
        return 5;
        break;
      case 'orderOnHold':
        return 6;
        break;
      case 'mailConfirmation':
        return 7;
        break;
      default:
        return 0;
    }
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggles the display of BudgetGroup details based on the provided BudgetGroup ID.
   * If the BudgetGroup is already selected, it closes the details.
   * Otherwise, it selects the BudgetGroup and updates the form with the BudgetGroup's details.
   *
   * @param {number} id - The ID of the BudgetGroup to toggle details for.
   * @returns {void}
   */
  toggleDetails(id: number): void {
    //close create form if it is opened
    this.createBudgetGroup = false;
    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct.id === id) {
      // Close the details
      this.closeDetails();
      return;
    }

    const myMap = new Map(this.budgetGroupArray.map((obj) => [obj.id, obj]));

    this.selectedProduct = myMap.get(id);

    this.selectedProduct.orderOnHoldTime = CommonHelperService.GetTimeStampFromDateTime(this.selectedProduct.orderOnHoldDate?.toString());
    
    this.houseOrCompany = this.selectedProduct.isDeliveryToCompany;
    this.budgetGroupForm.patchValue(this.selectedProduct);
  }

  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
  }

  resetForm() {
    this.budgetGroupForm.reset();
  }

  /**
   * Cycle through images of selected product
   */
  cycleImages(forward: boolean = true): void {
    // Get the image count and current image index
    const count = this.budgetGroupForm.get('images').value.length;
    const currentIndex = this.budgetGroupForm.get('currentImageIndex').value;

    // Calculate the next and previous index
    const nextIndex = currentIndex + 1 === count ? 0 : currentIndex + 1;
    const prevIndex = currentIndex - 1 < 0 ? count - 1 : currentIndex - 1;

    // If cycling forward...
    if (forward) {
      this.budgetGroupForm.get('currentImageIndex').setValue(nextIndex);
    }
    // If cycling backwards...
    else {
      this.budgetGroupForm.get('currentImageIndex').setValue(prevIndex);
    }
  }

  /**
   * Toggle the tags edit mode
   */
  toggleTagsEditMode(): void {
    this.tagsEditMode = !this.tagsEditMode;
  }

  /**
   * Filter tags
   *
   * @param event
   */
  filterTags(event): void {
    // Get the value
    const value = event.target.value.toLowerCase();

    // Filter the tags
    this.filteredTags = this.tags.filter((tag) =>
      tag.title.toLowerCase().includes(value)
    );
  }

  /**
   * Filter tags input key down event
   *
   * @param event
   */
  // filterTagsInputKeyDown(event): void {
  //   // Return if the pressed key is not 'Enter'
  //   if (event.key !== 'Enter') {
  //     return;
  //   }

  //   // If there is no tag available...
  //   if (this.filteredTags.length === 0) {
  //     // Create the tag
  //     this.createTag(event.target.value);

  //     // Clear the input
  //     event.target.value = '';

  //     // Return
  //     return;
  //   }

  //   // If there is a tag...
  //   const tag = this.filteredTags[0];
  //   const isTagApplied = this.selectedProduct.tags.find((id) => id === tag.id);

  //   // If the found tag is already applied to the product...
  //   if (isTagApplied) {
  //     // Remove the tag from the product
  //     this.removeTagFromProduct(tag);
  //   } else {
  //     // Otherwise add the tag to the product
  //     this.addTagToProduct(tag);
  //   }
  // }

  /**
   * Create a new tag
   *
   * @param title
   */
  // createTag(title: string): void {
  //   const tag = {
  //     title,
  //   };

  //   // Create tag on the server
  //   this._inventoryService.createTag(tag).subscribe((response) => {
  //     // Add the tag to the product
  //     this.addTagToProduct(response);
  //   });
  // }

  /**
   * Update the tag title
   *
   * @param tag
   * @param event
   */
  // updateTagTitle(tag: InventoryTag, event): void {
  //   // Update the title on the tag
  //   tag.title = event.target.value;

  //   // Update the tag on the server
  //   this._inventoryService
  //     .updateTag(tag.id, tag)
  //     .pipe(debounceTime(300))
  //     .subscribe();

  //   // Mark for check
  //   this._changeDetectorRef.markForCheck();
  // }

  /**
   * Delete the tag
   *
   * @param tag
   */
  // deleteTag(tag: InventoryTag): void {
  //   // Delete the tag from the server
  //   this._inventoryService.deleteTag(tag.id).subscribe();

  //   // Mark for check
  //   this._changeDetectorRef.markForCheck();
  // }

  /**
   * Add tag to the product
   *
   * @param tag
   */
  // addTagToProduct(tag: InventoryTag): void {
  //   // Add the tag
  //   this.selectedProduct.tags.unshift(tag.id);

  //   // Update the selected product form
  //   this.budgetGroupForm.get('tags').patchValue(this.selectedProduct.tags);

  //   // Mark for check
  //   this._changeDetectorRef.markForCheck();
  // }

  /**
   * Remove tag from the product
   *
   * @param tag
   */
  // removeTagFromProduct(tag: InventoryTag): void {
  //   // Remove the tag
  //   this.selectedProduct.tags.splice(
  //     this.selectedProduct.tags.findIndex((item) => item === tag.id),
  //     1
  //   );

  //   // Update the selected product form
  //   this.budgetGroupForm.get('tags').patchValue(this.selectedProduct.tags);

  //   // Mark for check
  //   this._changeDetectorRef.markForCheck();
  // }

  /**
   * Toggle product tag
   *
   * @param tag
   * @param change
   */
  // toggleProductTag(tag: InventoryTag, change: MatCheckboxChange): void {
  //   if (change.checked) {
  //     this.addTagToProduct(tag);
  //   } else {
  //     this.removeTagFromProduct(tag);
  //   }
  // }

  /**
   * Should the create tag button be visible
   *
   * @param inputValue
   */
  shouldShowCreateTagButton(inputValue: string): boolean {
    return !!!(
      inputValue === '' ||
      this.tags.findIndex(
        (tag) => tag.title.toLowerCase() === inputValue.toLowerCase()
      ) > -1
    );
  }

  /**
   * Create product
   */
  // createProduct(): void {
  //   // Create the product
  //   this._inventoryService.createProduct().subscribe((newProduct) => {
  //     // Go to new product
  //     this.selectedProduct = newProduct;

  //     // Fill the form
  //     this.budgetGroupForm.patchValue(newProduct);

  //     // Mark for check
  //     this._changeDetectorRef.markForCheck();
  //   });
  // }

  /**
   * Update the selected product using the form data
   */
  updateSelectedProduct(): void {
    // Get the product object
    const product = this.budgetGroupForm.getRawValue();

    // Remove the currentImageIndex field
    delete product.currentImageIndex;

    // Update the product on the server
    this._inventoryService.updateProduct(product.id, product).subscribe(() => {
      // Show a success message
      this.showFlashMessage('success');
    });
  }

  /**
   * Delete the selected product using the form data
   */
  async deleteSelectedProduct(id: number | null, isFromDeleteBtn = false): Promise<void> {

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Budget Group');

    if (!confirmed) {
      return;
    }

    if (!isFromDeleteBtn) {
      this.selectedBudgetGroups.clear();
      this.selectedBudgetGroups.set(id, true)
    }

    this.deleteBudgetGroups();

    this.closeDetails();
  }

  /**
   * Show flash message
   */
  showFlashMessage(type: 'success' | 'error'): void {
    // Show the message
    this.flashMessage = type;

    // Mark for check
    this._changeDetectorRef.markForCheck();

    // Hide it after 3 seconds
    setTimeout(() => {
      this.flashMessage = null;

      // Mark for check
      this._changeDetectorRef.markForCheck();
    }, 3000);
  }

  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }

  checkAll = true;
  toggleCheckAll() {
    this.checkAll = !this.checkAll;
  }

  onSelectionChange(value: any) {
    if(value && value !=''){
        this.budgetGroupForm.get(value).markAsTouched();      
    }
  }
}

