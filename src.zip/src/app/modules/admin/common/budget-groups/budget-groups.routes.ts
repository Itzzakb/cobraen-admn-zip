import { Routes } from "@angular/router";
import { BudgetGroupsComponent } from "./budget-groups.component";

export default[
   {
    path: '',
    component: BudgetGroupsComponent
   }
] as Routes