import {
  AsyncPipe,
  CommonModule,
  CurrencyPipe,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormControl,
  FormsModule,
  NgModel,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatCheckboxChange,
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { InventoryService } from 'app/shared/services/inventory.service';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatRadioModule } from '@angular/material/radio';
import { MatTooltipModule } from '@angular/material/tooltip';

import {
  InventoryBrand,
  InventoryCategory,
  InventoryPagination,
  InventoryProduct,
  InventoryTag,
  InventoryVendor,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  map,
  merge,
  switchMap,
  takeUntil,
} from 'rxjs';
import { CommonDropdownItem, GiftsetImage, Image, ImageLibraryContent, Product, productImage, productList, ProductPageDropdownList, ProductPrice } from 'app/shared/types/interfaces';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { set } from 'lodash-es';
import { SearchableDropdownComponent } from 'app/shared/components/searchable-dropdown/searchable-dropdown.component';
import { ImageLibraryDialog } from 'app/shared/components/image-library/image-library.component';
import { MatDialog } from '@angular/material/dialog';
import { DeleteConfirmationService, DeleteTypes } from 'app/shared/services/delete-confirmation.service';


@Component({
  selector: 'app-products',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 1fr 1fr 1fr 1fr 1fr 1fr 136px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 1fr 1fr 1fr 1fr 1fr 1fr 136px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 1fr 1fr 1fr 1fr 1fr 1fr 136px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 1fr 1fr 1fr 1fr 1fr 1fr 136px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    MatRadioModule,
    MatTooltipModule,
    CommonModule,
    SearchableDropdownComponent
  ],
  templateUrl: './products.component.html',
  styleUrl: './products.component.scss',
})
export class ProductsComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  products$: Observable<InventoryProduct[]>;

  brands: InventoryBrand[];
  categories: InventoryCategory[];
  filteredTags: InventoryTag[];
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: InventoryPagination;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: Product | null = null;
  selectedProductForm: UntypedFormGroup;
  tags: InventoryTag[];
  tagsEditMode: boolean = false;
  vendors: InventoryVendor[];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  productsArray: Product[] = [];
  selectedProducts: Map<number, boolean> = new Map(); // Tracks selected Products
  allSelected: boolean = false;

  searchQuery: string = '';
  searchSubject = new Subject<string>();
  searchSubscription: any;

  videoUrl: string = '';

  // Pagination properties
  pageIndex: number = 0;
  pageSize: number = 10;
  totalCount: number = 0;
  sortOrder: number = 1;
  sortColumn: number = 0;

  createProduct = false;

  indexImg: string = '';
  detailImg: string = '';
  indexImgFile: File | null = null;
  detailImgFile: File | null = null;

  errorMessage = '';

  selectedProductPrice: ProductPrice = null; 
  selectedProductPriceList: ProductPrice[] = []; 

  categoriesList: CommonDropdownItem[] = [];
  brandsList: CommonDropdownItem[] = [];
  characteristicsList: CommonDropdownItem[] = [];
  vatsList: CommonDropdownItem[] = [];
  partnersList: CommonDropdownItem[] = [];
  productList: productList[] = [];
  budgetGroupsList: CommonDropdownItem[] = [];


  selectedCategory: number | null = null;
  selectedBrand: number | null = null;
  selectedCharacteristic: number | null = null;
  selectedVat: number | null = null;
  selectedPartner: number | null = null;
  selectedStatus: number | null = null;

  productImages: productImage[] = [];
  existingImages: Image[] = [];
  LibraryImages:GiftsetImage[] = [];
  selectedThumbnailIndex: number = -1;

  videos: string[] = [];
  images: GiftsetImage[] = [];
  mappedProducts: number[] = [];
  selectedMappedProducts: CommonDropdownItem[] = [];

  inlineEditData: string | number = '';
  isInlineEdit: boolean = false;
  editField: string = '';
  selectedProductId: number | null = null;

  selectedProductPriceForm: UntypedFormGroup;
  createProductPrice: boolean = false;
  isDataLoaded: boolean = false;
  @ViewChild('headerPaginator') headerPaginator!: MatPaginator;
  @ViewChild('footerPaginator') footerPaginator!: MatPaginator;

  videoUrlError: boolean = false;  

  dummyProduct: Product = {
  id: 1,
  importId: "IMP-001",
  externalProductId: "EXT-001",
  supplierId: "SUP-001",
  published: true,
  title: "Sample Product",
  titleEng: "Sample Product (EN)",
  longDesc: "This is a sample product description.",
  longDescEng: "This is a sample product description in English.",
  addtionalText: "Additional information about the product.",
  partner: 123,
  stock: 50,
  stockIncludingExtraOrder: 60,
  dukatenExc: 100,
  dukatenInc: 120,
  vatId: 1,
  brandId: 2,
  category: 3,
  productPrices: [
    {
      productPriceId: 1,
      dukatenExc: 100,
      dukatenInc: 120,
      budgetGroupIds: [1, 2]
    }
  ],
  categories: [3, 4],
  characteristics: [5, 6],
  mappedProducts: [7, 8],
  videos: [
    "https://www.example.com/video-placeholder.mp4"
  ],
  images: [
    {
      fileName: "placeholder.jpg",
      imageUrl: "https://via.placeholder.com/300x200.png?text=Product+Image",
      thumbnail: true
    },
    {
      fileName: "placeholder2.jpg",
      imageUrl: "https://via.placeholder.com/100x100.png?text=Thumbnail",
      thumbnail: false
    }
  ]
};


  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _deleteConfirmationService: DeleteConfirmationService,
    private _formBuilder: UntypedFormBuilder,
    private apiService: ApiService,
    private toastr: ToastrService,
    private dialog: MatDialog
  ) {}

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.selectedProductForm = this._formBuilder.group({
      id: [''],
      importId: ['', [Validators.required]],
      externalProductId: [''],
      supplierId: [''],
      published: [false],
      title: ['', [Validators.required]],
      titleEng: ['', [Validators.required]],
      longDesc: [''],
      longDescEng: [''],
      addtionalText: [''],
      partner: ['', [Validators.required]],
      stock: ['', [Validators.required]],
      stockIncludingExtraOrder: [''],
      dukatenExc: ['', [Validators.required]],
      dukatenInc: ['', [Validators.required]],
      vatId: ['', [Validators.required]],
      brandId: [''],
      category: [''],
      categories: [[], [Validators.required]],
      productPrices: [[]], // Image index that is currently being viewed
      characteristics: [[]],
      mappedProducts: [[]],
      videos: [[]],
      images: [[]],
    });

    this.selectedProductPriceForm = this._formBuilder.group({
      productPriceId: [''],
      dukatenExc: ['', [Validators.required, Validators.pattern('^[0-9.]+$')]],
      dukatenInc: ['', [Validators.required, Validators.pattern('^[0-9.]+$')]],
      budgetGroupIds: [[], [Validators.required]]
    });

    

    // get all dropdown data
    this.getDropdownList();

    // get all product list
    this.getProductList();

    // Debounce search input to optimize API calls
    this.searchSubscription = this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe((query) => {
        this.searchQuery = query;
        this.pageIndex = 0; // Reset to first page on new search
        this.footerPaginator.firstPage();
        this.getAllProducts();
      });
  }

  videoUrlFormControl = new FormControl('', [
    Validators.pattern(
      '^https?:\\/\\/([\\w-]+\\.)+[\\w-]+(\\/[\\w\\-._~:/?#[\\]@!$&\'()*+,;=]*)?$'
    ),]);


  // Toggle selection for a single brand
  toggleSelection(brandId: number) {
    if (this.selectedProducts.has(brandId)) {
      this.selectedProducts.delete(brandId); // Unselect
    } else {
      this.selectedProducts.set(brandId, true); // Select
    }
    this.updateSelectAllState();
  }

  // Toggle Select All
  toggleSelectAll() {
    if (this.allSelected) {
      this.selectedProducts.clear(); // Unselect all
    } else {
      this.productsArray.forEach((brand) =>
        this.selectedProducts.set(brand.id, true)
      ); // Select all
    }
    this.allSelected = !this.allSelected;
  }

  // Update the "Select All" checkbox state
  updateSelectAllState() {
    this.allSelected = this.selectedProducts.size === this.productsArray.length;
  }

  toggleInlineEdit(id: number, field: string) {
    const myMap = new Map(this.productsArray.map((obj) => [obj.id, obj]));
    this.selectedProduct = myMap.get(id);

    let modifiedImages = this.selectedProduct.images.map(image => ({
      ...image,
      isLibraryImage: false
    }));
    this.selectedProductForm.patchValue(this.selectedProduct);
    this.images = modifiedImages;
    this.videos = this.selectedProduct.videos;
    this.initializeImages(this.images);

    this.editField = field;
    this.selectedProductId = id;
    this.inlineEditData = this.selectedProduct[field];
    this.isInlineEdit = true;
  }

  resetInlineEdit() {
    this.editField = '';
    this.selectedProductId = null;
    this.inlineEditData = '';
    this.isInlineEdit = false;
  }

  editInlineData(field: string) {
    this.selectedProductForm.patchValue({
      [field]: this.inlineEditData,
    });
    this.updateProduct();
  }

  //get selectedProducts' Ids
  getSelectedProductIds(): number[] {
    return Array.from(this.selectedProducts.entries()) // Convert Map to an array of key-value pairs
      .filter(([id, isSelected]) => isSelected) // Filter selected brands
      .map(([id]) => id); // Extract only the IDs
  }
  //Deletes the selected Brand entries by calling the API service. If the deletion is successful, it clears the selected Brands map.
  deleteProducts() {
    this.apiService.deleteProduct(this.getSelectedProductIds()).subscribe(
      (response) => {
        if (response.requestResult == 1) {
          this.selectedProducts = new Map();
          this.getAllProducts();
          this.showSuccess('delete');
        } else {
          this.errorMessage = response.responseTip;
          this.showError();
        }
      },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      }
    );
  }

  getDropdownList() {
   
    // this.apiService.getAllDropdownData(this.apiService.dropdownType.PRODUCT_SCREEN_DROPDOWNS).subscribe(
    //   (data) => {
    //     let allDropdownList = data.result;

    //     this.categoriesList = allDropdownList.categories?.data || [];
    //     this.brandsList = allDropdownList.brands?.data || [];
    //     this.characteristicsList = allDropdownList.characteristics?.data || [];
    //     this.vatsList = allDropdownList.vats?.data || [];
    //     //To bind partner shopname for partners instead of name
    //     this.partnersList = allDropdownList.partners?.data.map((x) => { return { id: x.id, name: x.shopName ?? x.name } }) || [];
    //     this.budgetGroupsList = allDropdownList.budgetGroups?.data || [];
        
    //   },
    //   (error) => {
    //     this.errorMessage = 'Unable to fetch dropdown data';
    //     this.showError();
    //   }
    // );
  }

  getProductList() {
    // this.apiService.getAllProducts().subscribe(
    //   (data) => {
    //     this.productList = this.dummyProduct ? [this.dummyProduct] : data.result.data;
    //   },
    //   (error) => {
    //     this.errorMessage = 'Unable to fetch products data';
    //     this.showError();
    //   }
    // );
  }

  // get all brands
  getAllProducts() {
    // const params = {
    //   sortColumn: this.sortColumn,
    //   pageIndex: this.pageIndex,
    //   pageSize: this.pageSize,
    //   sortOrder: this.sortOrder,
    //   searchQuery: this.searchQuery,
    //   categoryId: this.selectedCategory,
    //   brandId: this.selectedBrand,
    //   partnerId: this.selectedPartner,
    //   status: this.selectedStatus,
    // };
    // this.apiService.getProducts(params).subscribe((data) => {
    //   this.productsArray = this.dummyProduct ? [this.dummyProduct] : data.result.data;
    //   // this.productsArray = data.result.data;
    //   this.pageIndex = data.result.pageIndex;
    //   this.pageSize = data.result.pageSize;
    //   this.totalCount = data.result.count;
    //   this.isDataLoaded = true;
    // });

    this.productsArray = this.dummyProduct ? [this.dummyProduct] : [];

  }

  //Update Product Status
  updateStatus(id: number) {
    const formData = new FormData();
    formData.append('productId', id.toString());

    this.apiService.updateProductStatus(formData).subscribe(
      (data) => {
        if (data.requestResult == 1) {
          this.showSuccess('statusUpdate');
          this.getAllProducts();
        } else {
          this.errorMessage = data.responseTip;
          this.showError();
        }
      },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      }
    );
  }

  getBrandName(id: number): string {
    const brand = this.brandsList.find((brand) => brand.id === id);
    return brand ? brand.name : '';
  }

  getBudgetGroupsName(ids: number[]){
    let budgetGroupNames: string = '';
    ids.forEach((id) => {
      const budgetGroup = this.budgetGroupsList.find((budgetGroup) => budgetGroup.id === id);
      if (budgetGroup) {
        budgetGroupNames += budgetGroup.name + ', ';
      }
    }

    );
    return budgetGroupNames.slice(0, -2); // Remove the last comma and space   
  }

  getCategoryName(ids: number[]): string {
    let categoryNames: string = '';
    ids.forEach((id) => {
      const category = this.categoriesList.find(
        (category) => category.id === id
      );
      if (category) {
        categoryNames += category.name + ', ';
      }
    });
    return categoryNames.slice(0, -2); // Remove the last comma and space
  }

  getPartnerName(id: number): string {
    const partner = this.partnersList.find((partner) => partner.id === id);
    return partner ? partner.name : '';
  }

  getImageFileName(filePath: string | File): string {
    if (filePath instanceof File) {
      return filePath.name; // Return the file name directly if it's a File object
    } else {
      return filePath;
    }
  }

  getMappedProducts(ids: number[]) {
    this.selectedMappedProducts = this.productList.filter((product) =>
      ids.includes(product.id)
    );
  }

  removeFromMappedProductLIst(id: number) {
    this.selectedMappedProducts = this.selectedMappedProducts.filter(
      (product) => product.id != id
    );
  }

  showSuccess(type: string) {
    const message = this.getSuccessMessage(type);
    this.toastr.success(message, 'Success!');
  }
  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }

  //get success message based on type
  getSuccessMessage(type: string) {
    switch (type) {
      case 'create':
        return 'Product created successfully.';
        break;
      case 'update':
        return 'Product updated successfully.';
        break;
      case 'delete':
        return 'Product deleted successfully.';
        break;
      case 'statusUpdate':
        return 'Product status updated successfully.';
        break;
    }
  }

  // Triggers a search operation with the provided query string.
  onSearch(query: string): void {
    this.createProduct = false;
    this.closeDetails();
    this.searchSubject.next(query);
  }

  // Handle pagination changes
  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.getAllProducts();
  }

  toggleCreateProductForm() {
    //close the edit form if open
    this.closeDetails();
    this.createProductPrice = true;

    this.createProduct = !this.createProduct;
    if (this.createProduct) {
      const newProduct = {
        id: null,
        importId: '',
        externalProductId: '',
        supplierId: '',
        published: false,
        title: '',
        titleEng: '',
        longDesc: '',
        longDescEng: '',
        addtionalText: '',
        partner: null,
        stock: null,
        stockIncludingExtraOrder: null,
        dukatenExc: null,
        dukatenInc: null,
        vatId: null,
        brandId: null,
        category: null,
        productPrices: null,
        categories: null,
        characteristics: null,
        mappedProducts: null,
        videos: null,
        images: null,
      };
      // Go to new product
      this.selectedProduct = newProduct;

      // Fill the form
      this.selectedProductForm.patchValue(newProduct);

      // Mark for check
      this._changeDetectorRef.markForCheck();
    } else {
      this.selectedProductForm.reset();
    }
  }

  toggleCreateProductPriceForm() {
    //close the edit form if open
    this.closeProductPriceDetails();

    this.createProductPrice = !this.createProductPrice;
    if (this.createProductPrice) {
      const newProduct = {
        productPriceId: null,
        dukatenExc: null,
        dukatenInc: null,
        budgetGroupIds: []
      }
      // Go to new product
      this.selectedProductPrice = newProduct;

      // Fill the form
      this.selectedProductPriceForm.patchValue(newProduct);

      // Mark for check
      this._changeDetectorRef.markForCheck();
    } else {
      this.selectedProductPriceForm.reset();
    }
  }

  addProduct() {
    if (this.selectedProductForm.valid) {
      this.separateImagesAccordingToTypes();
      const product = this.selectedProductForm.getRawValue();
      var formData = new FormData();
      
      // Required fields
      formData.append('ImportId', product.importId || '');
      formData.append('ExternalProductId', product.externalProductId || '');
      formData.append('SupplierId', product.supplierId || '');
      formData.append('Published', product.published.toString());
      formData.append('Title', product.title || '');
      formData.append('TitleEng', product.titleEng || '');
      formData.append('LongDesc', product.longDesc || '');
      formData.append('LongDescEng', product.longDescEng || '');
      formData.append('AddtionalText', product.addtionalText || '');
      formData.append('PartnerId', product.partner ? product.partner.toString() : '');
      formData.append('Stock', product.stock ? product.stock.toString() : '0');
      formData.append('DukatenExc', product.dukatenExc ? product.dukatenExc.toString() : '0');
      formData.append('DukatenInc', product.dukatenInc ? product.dukatenInc.toString() : '0');
      formData.append('VatId', product.vatId ? product.vatId.toString() : '');

      // Optional fields
      if (product.brandId) {
        formData.append('BrandId', product.brandId.toString());
      }

      
      if (this.productImages && this.productImages.length > 0) {
        let hasThumbnail = false;
        this.productImages.forEach((image: productImage, i: number) => {
          if (image.Image) {
            formData.append(
              `ProductImages[${i}].Image`,
              image.Image,
              image.Image.name
            );
            formData.append(
              `ProductImages[${i}].Thumbnail`,
              image.Thumbnail.toString()
            );
            if (image.Thumbnail) {
              hasThumbnail = true;
            }
          }
        });
        
       
        if (!hasThumbnail && this.productImages.length > 0 && this.productImages[0].Image) {
          formData.set(`ProductImages[0].Thumbnail`, 'true');
        }
      } 

      if (this.LibraryImages.length > 0) {
        this.LibraryImages.forEach((image: GiftsetImage, i: number) => {
          formData.append(`LibraryImages[${i}].UrlPath`, image.imageUrl);
          formData.append(`LibraryImages[${i}].FileName`, image.fileName);
          formData.append(`LibraryImages[${i}].Thumbnail`, image.thumbnail.toString());
        }
        );
      }
      
      
      if(this.productImages.length == 0 && this.LibraryImages.length == 0){
        this.errorMessage = 'At least one product image is required';
        this.showError();
        return;
      }

      

      // Handle videos
      if (this.videos && this.videos.length > 0) {
        this.videos.forEach((video: string) => {
          if (video) {
            formData.append('ProductVideos', video);
          }
        });
      }

      // Handle categories
      if (product.categories && product.categories.length > 0) {
        product.categories.forEach((category: number) => {
          if (category) {
            formData.append('ProductCategories', category.toString());
          }
        });
      } else {
        this.errorMessage = 'At least one product category is required';
        this.showError();
        return;
      }

      if (this.selectedProductPriceList && this.selectedProductPriceList.length > 0) {
        this.selectedProductPriceList.forEach((productPrice: ProductPrice, i: number) => {
         
          const dukatenExc = productPrice.dukatenExc !== null && productPrice.dukatenExc !== undefined ? 
            productPrice.dukatenExc.toString() : '0';
          const dukatenInc = productPrice.dukatenInc !== null && productPrice.dukatenInc !== undefined ? 
            productPrice.dukatenInc.toString() : '0';
            
          formData.append(`ProductPriceBudgetGroups[${i}].DukatenExc`, dukatenExc);
          formData.append(`ProductPriceBudgetGroups[${i}].DukatenInc`, dukatenInc);
          
          // Ensure budget group IDs are properly formatted
          if (productPrice.budgetGroupIds && productPrice.budgetGroupIds.length > 0) {
            productPrice.budgetGroupIds.forEach((id: number, j: number) => {
              if (id) {
                formData.append(`ProductPriceBudgetGroups[${i}].BudgetGroupsIds[${j}]`, id.toString());
              }
            });
          } else {
           
            this.errorMessage = 'Budget group IDs are required for each price group';
            this.showError();
            return;
          }
        });
      }

      // Handle characteristics
      if (product.characteristics && product.characteristics.length > 0) {
        product.characteristics.forEach((characteristic: number) => {
          if (characteristic) {
            formData.append('ProductCharacteristics', characteristic.toString());
          }
        });
      }
      
      // Handle mapped products
      if (product.mappedProducts && product.mappedProducts.length > 0) {
        product.mappedProducts.forEach((mp: number) => {
          if (mp) {
            formData.append('MappedProducts', mp.toString());
          }
        });
      }


      this.apiService.createProduct(formData).subscribe(
        (data) => {
          if (data.requestResult == 1) {
            this.getAllProducts();
            this.resetForm();
            this.closeDetails();
            this.createProduct = false;
            this.showSuccess('create');
          } else {
            this.errorMessage = data.responseTip;
            this.showError();
          }
        },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        }
      );
    } else {
      this.selectedProductForm.markAllAsTouched();
      this.errorMessage = 'Please fill all required fields.';
      this.showError();
    }
  }

  updateProduct() {
    if (this.selectedProductForm.valid) {
      this.separateImagesAccordingToTypes();
      const product = this.selectedProductForm.getRawValue();
      var formData = new FormData();
      //append the form field if the value is not null
      const appendIfNotNull = (key: string, value: any) => {
        if (value !== null && value !== undefined && value !== '') {
          formData.append(key, value);
        }
      };

      formData.append('Id', product.id);
      formData.append('ImportId', product.importId);
      appendIfNotNull('ExternalProductId', product.externalProductId);
      appendIfNotNull('SupplierId', product.supplierId);
      appendIfNotNull('LongDesc', product.longDesc);
      appendIfNotNull('LongDescEng', product.longDescEng);
      appendIfNotNull('AddtionalText', product.addtionalText);
      formData.append('Published', product.published);
      formData.append('Title', product.title);
      formData.append('TitleEng', product.titleEng);
      
      formData.append('PartnerId', product.partner);
      formData.append('Stock', product.stock);
      formData.append('DukatenExc', product.dukatenExc);
      formData.append('DukatenInc', product.dukatenInc);
      formData.append('VatId', product.vatId);

      appendIfNotNull('BrandId', product.brandId);
      if (product.characteristics.length > 0) {
        product.characteristics.forEach((characteristic: number) => {
          formData.append('ProductCharacteristics', characteristic.toString());
        });
      }

      if (this.videos.length > 0) {
        this.videos.forEach((video: string, i: number) => {
          formData.append(`ProductVideos`, video);
        }
        );
      }

      if (product.categories.length > 0) {
        product.categories.forEach((category: number) => {
          formData.append('ProductCategories', category.toString());
        });
      }

      if (product.mappedProducts.length > 0) {
        product.mappedProducts.forEach((mp: number) => {
          formData.append('MappedProducts', mp.toString());
        });
      }

      if(this.selectedProductPriceList.length > 0){
        this.selectedProductPriceList.forEach( (productPrice: ProductPrice, i: number) =>{
          formData.append(`ProductPriceBudgetGroups[${i}].DukatenExc`, productPrice.dukatenExc.toString());
          formData.append(`ProductPriceBudgetGroups[${i}].DukatenInc`, productPrice.dukatenInc.toString());
          if(productPrice.budgetGroupIds.length > 0){
            productPrice.budgetGroupIds.forEach((id: number, j: number)=>{
              formData.append(`ProductPriceBudgetGroups[${i}].BudgetGroupsIds[${j}]`, id.toString());
            })
          }
        })
      }

      if (this.productImages.length > 0) {
        this.productImages.forEach((image: productImage, i: number) => {
          formData.append(`ProductImages[${i}].Image`, image.Image);
          formData.append(
            `ProductImages[${i}].Thumbnail`,
            image.Thumbnail.toString()
          );
        });
      }
      
      if (this.existingImages.length > 0) {
        this.existingImages.forEach((image: Image, i: number) => {
          formData.append(
            `ExistingImages[${i}].FileName`,
            image.fileName.toString()
          );
          formData.append(
            `ExistingImages[${i}].Thumbnail`,
            image.thumbnail.toString()
          );
          formData.append(
            `ExistingImages[${i}].ImageUrl`,
            image.imageUrl.toString()
          );
        });
      }
      if (this.LibraryImages.length > 0) {
        this.LibraryImages.forEach((image: GiftsetImage, i: number) => {
          formData.append(`LibraryImages[${i}].UrlPath`, image.imageUrl);
          formData.append(`LibraryImages[${i}].FileName`, image.fileName);
          formData.append(`LibraryImages[${i}].Thumbnail`, image.thumbnail.toString());
        }
        );
      }

      this.apiService.updateProduct(formData).subscribe(
        (data) => {
          if (data.requestResult == 1) {
            this.getAllProducts();
            this.resetForm();
            this.closeDetails();
            this.showSuccess('update');
            this.resetInlineEdit();
          } else {
            this.errorMessage = data.responseTip;
            this.showError();
          }
        },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        }
      );
    } else {
      this.selectedProductForm.markAllAsTouched();
      this.errorMessage = 'Please fill all required fields.';
      this.showError();
    }
  }

  onSelectionChange(value: any) {
    if(value && value !=''){
      if(value == 'filter'){
        this.getAllProducts();
      }else if(value == 'budgetGroupIds'){
        this.selectedProductPriceForm.get(value).markAsTouched();
      }
      else{
        this.selectedProductForm.get(value).markAsTouched();
      }
    }
  }

  saveProductPrice() {
    if (this.selectedProductPriceForm.valid) {
      this.selectedProductPriceForm.get('productPriceId').patchValue(`a${this.selectedProductPriceList.length}`);
      this.selectedProductPriceList.push(this.selectedProductPriceForm.getRawValue());
      this.closeProductPriceDetails();
    } else {
      this.selectedProductPriceForm.markAllAsTouched();
    }
  }

  updateProductPrice() {
    if (this.selectedProductPriceForm.valid) {
      this.selectedProductPriceList = this.selectedProductPriceList.filter((productPrice) => {
        productPrice.productPriceId != this.selectedProductPrice.productPriceId;
      });
      this.selectedProductPriceList.push(this.selectedProductPriceForm.getRawValue());
      this.closeProductPriceDetails();
    } else {
      this.selectedProductPriceForm.markAllAsTouched();
    }
  }



  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * After view init
   */
  ngAfterViewInit(): void {
    if (this._sort && this._paginator) {
      setTimeout(() => {
        // Set the initial sort
        this._sort.sort({
          id: 'id',
          start: 'desc',
          disableClear: true,
        });
      });

      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;
          this.pageIndex = 0;

          //reset and close the form if it is open
          this.resetForm();
          this.closeDetails();

          // set the sort column and sort order
          this.sortColumn = this.getSortColumn(this._sort.active);
          this.sortOrder = this._sort.direction === 'asc' ? 2 : 1;

          // Close the details
          this.closeDetails();

          // Get the Brands
          this.getAllProducts();
        });
    }
  }

  getSortColumn(name: string) {
    switch (name) {
      case 'importId':
        return 1;
        break;
      case 'title':
        return 2;
        break;
      case 'brand':
        return 3;
        break;
      case 'category':
        return 4;
        break;
      case 'partner':
        return 5;
        break;
      case 'stock':
        return 6;
        break;
      case 'stockIncludingExtraOrder':
        return 7;
        break;
      default:
        return 0;
    }
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggle product details
   *
   * @param productId
   */
  toggleDetails(productId: number): void {
    this.createProduct = false;
    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct.id === productId) {
      // Close the details
      this.closeDetails();
      return;
    }

    const myMap = new Map(this.productsArray.map((obj) => [obj.id, obj]));

    this.selectedProduct = myMap.get(productId);
    let modifiedImages = this.selectedProduct.images.map(image => ({
      ...image,
      isLibraryImage: false
    }));
    this.selectedProductForm.patchValue(this.selectedProduct);
    this.images = modifiedImages;
    this.videos = this.selectedProduct.videos;
    this.initializeImages(this.images);
    this.selectedProductPriceList = this.selectedProduct.productPrices;
    this.createProductPrice = this.selectedProductPriceList.length == 0;
  }

  toggleProductPriceDetails(id: number | string){
    // If the product is already selected...
    if (this.selectedProductPrice && this.selectedProductPrice.productPriceId === id) {
      // Close the details
      this.closeProductPriceDetails();
      return;
    }


    const myMap = new Map(this.selectedProductPriceList.map(obj => [obj.productPriceId, obj]));

    this.selectedProductPrice = myMap.get(id);
    this.selectedProductPriceForm.patchValue(this.selectedProductPrice);
  }



  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
    this.videos = [];
    this.images = [];
    this.isInlineEdit = false;
    this.selectedProductPriceList = [];
    this.selectedProductPrice = null;
  }

  closeProductPriceDetails(){
    this.selectedProductPrice = null;
    this.createProductPrice = false;
  }

  resetForm() {
    this.resetProductPriceForm();
    let property = this.selectedProductForm.getRawValue();
    this.selectedProductForm.reset({
      id : property.id,
      published: false,
      categories: [],
      productPrices: [],
      characteristics: [],
      mappedProducts: [],
      videos: [],
      images: [],
    });

    // Optionally mark the form as touched to trigger validation messages
    if(property.id != 0){
      this.selectedProductForm.markAllAsTouched();
    }

    this.images = [];
    this.selectedProductPriceList = [];
    this.selectedProductPrice = null;
  }

  resetProductPriceForm(){
    this.selectedProductPriceForm.reset();
  }

  /**
   * Delete the selected product using the form data
   */
  async deleteSelectedProduct(id: number | null, isFromDeleteBtn: boolean = false): Promise<void> {

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('product');

    if (!confirmed) {
      return;
    }

    if (!isFromDeleteBtn) {
      this.selectedProducts.clear();
      this.selectedProducts.set(id, true)
    }

    // delete the faq group
    this.deleteProducts();

    // Close the details
    this.closeDetails();
  }


  async deleteSelectedProductPrice(id: number | null): Promise<void> {

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('product price', DeleteTypes.Custom, 'Are you sure you want to remove this product price?');

    if (confirmed) {

      this.selectedProductPriceList = this.selectedProductPriceList.filter((productPrice) => productPrice.productPriceId != id);

      this.closeProductPriceDetails();
    }
  }

  /**
   * Show flash message
   */
  showFlashMessage(type: 'success' | 'error'): void {
    // Show the message
    this.flashMessage = type;

    // Mark for check
    this._changeDetectorRef.markForCheck();

    // Hide it after 3 seconds
    setTimeout(() => {
      this.flashMessage = null;

      // Mark for check
      this._changeDetectorRef.markForCheck();
    }, 3000);
  }

  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }

  addVideos(video: string) {
    let urlPattern =
      /^https?:\/\/([\w-]+\.)+[\w-]+(\/[\w\-._~:/?#[\]@!$&'()*+,;=]*)?$/;
    if (urlPattern.test(video)) {
      this.videoUrlError = false;

      this.videos.push(video);
      this.videoUrl = ''; // Clear the input field after adding the video
    } else {
      this.videoUrlError = true;
    }
  }

  async removeVideo(video: string) {

    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('video', DeleteTypes.Video);

    if (confirmed) {
      this.videos = this.videos.filter((i) => i !== video);
    }
  }

  // When user changes thumbnail
  onThumbnailSelect(index: number) {
    this.selectedThumbnailIndex = index;

    // Update all images
    this.images.forEach((image, i) => {
      image.thumbnail = i === index;
    });
  }

  // While initializing (example after fetching images)
  initializeImages(images: Image[]) {
    this.selectedThumbnailIndex = this.images.findIndex((img) => img.thumbnail);
  }


  separateImagesAccordingToTypes() {
    this.productImages = [];
    this.existingImages = [];
    this.LibraryImages = [];
    for (const image of this.images) {
      if (image.fileName instanceof File) {
        this.productImages.push({
          Image: image.fileName,
          Thumbnail: image.thumbnail,
        });
      } else if(image.isLibraryImage){
        this.LibraryImages.push(image);
      }
       else {
        this.existingImages.push(image);
      }

    }
  }

  public GetFileOnLoad(event: any, inputBox: string) {
    if (event.target.files && event.target.files.length > 0) {
      for (let i = 0; i < event.target.files.length; i++) {
        var file = event.target.files[i] as File;
        this.images.push({
          fileName: file,
          thumbnail: this.images?.length > 0 ? false : true,
          imageUrl: URL.createObjectURL(file),
          isLibraryImage: false
        });
      }

      if(this.images?.length == 0){
        this.onThumbnailSelect(0);
      }
      
    }

      
    
  }

  removeImageFile(url: string) {
    this.images = this.images.filter((pimage) => pimage.imageUrl !== url);
  }

  // Methods to clear search inputs in dropdown search fields
  clearDropdownSearch(event: Event, inputElement: HTMLInputElement): void {
    event.stopPropagation(); 
    inputElement.value = ''; 
    inputElement.dispatchEvent(new Event('input')); 
    inputElement.focus();
  }

  openImageLibrary() {
    const dialogRef = this.dialog.open(ImageLibraryDialog);

    dialogRef.afterClosed().subscribe((result: ImageLibraryContent) => {
      this.images.push({
        fileName: result.fileName,
        imageUrl: result.urlPath + result.fileName,
        thumbnail: false,
        isLibraryImage: true
      })

      setTimeout(() => {
        if(this.images?.length == 1){
          this.onThumbnailSelect(0);
        }
      });
    });

   
  }

  onDropdownBlur(type: string) {
    switch (type) {
      case 'partner':
        this.selectedProductForm.get('partner').markAsTouched();
        break;
      case 'vatId':
        this.selectedProductForm.get('vatId').markAsTouched();
        break;
      case 'categories':
        this.selectedProductForm.get('categories').markAsTouched();
        break;
      case 'budgetGroupIds':
        this.selectedProductPriceForm.get('budgetGroupIds').markAsTouched();
        break;
      default:
        break;
    }
  }
}

