import { Routes } from "@angular/router";
import { ProductsComponent } from "./products.component";

export default [
    {
        path: '',
        component: ProductsComponent
    }
] as Routes