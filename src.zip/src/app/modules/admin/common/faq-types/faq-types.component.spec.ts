import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FaqTypesComponent } from './faq-types.component';

describe('FaqTypesComponent', () => {
  let component: FaqTypesComponent;
  let fixture: ComponentFixture<FaqTypesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FaqTypesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FaqTypesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
