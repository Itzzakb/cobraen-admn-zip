import { Routes } from '@angular/router';
import { FaqTypesComponent } from './faq-types.component';


export default [
    {
        path: '',
        component: FaqTypesComponent,
    },
] as Routes;