import {
  AsyncPipe,
  CurrencyPipe,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { InventoryService } from 'app/shared/services/inventory.service';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatTooltipModule } from '@angular/material/tooltip';

import {
  InventoryBrand,
  InventoryCategory,
  InventoryPagination,
  InventoryProduct,
  InventoryTag,
  InventoryVendor,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  map,
  switchMap,
  takeUntil,
} from 'rxjs';
import { faqType } from 'app/shared/types/interfaces';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { DeleteConfirmationService } from 'app/shared/services/delete-confirmation.service';

@Component({
  selector: 'app-faq-types',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 80px 1fr 88px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 80px 1fr 88px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 80px 1fr 88px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 80px 1fr 88px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    MatTooltipModule,
  ],
  templateUrl: './faq-types.component.html',
  styleUrl: './faq-types.component.scss',
})
export class FaqTypesComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  products$: Observable<InventoryProduct[]>;

  brands: InventoryBrand[];
  categories: InventoryCategory[];
  filteredTags: InventoryTag[];
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: InventoryPagination;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: faqType | null = null;
  selectedProductForm: UntypedFormGroup;
  tags: InventoryTag[];
  tagsEditMode: boolean = false;
  vendors: InventoryVendor[];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  FaqTypesArray: faqType[] = [];
  selectedFaqTypes: Map<number, boolean> = new Map(); // Tracks selected brands
  allSelected: boolean = false;

  searchQuery: string = '';
  searchSubject = new Subject<string>();
  searchSubscription: any;

  // Pagination properties
  pageIndex: number = 0;
  pageSize: number = 10;
  totalCount: number = 0;
  sortOrder: number = 1;
  sortColumn: number = 0;

  createFaqtype = false;

  errorMessage: string = '';
  isDataLoaded: boolean = false;
  @ViewChild('headerPaginator') headerPaginator!: MatPaginator;
  @ViewChild('footerPaginator') footerPaginator!: MatPaginator;

  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _deleteConfirmationService: DeleteConfirmationService,
    private _formBuilder: UntypedFormBuilder,
    private _inventoryService: InventoryService,
    private apiService: ApiService,
    private toastr: ToastrService
  ) {}

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.selectedProductForm = this._formBuilder.group({
      id: [''],
      type: ['', [Validators.required]],
    });

    // Get the brands
    this._inventoryService.brands$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((brands: InventoryBrand[]) => {
        // Update the brands
        this.brands = brands;

        // Mark for check
        this._changeDetectorRef.markForCheck();
      });

    // Get the categories
    this._inventoryService.categories$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((categories: InventoryCategory[]) => {
        // Update the categories
        this.categories = categories;

        // Mark for check
        this._changeDetectorRef.markForCheck();
      });

    // Get the pagination
    this._inventoryService.pagination$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((pagination: InventoryPagination) => {
        // Update the pagination
        this.pagination = pagination;

        // Mark for check
        this._changeDetectorRef.markForCheck();
      });

    // Get the products
    this.products$ = this._inventoryService.products$;

    // Get the tags
    this._inventoryService.tags$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((tags: InventoryTag[]) => {
        // Update the tags
        this.tags = tags;
        this.filteredTags = tags;

        // Mark for check
        this._changeDetectorRef.markForCheck();
      });

    // Get the vendors
    this._inventoryService.vendors$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((vendors: InventoryVendor[]) => {
        // Update the vendors
        this.vendors = vendors;

        // Mark for check
        this._changeDetectorRef.markForCheck();
      });

    // Subscribe to search input field value changes
    this.searchInputControl.valueChanges
      .pipe(
        takeUntil(this._unsubscribeAll),
        debounceTime(300),
        switchMap((query) => {
          this.closeDetails();
          this.isLoading = true;
          return this._inventoryService.getProducts(
            0,
            10,
            'name',
            'asc',
            query
          );
        }),
        map(() => {
          this.isLoading = false;
        })
      )
      .subscribe();

    // Debounce search input to optimize API calls
    this.searchSubscription = this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe((query) => {
        this.searchQuery = query;
        this.pageIndex = 0; // Reset to first page on new search
        this.footerPaginator.firstPage();
        this.getAllFaqTypes();
      });
  }

  // Toggle selection for a single brand
  toggleSelection(id: number) {
    if (this.selectedFaqTypes.has(id)) {
      this.selectedFaqTypes.delete(id); // Unselect
    } else {
      this.selectedFaqTypes.set(id, true); // Select
    }
    this.updateSelectAllState();
  }

  // Toggle Select All
  toggleSelectAll() {
    if (this.allSelected) {
      this.selectedFaqTypes.clear(); // Unselect all
    } else {
      this.FaqTypesArray.forEach((brand) =>
        this.selectedFaqTypes.set(brand.id, true)
      ); // Select all
    }
    this.allSelected = !this.allSelected;
  }

  // Update the "Select All" checkbox state
  updateSelectAllState() {
    this.allSelected = this.selectedFaqTypes.size === this.FaqTypesArray.length;
  }

  //get selectedFaqTypes' Ids
  getSelectedFaqTypeIds(): number[] {
    return Array.from(this.selectedFaqTypes.entries()) // Convert Map to an array of key-value pairs
      .filter(([id, isSelected]) => isSelected) // Filter selected brands
      .map(([id]) => id); // Extract only the IDs
  }
  //Deletes the selected Brand entries by calling the API service. If the deletion is successful, it clears the selected Brands map.
  deleteFaqTypes() {
    this.apiService.deleteFAQType(this.getSelectedFaqTypeIds()).subscribe(
      (response) => {
        if (response.requestResult == 1) {
          this.selectedFaqTypes = new Map();
          this.getAllFaqTypes();
          this.showSuccess('delete');
        } else {
          this.errorMessage = response.responseTip;
          this.showError();
          this.selectedFaqTypes = new Map();
        }
      },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
        this.selectedFaqTypes = new Map();
      }
    );
  }

  // get all brands
  getAllFaqTypes() {
    const params = {
      sortColumn: this.sortColumn,
      pageIndex: this.pageIndex,
      pageSize: this.pageSize,
      sortOrder: this.sortOrder,
      searchQuery: this.searchQuery,
    };
    this.apiService.getFAQTypes(params).subscribe((data) => {
      this.FaqTypesArray = data.result.data;
      this.pageIndex = data.result.pageIndex;
      this.pageSize = data.result.pageSize;
      this.totalCount = data.result.count;
      this.isDataLoaded = true;
    });
  }

  // Triggers a search operation with the provided query string.
  onSearch(query: string): void {
    this.searchSubject.next(query);
  }

  // Handle pagination changes
  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.getAllFaqTypes();
  }

  toggleCreateFaqTypeForm() {
    this.createFaqtype = !this.createFaqtype;
    if (this.createFaqtype) {
      const newProduct = {
        id: 0,
        type: '',
      };
      // Go to new product
      this.selectedProduct = newProduct;

      // Fill the form
      this.selectedProductForm.patchValue(newProduct);

      // Mark for check
      this._changeDetectorRef.markForCheck();
    } else {
      this.selectedProductForm.reset();
    }
  }
  //update faq type
  updateFaqType() {
    if (this.selectedProductForm.valid) {
      const faqType = this.selectedProductForm.getRawValue();
      var formData = new FormData();
      formData.append('Id', faqType.id);
      formData.append('Type', faqType.type);

      this.apiService.updateFAQType(formData).subscribe(
        (data) => {
          if (data.requestResult == 1) {
            this.getAllFaqTypes();
            this.closeDetails();
            this.showSuccess('update');
          } else {
            this.errorMessage = data.responseTip;
            this.showError();
          }
        },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        }
      );
    } else {
      this.errorMessage = 'Please fill all the required fields.';
      this.selectedProductForm.markAllAsTouched();
      this.showError();
    }
  }

  //add faq type
  addFaqType(): void {
    if (this.selectedProductForm.valid) {
      const faqType = this.selectedProductForm.getRawValue();
      var formData = new FormData();
      formData.append('Type', faqType.type);

      this.apiService.createFAQType(formData).subscribe(
        (data) => {
          if (data.requestResult == 1) {
            this.getAllFaqTypes();
            this.resetForm();
            this.closeDetails();
            this.createFaqtype = false;
            this.showSuccess('create');
          } else {
            this.errorMessage = data.responseTip;
            this.showError();
          }
        },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        }
      );
    } else {
      this.selectedProductForm.markAllAsTouched();
      this.errorMessage = 'Please fill all the required fields';
      this.showError();
    }
  }

  showSuccess(type: string) {
    const message =
      type == 'create'
        ? 'FAQ Type created successfully.'
        : type === 'update'
        ? 'FAQ Type updated successfully.'
        : 'FAQ Type deleted successfully.';
    this.toastr.success(message, 'Success!');
  }
  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }

  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * After view init
   */
  ngAfterViewInit(): void {
    if (this._sort && this._paginator) {
      setTimeout(() => {
        // Set the initial sort
        this._sort.sort({
          id: 'id',
          start: 'desc',
          disableClear: true,
        });
      });

      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;
          this.pageIndex = 0;

          //reset and close the form if it is open
          this.resetForm();
          this.closeDetails();

          // set the sort column and sort order
          this.sortColumn = this._sort.active === 'type' ? 1 : 0;
          this.sortOrder = this._sort.direction === 'asc' ? 2 : 1;

          // Close the details
          this.closeDetails();

          //get all FaqTypes
          this.getAllFaqTypes();
        });
    }
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
    if (this.searchSubscription) {
      this.searchSubscription.unsubscribe();
    }
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggle product details
   *
   * @param id
   */
  toggleDetails(id: number): void {
    this.createFaqtype = false;
    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct.id === id) {
      // Close the details
      this.closeDetails();
      return;
    }

    const myMap = new Map(this.FaqTypesArray.map((obj) => [obj.id, obj]));

    this.selectedProduct = myMap.get(id);
    this.selectedProductForm.patchValue(this.selectedProduct);
  }

  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
    this.resetForm();
  }

  //reset form
  resetForm() {
    const currentIndex = this.selectedProductForm.get('id').value;
    
    if (currentIndex != 0) {
      this.selectedProductForm.patchValue(this.selectedProduct);
    }
    else {
      this.selectedProductForm.reset();
    }
  }

  /**
   * Toggle the tags edit mode
   */
  toggleTagsEditMode(): void {
    this.tagsEditMode = !this.tagsEditMode;
  }

  /**
   * Filter tags
   *
   * @param event
   */
  filterTags(event): void {
    // Get the value
    const value = event.target.value.toLowerCase();

    // Filter the tags
    this.filteredTags = this.tags.filter((tag) =>
      tag.title.toLowerCase().includes(value)
    );
  }

  /**
   * Filter tags input key down event
   *
   * @param event
   */
  // filterTagsInputKeyDown(event): void {
  //   // Return if the pressed key is not 'Enter'
  //   if (event.key !== 'Enter') {
  //     return;
  //   }

  //   // If there is no tag available...
  //   if (this.filteredTags.length === 0) {
  //     // Create the tag
  //     this.createTag(event.target.value);

  //     // Clear the input
  //     event.target.value = '';

  //     // Return
  //     return;
  //   }

  //   // If there is a tag...
  //   const tag = this.filteredTags[0];
  //   const isTagApplied = this.selectedProduct.tags.find((id) => id === tag.id);

  //   // If the found tag is already applied to the product...
  //   if (isTagApplied) {
  //     // Remove the tag from the product
  //     this.removeTagFromProduct(tag);
  //   } else {
  //     // Otherwise add the tag to the product
  //     this.addTagToProduct(tag);
  //   }
  // }

  /**
   * Create a new tag
   *
   * @param title
   */
  // createTag(title: string): void {
  //   const tag = {
  //     title,
  //   };

  //   // Create tag on the server
  //   this._inventoryService.createTag(tag).subscribe((response) => {
  //     // Add the tag to the product
  //     this.addTagToProduct(response);
  //   });
  // }

  /**
   * Update the tag title
   *
   * @param tag
   * @param event
   */
  // updateTagTitle(tag: InventoryTag, event): void {
  //   // Update the title on the tag
  //   tag.title = event.target.value;

  //   // Update the tag on the server
  //   this._inventoryService
  //     .updateTag(tag.id, tag)
  //     .pipe(debounceTime(300))
  //     .subscribe();

  //   // Mark for check
  //   this._changeDetectorRef.markForCheck();
  // }

  /**
   * Delete the tag
   *
   * @param tag
   */
  // deleteTag(tag: InventoryTag): void {
  //   // Delete the tag from the server
  //   this._inventoryService.deleteTag(tag.id).subscribe();

  //   // Mark for check
  //   this._changeDetectorRef.markForCheck();
  // }

  /**
   * Add tag to the product
   *
   * @param tag
   */
  // addTagToProduct(tag: InventoryTag): void {
  //   // Add the tag
  //   this.selectedProduct.tags.unshift(tag.id);

  //   // Update the selected product form
  //   this.selectedProductForm.get('tags').patchValue(this.selectedProduct.tags);

  //   // Mark for check
  //   this._changeDetectorRef.markForCheck();
  // }

  /**
   * Remove tag from the product
   *
   * @param tag
   */
  // removeTagFromProduct(tag: InventoryTag): void {
  //   // Remove the tag
  //   this.selectedProduct.tags.splice(
  //     this.selectedProduct.tags.findIndex((item) => item === tag.id),
  //     1
  //   );

  //   // Update the selected product form
  //   this.selectedProductForm.get('tags').patchValue(this.selectedProduct.tags);

  //   // Mark for check
  //   this._changeDetectorRef.markForCheck();
  // }

  /**
   * Toggle product tag
   *
   * @param tag
   * @param change
   */
  // toggleProductTag(tag: InventoryTag, change: MatCheckboxChange): void {
  //   if (change.checked) {
  //     this.addTagToProduct(tag);
  //   } else {
  //     this.removeTagFromProduct(tag);
  //   }
  // }

  /**
   * Should the create tag button be visible
   *
   * @param inputValue
   */
  shouldShowCreateTagButton(inputValue: string): boolean {
    return !!!(
      inputValue === '' ||
      this.tags.findIndex(
        (tag) => tag.title.toLowerCase() === inputValue.toLowerCase()
      ) > -1
    );
  }

  /**
   * Update the selected product using the form data
   */
  updateSelectedProduct(): void {
    // Get the product object
    const product = this.selectedProductForm.getRawValue();

    // Remove the currentImageIndex field
    delete product.currentImageIndex;

    // Update the product on the server
    this._inventoryService.updateProduct(product.id, product).subscribe(() => {
      // Show a success message
      this.showFlashMessage('success');
    });
  }

  /**
   * Delete the selected product using the form data
   */
  async deleteSelectedProduct(id: number | null, isFromDeleteBtn = false): Promise<void> {

    //Open the confirmation dialog
    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('FAQ type');

    if (!confirmed) {
      return;
    }

    // If the confirm button pressed...
    if (!isFromDeleteBtn) {
      this.selectedFaqTypes.clear();
      this.selectedFaqTypes.set(id, true)
    }

    this.deleteFaqTypes();
    this.closeDetails();
  }

  /**
   * Show flash message
   */
  showFlashMessage(type: 'success' | 'error'): void {
    // Show the message
    this.flashMessage = type;

    // Mark for check
    this._changeDetectorRef.markForCheck();

    // Hide it after 3 seconds
    setTimeout(() => {
      this.flashMessage = null;

      // Mark for check
      this._changeDetectorRef.markForCheck();
    }, 3000);
  }

  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }
}
