import { Routes } from "@angular/router";
import { BrandsComponent } from "./brands.component";

export default[
    {
        path:'',
        component: BrandsComponent
    }
] as Routes