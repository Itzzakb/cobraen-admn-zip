import {
  AsyncPipe,
  CommonModule,
  CurrencyPipe,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule, } from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatTooltipModule } from '@angular/material/tooltip';

import {
  InventoryBrand,
  InventoryCategory,
  InventoryPagination,
  InventoryProduct,
  InventoryTag,
  InventoryVendor,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  takeUntil,
} from 'rxjs';
import { Brand } from 'app/shared/types/interfaces';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { DeleteConfirmationService } from 'app/shared/services/delete-confirmation.service';
import { CommonHelperService } from 'app/shared/services/common-helper.service';

@Component({
  selector: 'app-brands',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 80px 1fr 88px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 80px 1fr 88px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 80px 1fr 88px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 80px 1fr 88px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    CommonModule,
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    MatTooltipModule,
  ],
  templateUrl: './brands.component.html',
  styleUrl: './brands.component.scss',
})

export class BrandsComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  products$: Observable<InventoryProduct[]>;

  brands: InventoryBrand[];
  categories: InventoryCategory[];
  filteredTags: InventoryTag[];
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: InventoryPagination;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: Brand | null = null;
  selectedProductForm: UntypedFormGroup;
  tags: InventoryTag[];
  tagsEditMode: boolean = false;
  vendors: InventoryVendor[];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  brandsArray: Brand[] = [];
  selectedBrands: Map<number, boolean> = new Map(); // Tracks selected brands
  allSelected: boolean = false;

  searchQuery: string = '';
  searchSubject = new Subject<string>();
  searchSubscription: any;

  // Pagination properties
  pageIndex: number = 0;
  pageSize: number = 10;
  totalCount: number = 0;
  sortOrder: number = 1;
  sortColumn: number = 0;

  createBrand = false;

  indexImg: string = '';
  detailImg: string = '';
  indexImgFile: File | null = null;
  detailImgFile: File | null = null;

  errorMessage = '';
  isDataLoaded: boolean = false;

  @ViewChild('headerPaginator') headerPaginator!: MatPaginator;
  @ViewChild('footerPaginator') footerPaginator!: MatPaginator;

  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _formBuilder: UntypedFormBuilder,
    private apiService: ApiService,
    private toastr:ToastrService,
    private _deleteConfirmationService: DeleteConfirmationService
  ) { }

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.selectedProductForm = this._formBuilder.group({
      id: [0],
      name: ['', [Validators.required]],
      description: ['', [Validators.required]],
      descriptionEng: ['', [Validators.required]],
      descriptionIntro: ['', [Validators.required]],
      descriptionIntroEng: ['', [Validators.required]],
    });

   
    // Debounce search input to optimize API calls
    this.searchSubscription = this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe(query => {
        this.searchQuery = query;
        this.pageIndex = 0; // Reset to first page on new search
        this.footerPaginator.firstPage();
        this.getAllBrands();
      });

  }



  // Toggle selection for a single brand
  toggleSelection(brandId: number) {
    if (this.selectedBrands.has(brandId)) {
      this.selectedBrands.delete(brandId); // Unselect
    } else {
      this.selectedBrands.set(brandId, true); // Select
    }
    this.updateSelectAllState();
  }

  // Toggle Select All
  toggleSelectAll() {
    if (this.allSelected) {
      this.selectedBrands.clear(); // Unselect all
    } else {
      this.brandsArray.forEach(brand => this.selectedBrands.set(brand.id, true)); // Select all
    }
    this.allSelected = !this.allSelected;
  }

  // Update the "Select All" checkbox state
  updateSelectAllState() {
    this.allSelected = this.selectedBrands.size === this.brandsArray.length;
  }

  //get selectedBrands' Ids
  getSelectedBrandIds(): number[] {
    return Array.from(this.selectedBrands.entries()) // Convert Map to an array of key-value pairs
      .filter(([id, isSelected]) => isSelected) // Filter selected brands
      .map(([id]) => id); // Extract only the IDs
  }

  //Deletes the selected Brand entries by calling the API service. If the deletion is successful, it clears the selected Brands map.
  deleteBrands() {
    this.apiService.deleteBrand(this.getSelectedBrandIds()).subscribe({
      next: (response) => {
        if (response.requestResult == 1) {
          this.selectedBrands = new Map();
          this.getAllBrands();
          this.showSuccess('delete');
        } else {
          this.errorMessage = response.responseTip;
          this.showError();
        }
      },
      error: (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      }
    })
  }

  // get all brands
  getAllBrands() {
    const params = {
      sortColumn: this.sortColumn,
      pageIndex: this.pageIndex,
      pageSize: this.pageSize,
      sortOrder: this.sortOrder,
      searchQuery: this.searchQuery
    }
    this.apiService.getbrands(params).subscribe((data) => {
      this.brandsArray = data.result.data;
      this.pageIndex = data.result.pageIndex;
      this.pageSize = data.result.pageSize;
      this.totalCount = data.result.count;
      this.isDataLoaded = true;
    });
  }

  showSuccess(type: string) {
    const message = type === 'create'? 'Brand created successfully.': (type == 'update' ? 'Brand updated successfully.': 'Brand deleted successfully.');
    this.toastr.success(message, 'Success!');
  }
  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }

  // Triggers a search operation with the provided query string.
  onSearch(query: string): void {
    this.createBrand = false;
    this.closeDetails();
    this.searchSubject.next(query);
  }

  // Handle pagination changes
  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.getAllBrands();
  }

  toggleCreateBrandForm() {
    //close the edit form if open
    this.closeDetails();
    
    this.createBrand = !this.createBrand;
    if (this.createBrand) {
      const newProduct = {
        id: 0,
        name: '',
        description: '',
        descriptionEng: '',
        descriptionIntro: '',
        descriptionIntroEng: '',
        image: null,
        indexImage: null
      }
      // Go to new product
      this.selectedProduct = newProduct;

      // Fill the form
      this.selectedProductForm.patchValue(newProduct);

      // Mark for check
      this._changeDetectorRef.markForCheck();
    } else {
      this.selectedProductForm.reset();
    }
  }

  //tiny editor configuration
  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * After view init
   */
  ngAfterViewInit(): void {    
    if (this._sort && this._paginator) {
     setTimeout(()=>{
       // Set the initial sort
       this._sort.sort({
        id: 'id',
        start: 'desc',
        disableClear: true,
      });
     })
      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;
          this.pageIndex = 0;

          //reset and close the form if it is open
          this.resetForm();
          this.closeDetails();

          // set the sort column and sort order
          this.sortColumn = this._sort.active === 'name' ? 1 : 0;
          this.sortOrder = this._sort.direction === 'asc' ? 2 : 1;

          // Get the Brands
          this.getAllBrands();
        });
    }
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
    if (this.searchSubscription) {
      this.searchSubscription.unsubscribe();
    }
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggle product details
   *
   * @param productId
   */
  toggleDetails(id: number): void {
    this.createBrand = false; // Close create brand form if open
    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct.id === id) {
      // Close the details
      this.closeDetails();
      return;
    }

    const myMap = new Map(this.brandsArray.map(obj => [obj.id, obj]));

    this.selectedProduct = myMap.get(id);
    this.selectedProductForm.patchValue(this.selectedProduct);
    this.indexImg = this.selectedProduct.indexImage;
    this.detailImg = this.selectedProduct.image;
  }



  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
    this.selectedProductForm.reset();
    this.indexImg = '';
    this.detailImg = '';
    this.indexImgFile = null;
    this.detailImgFile = null;
  }


  //reset the form
  resetForm() {
    CommonHelperService.preserveId(this.selectedProductForm);
    setTimeout(() => {
      this.selectedProductForm.get('name').reset();
    }, 100); 
        this.indexImg = '';
    this.detailImg = '';
    this.indexImgFile = null;
    this.detailImgFile = null;
  }

  addBrand() {
    if(this.selectedProductForm.valid){
    const brand = this.selectedProductForm.getRawValue();
    var formData = new FormData();
    formData.append('Name', brand.name);
    formData.append('Description', brand.description);
    formData.append('DescriptionEng', brand.descriptionEng);
    formData.append('DescriptionIntro', brand.descriptionIntro);
    formData.append('DescriptionIntroEng', brand.descriptionIntroEng);
    if (this.indexImgFile != null) {
      formData.append('IndexImage', this.indexImgFile);
    }
    if (this.detailImgFile != null) {
      formData.append('DetailImage', this.detailImgFile);
    }
    this.apiService.createBrand(formData).subscribe((data) => {
      if(data.requestResult == 1){
        this.getAllBrands();
        this.resetForm();
        this.closeDetails();
        this.createBrand = false;
        this.showSuccess('create');
      }else{
        this.errorMessage = data.responseTip;
        this.showError();
      }
    },
  (error) => {
    this.errorMessage = error.error.responseTip;
    this.showError();
  });
    }else{
      this.selectedProductForm.markAllAsTouched();
      this.errorMessage = 'Please fill all the required fields';
      this.showError();
    }
  }


  updateBrand() {
    if(this.selectedProductForm.valid){
    const brand = this.selectedProductForm.getRawValue();
    var formData = new FormData();
    formData.append('Id', brand.id);
    formData.append('Name', brand.name);
    formData.append('Description', brand.description);
    formData.append('DescriptionEng', brand.descriptionEng);
    formData.append('DescriptionIntro', brand.descriptionIntro);
    formData.append('DescriptionIntroEng', brand.descriptionIntroEng);
    formData.append('IndexImage', this.indexImgFile);
    formData.append('DetailImage', this.detailImgFile);
    this.apiService.updateBrand(formData).subscribe((data) => {
      if(data.requestResult == 1){
        this.getAllBrands();
        this.resetForm();
        this.closeDetails();
        this.showSuccess('update');
      }else{
        this.errorMessage = data.responseTip;
        this.showError();
      }
    },
  (error) => {
    this.errorMessage = error.error.responseTip;
    this.showError();
  });
  }else{
    this.selectedProductForm.markAllAsTouched();
    this.errorMessage = 'Please fill all the required fields';
    this.showError();
  }
}


  /**
   * Delete the selected product using the form data
   */
  async deleteSelectedProduct(id: number | null, isFromDeleteBtn = false) {

    // Open the confirmation dialog
    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('Brands');

    if (!confirmed)
      return;

    // If the confirm button pressed...
    if (!isFromDeleteBtn) {
      this.selectedBrands.clear();
      this.selectedBrands.set(id, true)
    }

    //Delete the Brand
    this.deleteBrands();

    //Close the details
    this.closeDetails();
  }

  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }

  
  GetFileOnLoad(event: any, name: string) {
    if (event.target.files && event.target.files[0]) {
      var file = event.target.files[0] as File;

      this.getImageFilePreview(name, URL.createObjectURL(file));
      this.getImageFile(name, file);
    }
  }

  getImageFilePreview(name: string, imageURL: string) {
    switch (name) {
      case 'index image':
        this.indexImg = imageURL;
        break;
      case 'detail image':
        this.detailImg = imageURL;
        break;
    }
  }
  getImageFile(name: string, imageFile: File) {
    switch (name) {
      case 'index image':
        this.indexImgFile = imageFile;
        break;
      case 'detail image':
        this.detailImgFile = imageFile;
        break;
    }
  }

  removeImageFile(name: string, inputBox: string) {
    switch (name) {
      case 'index image':
        this.indexImg = '';
        this.indexImgFile = null;
        var element = document.getElementById(
          inputBox
        ) as HTMLInputElement | null;
        if (element != null) {
          element.value = '';
        }
        break;
      case 'detail image':
        this.detailImg = '';
        this.detailImgFile = null;
        var element = document.getElementById(
          inputBox
        ) as HTMLInputElement | null;
        if (element != null) {
          element.value = '';
          element.blur();
        }
        break;
    }
  }

}
