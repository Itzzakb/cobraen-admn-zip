import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FaqGroupsComponent } from './faq-groups.component';

describe('FaqGroupsComponent', () => {
  let component: FaqGroupsComponent;
  let fixture: ComponentFixture<FaqGroupsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FaqGroupsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FaqGroupsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
