import { Routes } from '@angular/router';
import { FaqGroupsComponent } from './faq-groups.component';

export default [
    {
        path: '',
        component: FaqGroupsComponent,
    },
] as Routes;