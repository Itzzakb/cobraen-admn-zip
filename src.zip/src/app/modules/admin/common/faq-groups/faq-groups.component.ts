import {
  AsyncPipe,
  CurrencyPipe,
  NgClass,
  NgTemplateOutlet,
} from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormsModule,
  ReactiveFormsModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { MatOptionModule, MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { fuseAnimations } from '@fuse/animations';
import { InventoryService } from 'app/shared/services/inventory.service';
import { EditorComponent } from '@tinymce/tinymce-angular';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDialog } from '@angular/material/dialog';


import {
  InventoryBrand,
  InventoryCategory,
  InventoryPagination,
  InventoryProduct,
  InventoryTag,
  InventoryVendor,
} from 'app/shared/types/inventory.types';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  map,
  switchMap,
  takeUntil,
} from 'rxjs';
import { faqGroup, faqTypeName } from 'app/shared/types/interfaces';
import { ApiService } from '@fuse/services/api-service.service';
import { ToastrService } from 'ngx-toastr';
import { DialogWithForm } from 'app/shared/utils/dialog-with-form/dialog-with-form.component';
import { SearchableDropdownComponent } from 'app/shared/components/searchable-dropdown/searchable-dropdown.component';
import { DeleteConfirmationService } from 'app/shared/services/delete-confirmation.service';


@Component({
  selector: 'app-faq-groups',
  standalone: true,
  styles: [
    /* language=SCSS */
    `
      .inventory-grid {
        grid-template-columns: 50px 1fr 50px 136px;
        width: 100%;

        @screen sm {
          grid-template-columns: 50px 1fr 50px 136px;
          width: 100%;
        }

        @screen md {
          grid-template-columns: 50px 1fr 50px 136px;
          width: 100%;
        }

        @screen lg {
          grid-template-columns: 50px 1fr 50px 136px;
          width: 100%;
        }
      }
    `,
  ],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations,
  imports: [
    EditorComponent,
    MatProgressBarModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSortModule,
    NgTemplateOutlet,
    MatPaginatorModule,
    NgClass,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatRippleModule,
    AsyncPipe,
    CurrencyPipe,
    MatTooltipModule,
    SearchableDropdownComponent
  ],
  templateUrl: './faq-groups.component.html',
  styleUrl: './faq-groups.component.scss',
})
export class FaqGroupsComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(MatPaginator) private _paginator: MatPaginator;
  @ViewChild(MatSort) private _sort: MatSort;

  products$: Observable<InventoryProduct[]>;

  brands: InventoryBrand[];
  categories: InventoryCategory[];
  filteredTags: InventoryTag[];
  flashMessage: 'success' | 'error' | null = null;
  isLoading: boolean = false;
  pagination: InventoryPagination;
  searchInputControl: UntypedFormControl = new UntypedFormControl();
  selectedProduct: faqGroup | null = null;
  selectedProductForm: UntypedFormGroup;
  tags: InventoryTag[];
  tagsEditMode: boolean = false;
  vendors: InventoryVendor[];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  faqGroupsArray: faqGroup[] = [];
  selectedFaqGroups: Map<number, boolean> = new Map(); // Tracks selected brands
  allSelected: boolean = false;

  searchQuery: string = '';
  searchSubject = new Subject<string>();
  searchSubscription: any;

  // Pagination properties
  pageIndex: number = 0;
  pageSize: number = 10;
  totalCount: number = 0;
  sortOrder: number = 1;
  sortColumn: number = 0;

  createFaqGroup = false;

  errorMessage = '';

  faqList : faqTypeName[] = [];
  isDataLoaded: boolean = false;
  @ViewChild('headerPaginator') headerPaginator!: MatPaginator;
  @ViewChild('footerPaginator') footerPaginator!: MatPaginator;

  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _deleteConfirmationService: DeleteConfirmationService,
    private _formBuilder: UntypedFormBuilder,
    private _inventoryService: InventoryService,
    private apiService: ApiService,
    private toastr: ToastrService,
    private dialog: MatDialog
  ) { }

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Create the selected product form
    this.selectedProductForm = this._formBuilder.group({
      id: [''],
      name: ['', [Validators.required]],
      faqIds: [[]],
      active: false,
      defaultActive: false,
      websiteActive: false,
      appActive: false,
      selfService: false
    });

    // Get the brands
    this._inventoryService.brands$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((brands: InventoryBrand[]) => {
        // Update the brands
        this.brands = brands;

        // Mark for check
        this._changeDetectorRef.markForCheck();
      });

    // Get the categories
    this._inventoryService.categories$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((categories: InventoryCategory[]) => {
        // Update the categories
        this.categories = categories;

        // Mark for check
        this._changeDetectorRef.markForCheck();
      });

    // Get the pagination
    this._inventoryService.pagination$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((pagination: InventoryPagination) => {
        // Update the pagination
        this.pagination = pagination;

        // Mark for check
        this._changeDetectorRef.markForCheck();
      });

    // Get the products
    this.products$ = this._inventoryService.products$;

    // Get the tags
    this._inventoryService.tags$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((tags: InventoryTag[]) => {
        // Update the tags
        this.tags = tags;
        this.filteredTags = tags;

        // Mark for check
        this._changeDetectorRef.markForCheck();
      });

    // Get the vendors
    this._inventoryService.vendors$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((vendors: InventoryVendor[]) => {
        // Update the vendors
        this.vendors = vendors;

        // Mark for check
        this._changeDetectorRef.markForCheck();
      });

    // Subscribe to search input field value changes
    this.searchInputControl.valueChanges
      .pipe(
        takeUntil(this._unsubscribeAll),
        debounceTime(300),
        switchMap((query) => {
          this.closeDetails();
          this.isLoading = true;
          return this._inventoryService.getProducts(
            0,
            10,
            'name',
            'asc',
            query
          );
        }),
        map(() => {
          this.isLoading = false;
        })
      )
      .subscribe();

      //get all faqs
    this.getAllFaqs();    

    // Debounce search input to optimize API calls
    this.searchSubscription = this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe(query => {
        this.searchQuery = query;
        this.pageIndex = 0; // Reset to first page on new search
        this.footerPaginator.firstPage();
        this.getAllFaqGroups();
      });

  }

  openDialog(id: number) {
    const dialogRef = this.dialog.open(DialogWithForm,{
      data: { showKeepProduct: false },
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result && result.name) {
        this.copyFaqGroup(id, result.name);
      }
    });
  }


  // Toggle selection for a single brand
  toggleSelection(brandId: number) {
    if (this.selectedFaqGroups.has(brandId)) {
      this.selectedFaqGroups.delete(brandId); // Unselect
    } else {
      this.selectedFaqGroups.set(brandId, true); // Select
    }
    this.updateSelectAllState();
  }

  // Toggle Select All
  toggleSelectAll() {
    if (this.allSelected) {
      this.selectedFaqGroups.clear(); // Unselect all
    } else {
      this.faqGroupsArray.forEach(brand => this.selectedFaqGroups.set(brand.id, true)); // Select all
    }
    this.allSelected = !this.allSelected;
  }

  // Update the "Select All" checkbox state
  updateSelectAllState() {
    this.allSelected = this.selectedFaqGroups.size === this.faqGroupsArray.length;
  }

  //get selectedFaqGroups' Ids
  getSelectedFaqGroupIds(): number[] {
    return Array.from(this.selectedFaqGroups.entries()) // Convert Map to an array of key-value pairs
      .filter(([id, isSelected]) => isSelected) // Filter selected brands
      .map(([id]) => id); // Extract only the IDs
  }
  //Deletes the selected faq group entries by calling the API service. If the deletion is successful, it clears the selected Brands map.
  deleteFaqGroups() {
    this.apiService.deleteFAQGroup(this.getSelectedFaqGroupIds()).subscribe((response) => {
      if (response.requestResult == 1) {
        this.selectedFaqGroups = new Map();
        this.getAllFaqGroups();
        this.showSuccess('delete');
      } else {
        this.errorMessage = response.responseTip;
        this.showError();
      }
    }, (error) => {
      this.errorMessage = error.error.responseTip;
      this.showError();
    })
  }

  // get all faq groups
  getAllFaqGroups() {
    const params = {
      sortColumn: this.sortColumn,
      pageIndex: this.pageIndex,
      pageSize: this.pageSize,
      sortOrder: this.sortOrder,
      searchQuery: this.searchQuery,
    }
    this.apiService.getFAQGroups(params).subscribe((data) => {
      this.faqGroupsArray = data.result.data;
      this.pageIndex = data.result.pageIndex;
      this.pageSize = data.result.pageSize;
      this.totalCount = data.result.count;
      this.isDataLoaded = true;
    },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      });
  }

  getAllFaqs() {
    this.apiService.getAllFaqs().subscribe((data) => {
      if(data.requestResult == 1){
        this.faqList = data.result;
      }else{
        this.errorMessage = data.responseTip;
        this.showError();
      }
    },
      (error) => {
        this.errorMessage = error.error.responseTip;
        this.showError();
      })
  }

  copyFaqGroup(id: number, name: string){
    const formData = new FormData();
    formData.append('Id', id.toString());
    formData.append('Name', name);

    this.apiService.copyFAQGroup(formData).subscribe((data)=>{
      if(data.requestResult == 1){
        this.getAllFaqGroups();
        this.showSuccess('copy');
      }else{
        this.errorMessage = data.responseTip;
        this.showError()
      }
    },
  (error)=>{
    this.errorMessage = error.error.responseTip;
    this.showError();
  })
  }


  showSuccess(type: string) {
    const message = this.getSuccessMessage(type);
    this.toastr.success(message, 'Success!');
  }


  //get success message based on type
  getSuccessMessage(type:string){
    switch(type){
      case 'create':
        return 'FAQ Group created successfully.';
        break;
      case 'update':
        return 'FAQ Group updated successfully.';
        break;
      case 'delete':
        return 'FAQ Group deleted successfully.';
        break;
      case 'copy':
        return 'FAQ Group copied successfully.';
        break;
      case 'statusUpdate':
        return 'FAQ Group status updated successfully.'
    }
  }
  showError() {
    this.toastr.error(this.errorMessage, 'Error!');
  }

  // Triggers a search operation with the provided query string.
  onSearch(query: string): void {
    this.createFaqGroup = false;
    this.closeDetails();
    this.searchSubject.next(query);
  }

  // Handle pagination changes
  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.getAllFaqGroups();
  }

  toggleCreateFaqGroupForm() {
    this.createFaqGroup = !this.createFaqGroup;
    if (this.createFaqGroup) {
      const newProduct = {
        id: 0,
        name: '',
        faqIds: [],
        active: false,
        defaultActive: false,
        websiteActive: false,
        appActive: false,
        selfService: false
      }
      // Go to new product
      this.selectedProduct = newProduct;

      // Fill the form
      this.selectedProductForm.patchValue(newProduct);

      // Mark for check
      this._changeDetectorRef.markForCheck();
    } else {
      this.selectedProductForm.reset();
    }
  }


  /**
   * Adds a new FAQ group based on the form data.
   * 
   * This method first checks if the selected product form is valid. If valid, it retrieves the form data,
   * constructs a FormData object, and appends the necessary fields. It then sends this data to the API service
   * to create a new FAQ group. Upon successful creation, it refreshes the FAQ groups list, resets the form,
   * closes the details view, and shows a success message. If the creation fails, it displays an error message.
   * 
   * If the form is invalid, it marks all form fields as touched to trigger validation messages.
   */
  addFaqGroup() {
    if (this.selectedProductForm.valid) {
      const faqGroup = this.selectedProductForm.getRawValue();
      var formData = new FormData();
      let faqIds = faqGroup.faqIds.length > 0 ? faqGroup.faqIds.toString().split(',') : [];
      formData.append('Name', faqGroup.name);
      formData.append('Active', faqGroup.active);
      formData.append('DefaultActive', faqGroup.defaultActive);
      formData.append('WebsiteActive', faqGroup.websiteActive);
      formData.append('AppActive', faqGroup.appActive);
      formData.append('SelfService', faqGroup.selfService);

      if(faqIds.length > 0){
        faqIds.forEach(element => {          
          formData.append('FaqIds', element);
        });
      }

      this.apiService.createFAQGroup(formData).subscribe((data) => {
        if (data.requestResult == 1) {
          this.getAllFaqGroups();
          this.resetForm();
          this.closeDetails();
          this.createFaqGroup = false;
          this.showSuccess('create');
        } else {
          this.errorMessage = data.responseTip;
          this.showError();
        }
      },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        });
    } else {
      this.selectedProductForm.markAllAsTouched();
      this.errorMessage = 'Please fill all the required fields';
      this.showError();
    }
  }



  /**
   * Updates the FAQ group with the data from the selected product form.
   * 
   * This function first checks if the selected product form is valid. If valid, it retrieves the form data,
   * creates a FormData object, and appends the necessary fields to it. The function then calls the API service
   * to update the FAQ group with the form data. Upon a successful update, it refreshes the FAQ groups list,
   * resets the form, closes the details view, and shows a success message. If the update fails, it displays
   * an error message.
   * 
   * If the form is not valid, it marks all form fields as touched to trigger validation messages.
   */
  updateFaqGroup() {
    if (this.selectedProductForm.valid) {
      const faqGroup = this.selectedProductForm.getRawValue();
      var formData = new FormData();
      let faqIds = faqGroup.faqIds.length > 0 ? faqGroup.faqIds.toString().split(',') : [];
      formData.append('Id', faqGroup.id);
      formData.append('Name', faqGroup.name);
      formData.append('Active', faqGroup.active);
      formData.append('DefaultActive', faqGroup.defaultActive);
      formData.append('WebsiteActive', faqGroup.websiteActive);
      formData.append('AppActive', faqGroup.appActive);
      formData.append('SelfService', faqGroup.selfService);

      if(faqIds.length > 0){
        faqIds.forEach(element => {          
          formData.append('FaqIds', element);
        });
      }
      this.apiService.updateFAQGroup(formData).subscribe((data) => {
        if (data.requestResult == 1) {
          this.getAllFaqGroups();
          this.resetForm();
          this.closeDetails();
          this.showSuccess('update');
        } else {
          this.errorMessage = data.responseTip;
          this.showError();
        }
      },
        (error) => {
          this.errorMessage = error.error.responseTip;
          this.showError();
        });
    } else {
      this.selectedProductForm.markAllAsTouched();
      this.errorMessage = 'Please fill all the required fields';
      this.showError();
    }
  }

  //Update FAQ group Status
  updateStatus(id: number){
    const formData = new FormData();
    formData.append('faqGroupId', id.toString());

    this.apiService.updateFAQGroupStatus(formData).subscribe((data)=>{
      if(data.requestResult == 1){
        this.showSuccess('statusUpdate');
        this.getAllFaqGroups();
      }else{
        this.errorMessage = data.responseTip;
        this.showError();
      }
    },
  (error)=>{
    this.errorMessage = error.error.responseTip;
    this.showError();
  })
  }

  init: EditorComponent['init'] = {
    plugins:
      'anchor autolink charmap codesample emoticons image code link lists searchreplace table visualblocks codesample',
    toolbar:
      'undo redo | blocks fontfamily fontsize | bold italic forecolor backcolor | link image media table mergetags | addcomment showcomments | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat textcolor',

    image_advtab: true,
    base_url: '/tinymce', // Root for resources
    suffix: '.min', // Suffix to use when loading resources
  };

  /**
   * After view init
   */
  ngAfterViewInit(): void {
    if (this._sort && this._paginator) {
      setTimeout(() => {
        // Set the initial sort
        this._sort.sort({
          id: 'id',
          start: 'desc',
          disableClear: true,
        });
      });



      // If the user changes the sort order...
      this._sort.sortChange
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          // Reset back to the first page
          this._paginator.pageIndex = 0;
          this.pageIndex = 0;

          //reset and close the form if it is open
          this.resetForm();
          this.closeDetails();

          // set the sort column and sort order
          this.sortColumn = this._sort.active == 'name' ? 1 : 0;
          this.sortOrder = this._sort.direction === 'asc' ? 2 : 1;


          // Close the details
          this.closeDetails();

          // Get the Brands
          this.getAllFaqGroups();
        });

      
    }
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Toggle product details
   *
   * @param id
   */
  toggleDetails(id: number): void {
    this.createFaqGroup = false;
    // If the product is already selected...
    if (this.selectedProduct && this.selectedProduct.id === id) {
      // Close the details
      this.closeDetails();
      return;
    }

    const myMap = new Map(this.faqGroupsArray.map(obj => [obj.id, obj]));

    this.selectedProduct = myMap.get(id);
    this.selectedProductForm.patchValue(this.selectedProduct);
  }

  /**
   * Close the details
   */
  closeDetails(): void {
    this.selectedProduct = null;
  }

  //resetForm
  resetForm() {
    this.clearForm();
    this.createFaqGroup = false;
  }

  clearForm(){
    let property = this.selectedProductForm.getRawValue();
    
    this.selectedProductForm.reset({
      id: property.id,
      faqIds: [],
      active: false,
      defaultActive: false,
      websiteActive: false,
      appActive: false,
      selfService: false
    });

    // Optionally mark the form as touched to trigger validation messages
    if(property.id != 0){
      this.selectedProductForm.markAllAsTouched();
    }
  }

  /**
   * Delete the selected product using the form data
   */
  async deleteSelectedProduct(id: number | null, isFromDeleteBtn = false): Promise<void> {
    
    const confirmed = await this._deleteConfirmationService.showDeleteConfirmation('FAQ Group');

    if (!confirmed) {
      return;
    }

    if (!isFromDeleteBtn) {
      this.selectedFaqGroups.clear();
      this.selectedFaqGroups.set(id, true)
    }

    this.deleteFaqGroups();
    this.closeDetails();
  }


  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }

  onSelectionChange(value: any) {
    if(value && value !=''){
      this.selectedProductForm.get(value).markAsTouched();
    }
  }
}
