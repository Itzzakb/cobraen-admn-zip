import { HSNComponent } from './modules/admin/common/hsn/hsn.component';
import { FitComponent } from './modules/admin/common/fit-type/fit.component';
import { Routes } from '@angular/router';
import { SigninComponent } from './components/login/signin/signin.component';
import { DashboardComponent } from './modules/admin/common/dashboard/dashboard.component';
import { LayoutComponent } from './layout/layout.component';
import { initialDataResolver } from './app.resolvers';
import { inject } from '@angular/core';
import { InventoryService } from './shared/services/inventory.service';
import { authGuard } from './guards/auth.guard';

export const routes: Routes = [
  {
    path: 'signIn',
    component: SigninComponent,
  },
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'dashboard',
  },
  {
    path: '',
    canActivate: [authGuard],
    component: LayoutComponent,
    resolve: {
      initialData: initialDataResolver,
      brands: () => inject(InventoryService).getBrands(),
      categories: () => inject(InventoryService).getCategories(),
      products: () => inject(InventoryService).getProducts(),
      tags: () => inject(InventoryService).getTags(),
      vendors: () => inject(InventoryService).getVendors(),
    },
    children: [
      {
        path: 'dashboard',
        loadComponent: () =>
          import('app/modules/admin/common/dashboard/dashboard.component').then(
            (m) => m.DashboardComponent
          ),
      },
      // Common
      {
        path: 'common',
        children: [
          {
            path: 'defaultstyling',
            loadChildren: () =>
              import(
                'app/modules/admin/common/default-styling/default-styling.routes'
              ),
          },
          {
            path: 'cms',
            loadChildren: () =>
              import('app/modules/admin/common/static-text/static-text.routes'),
          },
          {
            path: 'faq',
            loadChildren: () =>
              import('app/modules/admin/common/faq/faq.routes'),
          },
          {
            path: 'faqgroups',
            loadChildren: () =>
              import('app/modules/admin/common/faq-groups/faq-groups.routes'),
          },
          {
            path: 'faqtypes',
            loadChildren: () =>
              import('app/modules/admin/common/faq-types/faq-types.routes'),
          },
          {
            path: 'ordermessages',
            loadChildren: () =>
              import(
                'app/modules/admin/common/order-messages/order-messages.routes'
              ),
          },
          {
            path: 'seasons',
            loadChildren: () =>
              import('app/modules/admin/common/seasons/seasons.routes'),
          },
          {
            path: 'budgetgroups',
            loadChildren: () =>
              import(
                'app/modules/admin/common/budget-groups/budget-groups.routes'
              ),
          },
          {
            path: 'templates',
            loadChildren: () =>
              import('app/modules/admin/common/templates/templates.routes'),
          },
          {
            path: 'brands',
            loadChildren: () =>
              import('app/modules/admin/common/brands/brands.routes'),
          },
          {
            path: 'products',
            loadChildren: () =>
              import('app/modules/admin/common/products/products.routes'),
          },
          {
            path: 'giftset',
            loadChildren: () =>
              import('app/modules/admin/common/giftset/giftset.routes'),
          },
          {
            path: 'shopinshop',
            loadChildren: () =>
              import(
                'app/modules/admin/common/shop-in-shop/shop-in-shop.routes'
              ),
          },
          {
            path: 'characteristics',
            loadChildren: () =>
              import(
                'app/modules/admin/common/characteristics/characteristics.routes'
              ),
          },
          {
            path: 'extrastock',
            loadChildren: () =>
              import('app/modules/admin/common/extra-stock/extra-stock.routes'),
          },
          {
            path: 'vat',
            loadChildren: () =>
              import('app/modules/admin/common/vat/vat.routes'),
          },
          {
            path: 'categories',
            loadChildren: () =>
              import('app/modules/admin/common/categories/categories.routes'),
          },
          {
            path: 'partners',
            loadChildren: () =>
              import('app/modules/admin/common/partners/partners.routes'),
          },
          {
            path: 'freegifts',
            loadChildren: () =>
              import('app/modules/admin/common/free-gifts/free-gifts.routes'),
          },
        ],
      },

      //current season
      {
        path: 'currentseason',
        children: [
          {
            path: 'organizations',
            loadChildren: () =>
              import(
                'app/modules/admin/current-season/organizations/organizations.routes'
              ),
          },
          {
            path: 'orgbranding',
            loadChildren: () =>
              import(
                'app/modules/admin/current-season/org-branding/org-branding.routes'
              ),
          },
          {
            path: 'orggiftset',
            loadChildren: () =>
              import(
                'app/modules/admin/current-season/org-giftset/org-giftset.routes'
              ),
          },
          {
            path: 'orgshopinshop',
            loadChildren: () =>
              import(
                'app/modules/admin/current-season/org-shopinshop/org-shopinshop.routes'
              ),
          },
          {
            path: 'importedorgproducts',
            loadChildren: () =>
              import(
                'app/modules/admin/current-season/imported-organization-products/imported-organization-products.routes'
              ),
          },
          {
            path: 'users',
            loadChildren: () =>
              import('app/modules/admin/current-season/users/users.routes'),
          },
          {
            path: 'christmasfair',
            loadChildren: () =>
              import(
                'app/modules/admin/current-season/christmasfair/christmasfair.routes'
              ),
          },
          {
            path: 'settings',
            loadChildren: () =>
              import(
                'app/modules/admin/current-season/settings/settings.routes'
              ),
          },
          {
            path: 'questions',
            loadChildren: () =>
              import(
                'app/modules/admin/current-season/questions/questions.routes'
              ),
          },
          {
            path: 'standardgifts',
            loadChildren: () =>
              import(
                'app/modules/admin/current-season/standard-gifts/standard-gifts.routes'
              ),
          },
          {
            path: 'employeesinfo',
            loadChildren: () =>
              import(
                'app/modules/admin/current-season/employees-info/employees-info.routes'
              ),
          },
          {
            path: 'orders',
            loadChildren: () =>
              import('app/modules/admin/current-season/orders/orders.routes'),
          },
        ],
      },

      {
        path: 'imports',
        children: [
          {
            path: 'users',
            loadChildren: () =>
              import('app/modules/admin/imports/users/users.routes'),
          },
          {
            path: 'products',
            loadChildren: () =>
              import('app/modules/admin/imports/products/products.routes'),
          },
          {
            path: 'orgproducts',
            loadChildren: () =>
              import(
                'app/modules/admin/imports/org-products/org-products.routes'
              ),
          },
          {
            path: 'productimages',
            loadChildren: () =>
              import(
                'app/modules/admin/imports/additional-product-images/additional-product-images.routes'
              ),
          },
        ],
      },

      {
        path: 'my-profile',
        loadChildren: () =>
          import('app/modules/admin/common/profile/profile.routes'),
      },

      {
        path: 'products',
        children: [
          {
            path: 'product-list',
            loadChildren: () =>
              import('app/modules/admin/common/products/products.routes'),
          },
          {
            path: 'child-product-list',
            loadChildren: () =>
              import('app/modules/admin/common/products/products.routes'),
          }
        ],
      },
      {
    path: 'color-management',
    loadComponent: () =>
      import('app/modules/admin/common/color/color.component').then(
        (m) => m.ColorComponent
      ),
  },
      {
    path: 'coupon',
    loadComponent: () =>
      import('app/modules/admin/common/coupon/coupon.component').then(
        (m) => m.CouponComponent
      ),
  },
      {
    path: 'combo',
    loadComponent: () =>
      import('app/modules/admin/common/combo/combo.component').then(
        (m) => m.ComboComponent
      ),
  },
      {
    path: 'banner',
    loadComponent: () =>
      import('app/modules/admin/common/banner/banner.component').then(
        (m) => m.BannerComponent
      ),
  },
      {
    path: 'fabric',
    loadComponent: () =>
      import('app/modules/admin/common/fabric/fabric.component').then(
        (m) => m.FabricComponent
      ),
  },
      {
    path: 'fit',
    loadComponent: () =>
      import('app/modules/admin/common/fit-type/fit.component').then(
        (m) => m.FitComponent
      ),
  },
      {
    path: 'hsn',
    loadComponent: () =>
      import('app/modules/admin/common/hsn/hsn.component').then(
        (m) => m.HSNComponent
      ),
  },
    ],
  },
  {
    path: 'expired-link',
    loadComponent: () =>
      import('app/components/expired-link/expired-link.component').then(
        (m) => m.LinkExpiredComponent
      ),
  },
  {
    path: 'forgotpassword',
    loadComponent: () =>
      import('app/components/reset-password/reset-password.component').then(
        (m) => m.ResetPasswordComponent
      ),
  },
  {
    path: 'color-management',
    loadComponent: () =>
      import('app/modules/admin/common/color/color.component').then(
        (m) => m.ColorComponent
      ),
  },
];
