import {
    HttpErrorResponse,
    HttpEvent,
    HttpHandlerFn,
    HttpRequest,
} from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthUtils } from 'app/core/auth/auth.utils';
import { AuthService } from 'app/services/auth.service';
import { Observable, catchError, throwError } from 'rxjs';

/**
 * Intercept
 *
 * @param req
 * @param next
 */
export const HttpInterceptor = (
    req: HttpRequest<unknown>,
    next: HttpHandlerFn
): Observable<HttpEvent<unknown>> => {
    const router = inject(Router);
    const authService = inject(AuthService);
    
    // Clone the request object
    let newReq = req.clone();

    // Request
    //
    // If auth token is available in local storage then append it in the header.
    // When the server to return a "401 Unauthorized" response
    // for the protected API routes which our response interceptor will
    // catch and delete the auth token from the local storage while logging
    // the user out from the app.

        newReq = req.clone();

        if (
            authService.isLoggedIn()
        ) {
            newReq = req.clone({
                headers: req.headers.set(
                    'Authorization',
                    'Bearer ' + authService.getToken()
                )
                .set('accept', '*/*')
            });
        }


    // Response
    return next(newReq).pipe(
        catchError((error) => {
            if (error && error.status === 401) {
                // Sign out
                localStorage.removeItem('authToken');
                localStorage.removeItem('userName');
                router.navigate(['signIn']);
            }
            return throwError(error);
        })
    );
};
