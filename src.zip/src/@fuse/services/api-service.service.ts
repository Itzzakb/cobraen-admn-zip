import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { GlobalVariables } from '../../app/global-variables';

@Injectable({ providedIn: 'root' })
export class ApiService {
  constructor(private http: HttpClient) {}

  baseURL = GlobalVariables.baseUrl;

  contentTypeApplicationJson = new HttpHeaders({
    'Content-Type': 'application/json',
  });

  // Enum values for SortOrder
  sortOrder = {
    DESCENDING: 1,
    ASCENDING: 2,
  };

  dropdownType = {
    NONE: 0,
    ORGANIZATION: 1,
    BUDGETGROUP: 2,
    USER: 4,
    STATUS: 8,
    PARTNER: 16,
    CATEGORY: 32,
    VAT: 64,
    PRODUCT: 64,
    BRAND: 128,
    CHARACTERISTICS: 256,
    // Calculate combined flags
    get ALL() { return 511; }, // All flags combined (1+2+4+8+16+32+64+128+256)
    get PRODUCT_SCREEN_DROPDOWNS() { return 498; }, // Partner+Category+VAT+Brand+Characteristics+BudgetGroup (16+32+64+128+256+2)
    // Helper function to combine flags
    combine: (...types) => types.reduce((acc, type) => acc | type, 0)
  };

  // login
  login(requestBody: any): Observable<any> {
    const header = new HttpHeaders({
      accept: '*/*',
      'Content-Type': 'application/json',
    });
    return this.http.post(`${this.baseURL}/Account/Login`, requestBody, {
      headers: header,
    });
  }

  // forgot password API
  forgotPassword(username: string): Observable<any> {
    return this.http.get(`${this.baseURL}/Account/ForgotPassword?userName=${username}`, { headers: this.contentTypeApplicationJson });
  }

  // Reset password API
  resetPassword(body: any): Observable<any> {
    return this.http.post(`${this.baseURL}/Account/ResetPassword`, body, {
      headers: this.contentTypeApplicationJson,
    });
  }

  //Validate the reset token
  validateResetToken(token: string): Observable<any> {
    return this.http.get(`${this.baseURL}/Account/ValidateResetPasswordToken`, { headers: this.contentTypeApplicationJson , params: new HttpParams().append('token', token)});
  }
  

  //brand APIs
  getbrands(params: any): Observable<any> {
    const url = params.searchQuery
      ? `${this.baseURL}/Brand/GetBrands?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}&Search=${params.searchQuery}`
      : `${this.baseURL}/Brand/GetBrands?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&pageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;
    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  createBrand(brand: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Brand/CreateBrand`, brand);
  }

  updateBrand(brand: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Brand/UpdateBrand`, brand);
  }

  deleteBrand(brandIds: number[]): Observable<any> {
    const requestBody = {
      selectedIds: brandIds,
      allSelected: false,
    };
    return this.http.delete(`${this.baseURL}/Brand/DeleteBrands`, {
      headers: this.contentTypeApplicationJson,
      body: requestBody,
    });
  }

  //category APIs
  getCategories(params: any): Observable<any> {
    const url = params.searchQuery
      ? `${this.baseURL}/Category/GetCategories?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&pageSize=${params.pageSize}&SortOrder=${params.sortOrder}&Search=${params.searchQuery}`
      : `${this.baseURL}/Category/GetCategories?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&pageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;
    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }
  getParentCategories(): Observable<any> {
    const url = `${this.baseURL}/Category/GetParentCategories`;
    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  createCategory(Category: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Category/CreateCategory`, Category);
  }

  updateCategory(Category: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Category/UpdateCategory`, Category);
  }

  deleteCategory(CategoryIds: number[]): Observable<any> {
    const requestBody = {
      selectedIds: CategoryIds,
      allSelected: false,
    };
    return this.http.delete(`${this.baseURL}/Category/DeleteCategories`, {
      headers: this.contentTypeApplicationJson,
      body: requestBody,
    });
  }

  getAllCategories(): Observable<any> {
    return this.http.get(`${this.baseURL}/Category/GetAllCategories`, {
      headers: this.contentTypeApplicationJson,
    });
  }

  //VAT APIs
  getVats(params: any): Observable<any> {
    const url = params.searchQuery
      ? `${this.baseURL}/Vat/GetVats?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}&Search=${params.searchQuery}`
      : `${this.baseURL}/Vat/GetVats?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&pageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;
    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  createVat(brand: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Vat/CreateVat`, brand);
  }

  updateVat(brand: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Vat/UpdateVat`, brand);
  }

  deleteVat(Ids: number[]): Observable<any> {
    const requestBody = {
      selectedIds: Ids,
      allSelected: false,
    };
    return this.http.delete(`${this.baseURL}/Vat/DeleteVats`, {
      headers: this.contentTypeApplicationJson,
      body: requestBody,
    });
  }

  //CMSContent APIs
  getCMSContent(params: any): Observable<any> {
    const url = params.searchQuery
      ? `${this.baseURL}/CMSContent/GetCMSContent?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}&Search=${params.searchQuery}`
      : `${this.baseURL}/CMSContent/GetCMSContent?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&pageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;
    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  updateCMSContent(body: any): Observable<any> {
    return this.http.post(`${this.baseURL}/CMSContent/EditCMSContent`, body, {
      headers: this.contentTypeApplicationJson,
    });
  }

  deleteCMSContent(Ids: number[]): Observable<any> {
    const requestBody = {
      selectedIds: Ids,
      allSelected: false,
    };
    return this.http.delete(`${this.baseURL}/CMSContent/DeleteCMSContent`, {
      headers: this.contentTypeApplicationJson,
      body: requestBody,
    });
  }

  //FAQType APIs
  getFAQTypes(params: any): Observable<any> {
    const url = params.searchQuery
      ? `${this.baseURL}/Faq/GetFaqTypes?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}&Search=${params.searchQuery}`
      : `${this.baseURL}/Faq/GetFaqTypes?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&pageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;
    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  createFAQType(body: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Faq/CreateFaqType`, body);
  }

  updateFAQType(body: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Faq/UpdateFaqType`, body);
  }

  deleteFAQType(ids: number[]): Observable<any> {
    const requestBody = {
      selectedIds: ids,
      allSelected: false,
    };
    return this.http.delete(`${this.baseURL}/Faq/DeleteFaqTypes`, {
      headers: this.contentTypeApplicationJson,
      body: requestBody,
    });
  }

  //FAQ APIs
  getFAQs(params: any): Observable<any> {
    var url = `${this.baseURL}/Faq/GetFaqs?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&pageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;

    if (params.searchQuery && params.faqTypeId) {
      url += `&Search=${params.searchQuery}&FaqTypeId=${params.faqTypeId}`;
    }

    if (params.searchQuery) {
      url += `&Search=${params.searchQuery}`;
    }

    if (params.faqTypeId) {
      url += `&FaqTypeId=${params.faqTypeId}`;
    }
    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  getFAQTypesList(): Observable<any> {
    return this.http.get(`${this.baseURL}/Faq/GetAllFaqTypes`, {
      headers: this.contentTypeApplicationJson,
    });
  }

  createFAQ(body: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Faq/CreateFaq`, body);
  }

  updateFAQ(body: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Faq/UpdateFaq`, body);
  }

  deleteFAQ(ids: number[]): Observable<any> {
    const requestBody = {
      selectedIds: ids,
      allSelected: false,
    };
    return this.http.delete(`${this.baseURL}/Faq/DeleteFaqs`, {
      headers: this.contentTypeApplicationJson,
      body: requestBody,
    });
  }

  //FAQ Group APIs
  getFAQGroups(params: any): Observable<any> {
    const url = params.searchQuery
      ? `${this.baseURL}/Faq/GetFaqGroups?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}&Search=${params.searchQuery}`
      : `${this.baseURL}/Faq/GetFaqGroups?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&pageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;
    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  createFAQGroup(faqGroup: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Faq/CreateFaqGroup`, faqGroup);
  }

  updateFAQGroup(faqGroup: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Faq/UpdateFaqGroup`, faqGroup);
  }

  deleteFAQGroup(ids: number[]): Observable<any> {
    const requestBody = {
      selectedIds: ids,
      allSelected: false,
    };
    return this.http.delete(`${this.baseURL}/Faq/DeleteFaqGroups`, {
      headers: this.contentTypeApplicationJson,
      body: requestBody,
    });
  }

  getAllFaqs(): Observable<any> {
    return this.http.get(`${this.baseURL}/Faq/GetAllFaqs`, {
      headers: this.contentTypeApplicationJson,
    });
  }

  copyFAQGroup(faqGroup: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Faq/CopyFaqGroup`, faqGroup);
  }

  updateFAQGroupStatus(body: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Faq/EditFaqGroupStatus`, body);
  }

  //Budget group APIs

  getBudgetGroups(params: any): Observable<any> {
    const url = params.searchQuery
      ? `${this.baseURL}/BudgetGroup/GetBudgetGroups?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}&Search=${params.searchQuery}`
      : `${this.baseURL}/BudgetGroup/GetBudgetGroups?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&pageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;

    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  createBudgetGroup(body: FormData): Observable<any> {
    return this.http.post(
      `${this.baseURL}/BudgetGroup/CreateBudgetGroup`,
      body
    );
  }

  updateBudgtGroup(body: FormData): Observable<any> {
    return this.http.post(
      `${this.baseURL}/BudgetGroup/UpdateBudgetGroup`,
      body
    );
  }

  deleteBudgetGroup(ids: number[]): Observable<any> {
    const requestBody = {
      selectedIds: ids,
      allSelected: false,
    };
    return this.http.delete(`${this.baseURL}/BudgetGroup/DeleteBudgetGroups`, {
      headers: this.contentTypeApplicationJson,
      body: requestBody,
    });
  }

  copyBudgetGroup(faqGroup: FormData): Observable<any> {
    return this.http.post(
      `${this.baseURL}/BudgetGroup/CopyBudgetGroup`,
      faqGroup
    );
  }

  getOrganizationBudgetGroups(id: number): Observable<any> {
    return this.http.get(
      `${this.baseURL}/BudgetGroup/GetOrganizationBudgetGroups?organizationId=${id}`,
      { headers: this.contentTypeApplicationJson }
    );
  }

  //organization APIs

  getOrganizations(params: any): Observable<any> {
    let url = params.searchQuery
      ? `${this.baseURL}/Organization/GetOrganizations?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}&Search=${params.searchQuery}`
      : `${this.baseURL}/Organization/GetOrganizations?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&pageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;

    url += params.status != 0 ? `&Status=${params.status}` : '';

    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  createOrganization(body: FormData): Observable<any> {
    return this.http.post(
      `${this.baseURL}/Organization/CreateOrganization`,
      body
    );
  }

  updateOrganization(body: FormData): Observable<any> {
    return this.http.post(
      `${this.baseURL}/Organization/UpdateOrganization`,
      body
    );
  }

  deleteOrganization(ids: number[]): Observable<any> {
    const requestBody = {
      selectedIds: ids,
      allSelected: false,
    };
    return this.http.delete(
      `${this.baseURL}/Organization/DeleteOrganizations`,
      { headers: this.contentTypeApplicationJson, body: requestBody }
    );
  }

  copyOrganization(body: FormData): Observable<any> {
    return this.http.post(
      `${this.baseURL}/Organization/CopyOrganization`,
      body
    );
  }

  updateOrganizationStatus(body: FormData): Observable<any> {
    return this.http.post(
      `${this.baseURL}/Organization/EditOrganizationStatus`,
      body
    );
  }

  getAllFAQGroupsForDropdown(): Observable<any> {
    return this.http.get(`${this.baseURL}/Faq/GetAllFaqGroups`, {
      headers: this.contentTypeApplicationJson,
    });
  }

  getAllBudgetGroupsForDropdown(): Observable<any> {
    return this.http.get(`${this.baseURL}/BudgetGroup/GetAllBudgetGroups`, {
      headers: this.contentTypeApplicationJson,
    });
  }

  getAllCountries(): Observable<any> {
    return this.http.get(`${this.baseURL}/Common/GetCountries`, {
      headers: this.contentTypeApplicationJson,
    });
  }

  // Order messages
  getOrderMessages(params: any): Observable<any> {
    const url = params.searchQuery
      ? `${this.baseURL}/OrderMessage/GetOrderMessages?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}&Search=${params.searchQuery}`
      : `${this.baseURL}/OrderMessage/GetOrderMessages?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&pageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;
    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  updateOrderMessage(body: any): Observable<any> {
    return this.http.post(
      `${this.baseURL}/OrderMessage/EditOrderMessage`,
      body,
      { headers: this.contentTypeApplicationJson }
    );
  }

  deleteOrderMessage(Ids: number[]): Observable<any> {
    const requestBody = {
      selectedIds: Ids,
      allSelected: false,
    };
    return this.http.delete(`${this.baseURL}/OrderMessage/DeleteOrderMessage`, {
      headers: this.contentTypeApplicationJson,
      body: requestBody,
    });
  }

  //Organization branding APIs

  getOrganizationBrandings(params: any): Observable<any> {
    const url = params.searchQuery
      ? `${this.baseURL}/OrgBranding/GetOrganizationBrandings?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}&Search=${params.searchQuery}`
      : `${this.baseURL}/OrgBranding/GetOrganizationBrandings?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&pageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;

    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  createOrganizationBranding(body: FormData): Observable<any> {
    return this.http.post(
      `${this.baseURL}/OrgBranding/CreateOrganizationBranding`,
      body
    );
  }

  updateOrganizationBranding(body: FormData): Observable<any> {
    return this.http.post(
      `${this.baseURL}/OrgBranding/UpdateOrganizationBranding`,
      body
    );
  }

  deleteOrganizationBranding(ids: number[]): Observable<any> {
    const requestBody = {
      selectedIds: ids,
      allSelected: false,
    };
    return this.http.delete(
      `${this.baseURL}/OrgBranding/DeleteOrganizationBrandings`,
      { headers: this.contentTypeApplicationJson, body: requestBody }
    );
  }

  copyOrganizationBranding(body: FormData): Observable<any> {
    return this.http.post(
      `${this.baseURL}/OrgBranding/CopyOrganizationBranding`,
      body
    );
  }

  getAllOrganizations(): Observable<any> {
    return this.http.get(`${this.baseURL}/Organization/GetAllOrganizations`, {
      headers: this.contentTypeApplicationJson,
    });
  }

  getDeafultStyling(): Observable<any> {
    // Add error handling to avoid unhandled errors when endpoint doesn't exist
    try {
      return this.http
        .get(`${this.baseURL}/OrgBranding/GetDefaultStyling`, {
          headers: this.contentTypeApplicationJson,
        })
        .pipe();
    } catch (error) {
      console.warn('Error in getDefaultStyling:', error);
      return of({ result: null });
    }
  }

  //change password API

  changePassword(body: any): Observable<any> {
    return this.http.post(`${this.baseURL}/Account/ChangePassword`, body);
  }

  // Import APIs
  importUsers(file: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Import/ImportUsers`, file);
  }

  importProducts(file: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Import/ImportProducts`, file);
  }

    
  importAdditionalProductImages(formData: FormData): Observable<any> {
      // Use text response type to handle plain text responses
      return this.http.post(`${this.baseURL}/ProductImages/ImportAdditionalProductImages/ImportAdditional`, formData, {
          responseType: 'text'
      });
  }



  //christmas fair setting APIs

  getChristmasFairSettings(params: any): Observable<any> {
    let url = `${this.baseURL}/ChristmasFairSettings/GetChristmasFairSettings?SortBy=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;

    if (params.searchQuery != '') {
      url += `&Search=${params.searchQuery}`;
    }
    if (params.organizationId) {
      url += `&OrganizationId=${params.organizationId}`;
    }
    if (params.christmasFairId) {
      url += `&ChristmasFairId=${params.christmasFairId}`;
    }
    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  updateChristmasFairSetting(body: any): Observable<any> {
    return this.http.put(
      `${this.baseURL}/ChristmasFairSettings/EditChristmasFairSettings`,
      body
    );
  }

  getAllChristmasFairs(): Observable<any> {
    return this.http.get(
      `${this.baseURL}/ChristmasFairSettings/GetAllChristmasFairs`,
      { headers: this.contentTypeApplicationJson }
    );
  }

  //Christmas Fair Question APIs

  getChristmasFairQuestions(params: any): Observable<any> {
    let url = `${this.baseURL}/ChristmasFairQuestions?SortBy=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;

    if (params.fairId) {
      url += `&fairId=${params.fairId}`;
    }
    if (params.orgId) {
      url += `&organizationId=${params.orgId}`;
    }
    if (params.searchQuery) {
      url += `&search=${params.searchQuery}`;
    }

    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  updateChristmasFairQuestion(body: any): Observable<any> {
    return this.http.post(`${this.baseURL}/ChristmasFairQuestions`, body, {
      headers: this.contentTypeApplicationJson,
    });
  }

  copyChristmasFairQuestion(body: any): Observable<any> {
    return this.http.post(`${this.baseURL}/ChristmasFairQuestions/copy`, body, {
      headers: this.contentTypeApplicationJson,
    });
  }

  // Christmas Fair APIs

  getChristmasFairs(params: any): Observable<any> {
    let url = `${this.baseURL}/ChristmasFair/GetChristmasFairs?SortBy=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;

    if (params.searchQuery != '') {
      url += `&Search=${params.searchQuery}`;
    }
    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  createChristmasFair(body: any): Observable<any> {
    return this.http.post(
      `${this.baseURL}/ChristmasFair/CreateChristmasFair`,
      body
    );
  }

  updateChristmasFair(body: any): Observable<any> {
    return this.http.put(
      `${this.baseURL}/ChristmasFair/UpdateChristmasFair`,
      body
    );
  }

  deleteChristmasFair(idsArray: number[]): Observable<any> {
    const requestBody = {
      ids: idsArray,
    };
    return this.http.delete(
      `${this.baseURL}/ChristmasFair/DeleteChristmasFairs`,
      { headers: this.contentTypeApplicationJson, body: requestBody }
    );
  }

  updateChristmasFairStatus(id: number, status: boolean): Observable<any> {
    let body = {
      active: status,
    };
    return this.http.patch(
      `${this.baseURL}/ChristmasFair/UpdateActiveStatus/${id}/active`,
      body,
      { headers: this.contentTypeApplicationJson }
    );
  }

  // Partners APIs

  getPartners(params: any): Observable<any> {
    let url = `${this.baseURL}/Partner/GetPartners?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;

    if (params.searchQuery != '') {
      url += `&Search=${params.searchQuery}`;
    }

    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  createPartner(body: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Partner/CreatePartner`, body);
  }

  updatePartner(body: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Partner/UpdatePartner`, body);
  }

  deletePartner(idsArray: number[]): Observable<any> {
    const requestBody = {
      selectedIds: idsArray,
      allSelected: false,
    };
    return this.http.delete(`${this.baseURL}/Partner/DeletePartners`, {
      headers: this.contentTypeApplicationJson,
      body: requestBody,
    });
  }

  getAllCoumnsForFulfillment(): Observable<any> {
    return this.http.get(`${this.baseURL}/Partner/GetColumnsForFulfillment`, {
      headers: this.contentTypeApplicationJson,
    });
  }

  getAllFulfillments(): Observable<any> {
    return this.http.get(`${this.baseURL}/Partner/GetFulfillments`, {
      headers: this.contentTypeApplicationJson,
    });
  }

  getPartnerProductsAndCategories(partnerId: number): Observable<any> {
    return this.http.get(`${this.baseURL}/Partner/GetPartnerProductsAndCategories?partnerId=${partnerId}`, {
      headers: this.contentTypeApplicationJson,
    });
  }

  //Product APIs
  getProducts(params: any): Observable<any> {
    let url = `${this.baseURL}/Product/GetProducts?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;

    if (params.searchQuery != '') {
      url += `&Search=${params.searchQuery}`;
    }
    if (params.categoryId) {
      url += `&CategoryId=${params.categoryId}`;
    }
    if (params.brandId) {
      url += `&BrandId=${params.brandId}`;
    }
    if (params.partnerId) {
      url += `&PartnerId=${params.partnerId}`;
    }
    if (params.status) {
      url += `&Status=${params.status}`;
    }
    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  createProduct(body: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Product/CreateProduct`, body);
  }

  updateProduct(body: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Product/UpdateProduct`, body);
  }

  deleteProduct(idsArray: number[]): Observable<any> {
    const requestBody = {
      selectedIds: idsArray,
      allSelected: false,
    };
    return this.http.delete(`${this.baseURL}/Product/DeleteProducts`, {
      headers: this.contentTypeApplicationJson,
      body: requestBody,
    });
  }

  getAllProducts(): Observable<any> {
    return this.http.get(`${this.baseURL}/Product/GetAllProducts`, {
      headers: this.contentTypeApplicationJson,
    });
  }

  updateProductStatus(body: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/Product/EditProductStatus`, body);
  }

  getAllDropdownData(id: number, pageSize: number = 10): Observable<any> {
  
    const partnerPageSize = id === this.dropdownType.PRODUCT_SCREEN_DROPDOWNS ? 1000 : pageSize;
    
    return this.http.get(
      `${this.baseURL}/OrderDropdown/GetDropdowns?DropdownTypes=${id}&PageSize=${partnerPageSize}`,
      { headers: this.contentTypeApplicationJson }
    );
  }

  // Characteristics APIs

  getCharacteristics(params: any): Observable<any> {
    const url = params.searchQuery
      ? `${this.baseURL}/Characteristics/GetCharacteristics?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}&Search=${params.searchQuery}`
      : `${this.baseURL}/Characteristics/GetCharacteristics?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&pageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;

    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  createCharacteristics(body: FormData): Observable<any> {
    return this.http.post(
      `${this.baseURL}/Characteristics/CreateCharacteristics`,
      body
    );
  }

  updateCharacteristics(body: FormData): Observable<any> {
    return this.http.post(
      `${this.baseURL}/Characteristics/UpdateCharacteristics`,
      body
    );
  }

  deleteCharacteristics(idsArray: number[]): Observable<any> {
    const requestBody = {
      selectedIds: idsArray,
      allSelected: false,
    };
    return this.http.delete(
      `${this.baseURL}/Characteristics/DeleteCharacteristics`,
      { headers: this.contentTypeApplicationJson, body: requestBody }
    );
  }

  getAllCharacteristics(): Observable<any> {
    return this.http.get(
      `${this.baseURL}/Characteristics/GetAllCharacteristics`,
      { headers: this.contentTypeApplicationJson }
    );
  }

  // Season APIs

  getCurrentSeason(): Observable<any> {
    return this.http.get(`${this.baseURL}/Season/GetCurrentSeason`, {
      headers: this.contentTypeApplicationJson,
    });
  }

  getSeasonDetails(id: number): Observable<any> {
    return this.http.get(
      `${this.baseURL}/Season/GetSeasonDetails?seasonId=${id}`,
      { headers: this.contentTypeApplicationJson }
    );
  }

  updateSeason(body: any) {
    return this.http.post(`${this.baseURL}/Season/EditSeason`, body, {
      headers: this.contentTypeApplicationJson,
    });
  }

  resetSeason(body: any) {
    return this.http.post(`${this.baseURL}/Season/ResetSeason`, body, {
      headers: this.contentTypeApplicationJson,
    });
  }

  // ExtraStock APIs
  getExtraStocks(params: any): Observable<any> {
    let url = `${this.baseURL}/ExtraStock/GetExtraStocks`;

    // Add query parameters
    const queryParams = [];
    if (params.pageIndex !== undefined)
      queryParams.push(`PageIndex=${params.pageIndex}`);
    if (params.pageSize !== undefined)
      queryParams.push(`PageSize=${params.pageSize}`);
    if (params.sortBy !== undefined)
      queryParams.push(`SortBy=${params.sortBy}`);
    // Convert string sort order to numerical enum (1 = Descending, 2 = Ascending)
    if (params.sortOrder !== undefined) {
      const sortOrderValue = params.sortOrder === 'asc' ? 2 : 1;
      queryParams.push(`SortOrder=${sortOrderValue}`);
    }
    if (params.search !== undefined && params.search)
      queryParams.push(`Search=${params.search}`);
    if (params.statusId !== undefined)
      queryParams.push(`StatusId=${params.statusId}`);

    // Append query parameters to URL
    if (queryParams.length > 0) {
      url += '?' + queryParams.join('&');
    }

    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  getExtraStockDetails(id: number): Observable<any> {
    return this.http.get(
      `${this.baseURL}/ExtraStock/GetExtraStockDetails/${id}`,
      {
        headers: this.contentTypeApplicationJson,
      }
    );
  }

  createExtraStock(data: any): Observable<any> {
    return this.http.post(`${this.baseURL}/ExtraStock/CreateExtraStock`, data, {
      headers: this.contentTypeApplicationJson,
    });
  }

  updateExtraStock(data: any): Observable<any> {
    return this.http.put(`${this.baseURL}/ExtraStock/UpdateExtraStock`, data, {
      headers: this.contentTypeApplicationJson,
    });
  }

  updateExtraStockDeliveryStatus(data: any): Observable<any> {
    return this.http.patch(
      `${this.baseURL}/ExtraStock/UpdateDeliveryStatus/UpdateDeliveryStatus`,
      data,
      {
        headers: this.contentTypeApplicationJson,
      }
    );
  }

  searchProducts(params: any): Observable<any> {
    let url = `${this.baseURL}/ExtraStock/SearchProducts/SearchProducts`;

    // Add query parameters
    const queryParams = [];
    if (params.pageIndex !== undefined)
      queryParams.push(`PageIndex=${params.pageIndex}`);
    if (params.pageSize !== undefined)
      queryParams.push(`PageSize=${params.pageSize}`);
    if (params.search !== undefined && params.search)
      queryParams.push(`SearchTerm=${params.search}`);

    // Append query parameters to URL
    if (queryParams.length > 0) {
      url += '?' + queryParams.join('&');
    }

    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  //Giftset APIs

  getGiftsets(params: any): Observable<any> {
    let url = `${this.baseURL}/GiftSet/GetGiftSets?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;

    if (params.searchQuery != '') {
      url += `&Search=${params.searchQuery}`;
    }
    if (params.categoryId) {
      url += `&CategoryId=${params.categoryId}`;
    }
    if (params.status) {
      url += `&Status=${params.status}`;
    }
    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  createGiftset(body: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/GiftSet/CreateGiftSet`, body);
  }

  updateGiftset(body: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/GiftSet/UpdateGiftSet`, body);
  }

  deleteGiftSet(idsArray: number[]): Observable<any> {
    const requestBody = {
      selectedIds: idsArray,
      allSelected: false,
    };
    return this.http.delete(`${this.baseURL}/GiftSet/DeleteGiftSets`, {
      headers: this.contentTypeApplicationJson,
      body: requestBody,
    });
  }

  updateGiftSetStatus(body: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/GiftSet/EditGiftSetStatus`, body);
  }

  // Users APIs
  getUsers(params: any): Observable<any> {
    let url = `${this.baseURL}/User/GetUsers?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;

    if (params.searchQuery != '') {
      url += `&Search=${params.searchQuery}`;
    }
    if (params.organizationId) {
      url += `&OrganizationId=${params.organizationId}`;
    }
    if (params.status) {
      url += `&Status=${params.status}`;
    }
    if (params.sendDateMail) {
      url += `&WebShopMail=${params.sendDateMail}`;
    }

    return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  createUser(body: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/User/CreateUser`, body);
  }

  updateUser(body: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/User/UpdateUser`, body);
  }

  deleteUser(idsArray: string[]): Observable<any> {
    const requestBody = {
      selectedIds: idsArray,
      allSelected: false,
    };
    return this.http.delete(`${this.baseURL}/User/DeleteUsers`, {
      headers: this.contentTypeApplicationJson,
      body: requestBody,
    });
  }

  updateUserStatus(body: FormData): Observable<any> {
    return this.http.post(`${this.baseURL}/User/EditUserActiveStatus`, body);
  }

  getEventPartners(): Observable<any> {
    return this.http.get(`${this.baseURL}/User/GetEventPartners`, {
      headers: this.contentTypeApplicationJson,
    });
  }

    // Order APIs
    createOrder(model: any): Observable<any> {
        return this.http.post(`${this.baseURL}/Order/CreateOrder`, model, { headers: this.contentTypeApplicationJson });
    }
    
    updateOrder(model: any): Observable<any> {
        return this.http.put(`${this.baseURL}/Order/UpdateOrder`, model, { headers: this.contentTypeApplicationJson });
    }
    
    getOrders(params: any): Observable<any> {
        let url = `${this.baseURL}/Order/GetOrders?PageIndex=${params.pageIndex}&PageSize=${params.pageSize}`;
        
        if (params.sortBy) {
            url += `&SortBy=${params.sortBy}`;
        }
        
        if (params.sortOrder) {
            url += `&SortOrder=${params.sortOrder}`;
        }
        
        if (params.search) {
            url += `&Search=${params.search}`;
        }
        
        if (params.partnerId) {
            url += `&PartnerId=${params.partnerId}`;
        }
        
        if (params.budgetGroupId) {
            url += `&BudgetGroupId=${params.budgetGroupId}`;
        }
        
        if (params.organizationId) {
            url += `&OrganizationId=${params.organizationId}`;
        }
        
        if (params.userId) {
            url += `&UserId=${params.userId}`;
        }
        
        if (params.statusId) {
            url += `&StatusId=${params.statusId}`;
        }
        
        if (params.inExtraOrder !== undefined && params.inExtraOrder !== null) {
            url += `&InExtraOrder=${params.inExtraOrder}`;
        }
        
        return this.http.get(url, { headers: this.contentTypeApplicationJson });
    }
    
    deleteOrders(orderIds: number[]): Observable<any> {
        const requestBody = {
            orderIds: orderIds
        };
        return this.http.delete(`${this.baseURL}/Order/DeleteOrders`, { headers: this.contentTypeApplicationJson, body: requestBody });
    }
    
    bulkUpdateOrderStatus(orderIds: number[], statusId: number): Observable<any> {
        const requestBody = {
            OrderIds: orderIds,
            StatusId: statusId
        };
        return this.http.put(`${this.baseURL}/Order/BulkUpdateOrderStatus/BulkStatusUpdate`, requestBody, { headers: this.contentTypeApplicationJson });
    }
    

    
    // Order dropdowns API
    getOrderDropdowns(dropdownTypes: number, params: any = {}): Observable<any> {
        // Build the URL with query parameters
        let url = `${this.baseURL}/OrderDropdown/GetDropdowns?DropdownTypes=${dropdownTypes}`;
        
        // Add pagination parameters if provided
        if (params.pageIndex !== undefined) {
            url += `&PageIndex=${params.pageIndex}`;
        }
        
        if (params.pageSize !== undefined) {
            url += `&PageSize=${params.pageSize}`;
        }
        
        // Add search parameter if provided
        if (params.search) {
            url += `&Search=${encodeURIComponent(params.search)}`;
        }
        
        // Add organizationId parameter if provided
        if (params.organizationId) {
            url += `&OrganizationId=${params.organizationId}`;
        }
        
        return this.http.get(url, { headers: this.contentTypeApplicationJson });
    }


    //Free gifts APIs

    getFreeGifts(params: any): Observable<any> {
        let url = `${this.baseURL}/FreeGift/GetFreeGifts?SortColumn=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;

        if (params.searchQuery != '') {
            url += `&Search=${params.searchQuery}`;
        }
        
        return this.http.get(url, { headers: this.contentTypeApplicationJson });
    }

    createFreeGift(body: any): Observable<any> {
        return this.http.post(`${this.baseURL}/FreeGift/AddFreeGift`, body, { headers: this.contentTypeApplicationJson });
    }

    updateFreeGift(body: any, id: number): Observable<any> {
        return this.http.put(`${this.baseURL}/FreeGift/EditFreeGift/${id}`, body, { headers: this.contentTypeApplicationJson } );
    }

    deleteFreeGift(idsArray: number[]): Observable<any> {
        const requestBody = {
            "selectedIds": idsArray,
            "allSelected": false
        }
        return this.http.delete(`${this.baseURL}/FreeGift/DeleteFreeGifts`, { headers: this.contentTypeApplicationJson, body: requestBody });
    }

    getFreeGiftPartners(): Observable<any>{
        return this.http.get(`${this.baseURL}/Partner/GetFreeGiftPartners`, { headers: this.contentTypeApplicationJson } );
    }

    //Standard Gift APIs
    getStandardGifts(params: any): Observable<any> {
      let url = `${this.baseURL}/StandardGift/GetStandardGifts?SortBy=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;

      if (params.searchQuery != '') {
          url += `&Search=${params.searchQuery}`;
      }
      
      return this.http.get(url, { headers: this.contentTypeApplicationJson });
  }

  createStandardGift(body: any): Observable<any> {
      return this.http.post(`${this.baseURL}/StandardGift/CreateStandardGift`, body, { headers: this.contentTypeApplicationJson });
  }

  updateStandardGift(body: any): Observable<any> {
      return this.http.put(`${this.baseURL}/StandardGift/UpdateStandardGift`, body, { headers: this.contentTypeApplicationJson } );
  }

  updateStandardGiftStatus(body: any): Observable<any> {
      return this.http.put(`${this.baseURL}/StandardGift/UpdateStatus`, body, { headers: this.contentTypeApplicationJson } );
  }

  deleteStandardGift(idsArray: number[]): Observable<any> {
      const requestBody = {
          "standardGiftIds": idsArray,
      }
      return this.http.delete(`${this.baseURL}/StandardGift/DeleteStandardGifts`, { headers: this.contentTypeApplicationJson, body: requestBody });
  }

  //Employee Info APIs
  getEmployees(params: any): Observable<any> {
    let url = `${this.baseURL}/ChristmasFairEmployee/GetChristmasFairEmployees?SortBy=${params.sortColumn}&PageIndex=${params.pageIndex}&PageSize=${params.pageSize}&SortOrder=${params.sortOrder}`;

    ////console.log((params);

    if (params.searchQuery != '') {
        url += `&Search=${params.searchQuery}`;
    }
    if (params.registered !== null) {
        url += `&Registered=${params.registered}`;
    }
    if (params.arrived !== null) {
        url += `&Arrived=${params.arrived}`;
    }
    if (params.coming !== null) {
        url += `&Coming=${params.coming}`;
    }
    if (params.fairId) {
        url += `&FairId=${params.fairId}`;
    }
    if (params.organizationId) {
        url += `&OrganizationId=${params.organizationId}`;
    }
    if (params.active !== null) {
        url += `&Active=${params.active}`;
    }
    
    return this.http.get(url, { headers: this.contentTypeApplicationJson });
}

updateEmployeeStatus( body: any): Observable<any> {  
  return this.http.put(`${this.baseURL}/ChristmasFairEmployee/UpdateEmployeeArrivedStatus/arrived`, body, { headers: this.contentTypeApplicationJson } );
}

updateEmployeeRemark(body: any): Observable<any> {  
  return this.http.put(`${this.baseURL}/ChristmasFairEmployee/UpdateEmployeeRemark/UpdateRemark`, body, { headers: this.contentTypeApplicationJson } );
}

getEmployeeCount(): Observable<any>{
  return this.http.get(`${this.baseURL}/ChristmasFairEmployee/GetChristmasFairEmployeeCounts`, { headers: this.contentTypeApplicationJson } );
}

// Send orders to fulfillment
sendOrdersToFulfillment(orderIds: number[]): Observable<any> {
  const requestBody = {
    orderIds: orderIds
  };
  return this.http.post(`${this.baseURL}/Order/SendOrdersToFulfillment/SendToFulfillment`, requestBody, { headers: this.contentTypeApplicationJson });
}

//Image library API
getImageLibraryContent(currentPage: number, pageSize: number):Observable<any>{
  return this.http.get(`${this.baseURL}/ImageLibrary/GetLibraryImages?PageIndex=${currentPage}&PageSize=${pageSize}`, { headers: this.contentTypeApplicationJson } );
}

}

